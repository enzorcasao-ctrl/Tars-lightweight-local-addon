"""2.6.1: app aberto que não expõe os botões (Electron: Claude, Discord...).

Log real: "open claude and type..." -> a janela do Claude não tem árvore de
acessibilidade; a IA tentou click_element com 14 nomes diferentes (tirados
da descrição do print), todos falhando, até o limite de etapas.

O xmessage (X puro, sem acessibilidade) faz o papel do app Electron."""

import os
import shutil
import subprocess
import sys
import time

from _util import carregar_tars

tars = carregar_tars()

# ------------------------------------------------------------
# 1. Parte com a janela de verdade (precisa de X + D-Bus + xmessage)
# ------------------------------------------------------------
tem_x = (os.environ.get("DISPLAY") and os.environ.get("DBUS_SESSION_BUS_ADDRESS")
         and shutil.which("xmessage") and not tars.acess.indisponivel())
if tem_x:
    proc = subprocess.Popen(["xmessage", "-name", "clauded", "-title", "Claude", "Olá, eu sou um app Electron"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        limite = time.time() + 10
        while time.time() < limite and not tars.encontrar_janela_por_nome("Claude"):
            time.sleep(0.2)
        abriu = []
        tars.abrir_aplicativo = lambda app: abriu.append(app) or {"sucesso": True}
        r = tars.executar_ferramenta("click_element", {"name": "New chat", "window": "Claude"})
        assert not r["sucesso"] and "does not expose" in r["mensagem"] and "type_text" in r["mensagem"], r
        assert not abriu, "a janela já estava aberta: não abre o app de novo"
        inicio = time.time()
        r2 = tars.executar_ferramenta("list_elements", {"window": "Claude"})
        assert not r2["sucesso"] and "Do NOT use click_element" in r2["mensagem"] and time.time() - inicio < 0.2
        print("OK: janela aberta sem botões expostos -> diz na hora pra usar type_text/click_mouse (e não reabre o app)")
    finally:
        proc.kill()
else:
    print("PULADO (parte 1): precisa de DISPLAY, D-Bus, xmessage e acessibilidade")

# ------------------------------------------------------------
# 2. O loop do log: a IA insiste no click_element com nomes diferentes
# ------------------------------------------------------------
tars.carregar_modelo = lambda m, silencioso=False: True
tars.contexto_ia = lambda: 8192
tars.modo_modelo = "MANUAL"
tars.catalogar_modelos = lambda forcar=False: {}
nomes = iter(f"Botão {i}" for i in range(100))
turnos = []


def turno(modelo, msgs, tools, **kw):
    turnos.append(bool(tools))
    if not tools:
        return {"content": "Não consegui clicar: o app não mostra os botões. Clique você no campo.", "tool_calls": []}, None
    return {"content": "", "tool_calls": [{"function": {"name": "click_element",
                                                         "arguments": {"name": next(nomes), "window": "Claude"}}}]}, None


tars._executar_turno_streaming = turno
tars._DISPATCH_FERRAMENTAS["click_element"] = lambda a: {"sucesso": False, "mensagem": f"No element named '{a['name']}'."}
tars.conversa = []
resposta = tars.perguntar_modelo("qwen3:8b", "open claude and type hello", tarefa="acao")
assert "Não consegui" in resposta, resposta
assert turnos.count(True) == tars.LIMITE_FALHAS_SEGUIDAS and turnos[-1] is False, turnos
resultados = [m["content"] for m in tars.obter_sessao("qwen3:8b") if m.get("role") == "tool"]
assert "STOP" not in resultados[1] and "STOP: click_element failed 3 times" in resultados[2], resultados[:3]
print(f"OK: 3 falhas seguidas -> 'mude de estratégia'; {tars.LIMITE_FALHAS_SEGUIDAS} -> para e explica ao usuário "
      f"(antes: 20 etapas)")

# 3. A mesma chamada que já falhou nem roda de novo
rodou = []
tars._DISPATCH_FERRAMENTAS["click_element"] = lambda a: rodou.append(a) or {"sucesso": False, "mensagem": "nope."}
chamadas = iter([("click_element", {"name": "Send", "window": "Claude"})] * 2 + [None])


def turno2(modelo, msgs, tools, **kw):
    proxima = next(chamadas)
    if proxima is None or not tools:
        return {"content": "ok", "tool_calls": []}, None
    return {"content": "", "tool_calls": [{"function": {"name": proxima[0], "arguments": proxima[1]}}]}, None


tars._executar_turno_streaming = turno2
tars.perguntar_modelo("qwen3:8b", "type hello in claude", tarefa="acao")
ultimo = [m["content"] for m in tars.obter_sessao("qwen3:8b") if m.get("role") == "tool"][-1]
assert len(rodou) == 1 and "already tried exactly this" in ultimo, (rodou, ultimo)
print("OK: repetir exatamente a mesma chamada que falhou não roda de novo (a IA é avisada)")

# 4. Descrição da tela de um app sem botões expostos: manda clicar por coordenada
tars._descrever_print = lambda img, pedido, modelo: ("Message box at (400, 700). Send button at (760, 700).", "gemma4:e4b")
tars._marcar_sem_arvore("Claude")
msg = tars._print_em_texto("x", "type hello", "qwen3:8b", "Claude")
assert "click_mouse(x, y)" in msg and "click_element(name)" not in msg, msg
msg_outro = tars._print_em_texto("x", "type hello", "qwen3:8b", "calculator")
assert "click_element(name)" in msg_outro
print("OK: com um app sem botões expostos, a descrição da tela manda usar click_mouse(x, y) e type_text")

# 5. Abrir app pede a árvore de acessibilidade ao Chromium/Electron
envs = []


class Popen:
    def __init__(self, *a, **kw):
        envs.append(kw.get("env") or {})
        self.returncode = 0

    def poll(self):
        return 0


fonte = carregar_tars()  # abrir_aplicativo original (a parte 1 trocou o do outro)
fonte.subprocess.Popen = Popen
fonte.encontrar_app = lambda app: {"comando": ["claude-desktop"], "nome": "Claude", "tipo": "desktop"}
fonte.listar_janelas_x = lambda: None
fonte._processo_ativo = lambda termos: True
fonte.abrir_aplicativo("claude")
assert envs and envs[-1].get("ACCESSIBILITY_ENABLED") == "1", envs
print("OK: apps são abertos com ACCESSIBILITY_ENABLED=1 (Electron/Chromium passam a expor os botões)")

print("\nTUDO OK.")
