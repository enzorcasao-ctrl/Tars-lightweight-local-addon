#!/bin/bash
# Configuração do openTARS: instala o que falta pra ele rodar (Ollama,
# ambiente Python isolado com as dependências, modelo ajudante
# gemma3:270m) e NUNCA reinstala algo que já está presente no PC.
# Roda automaticamente depois do "apt install" (chamado pelo postinst)
# e pode ser rodado de novo a qualquer momento com "opentars --setup".
#
# De propósito, NUNCA sai com erro: se o dpkg visse esse script falhar,
# deixaria o pacote marcado como "quebrado" mesmo com o openTARS
# utilizável. Cada etapa arriscada (rede, permissões) avisa e segue.

set -uo pipefail

MODELO_AJUDANTE="${TARS_MODELO_CLASSIFICADOR:-gemma3:270m}"
DIR_OPENTARS="/usr/share/opentars"
VENV="$DIR_OPENTARS/venv"
DEPENDENCIAS=("requests:requests" "psutil:psutil" "pyautogui:pyautogui" "PIL:pillow")

msg()   { echo "[openTARS] $*"; }
aviso() { echo "[openTARS] AVISO: $*"; }

echo ""
echo "=== Configurando o openTARS ==="
echo ""

# ------------------------------------------------------------------
# 1. Ollama — só instala se ainda não existir.
# ------------------------------------------------------------------
if command -v ollama >/dev/null 2>&1; then
    msg "Ollama já está instalado — pulando."
else
    msg "Ollama não encontrado. Instalando (via ollama.com/install.sh)..."
    # Baixa pro disco e só então executa: com "curl | sh" o status do
    # pipe é o do "sh", que "funciona" mesmo se o download falhar.
    instalador="$(mktemp)"
    if curl -fsSL https://ollama.com/install.sh -o "$instalador" && sh "$instalador"; then
        msg "Ollama instalado com sucesso."
    else
        aviso "não foi possível instalar o Ollama automaticamente (sem internet?)."
        echo "        Instale em https://ollama.com/download e depois rode: opentars --setup"
    fi
    rm -f "$instalador"
fi

# ------------------------------------------------------------------
# 2. Ambiente Python isolado.
#
# Um venv próprio evita o conflito do pyautogui com o setuptools do
# sistema em distros recentes (Ubuntu 24.04+, Zorin 17+).
# --system-site-packages deixa o venv enxergar o tkinter, que só existe
# como pacote do sistema (python3-tk), nunca via pip.
#
# Se o venv existe mas o Python dele não roda mais (ex: atualização da
# distro trocou a versão do Python), ele é recriado do zero.
# ------------------------------------------------------------------
# Escolhe o Python base: o "python3" padrão, a menos que ele não tenha
# tkinter e outro python3.X instalado tenha (acontece quando o python3
# do PATH foi trocado e o pacote python3-tk é da versão padrão da distro).
escolher_python() {
    local candidato
    for candidato in python3 /usr/bin/python3 $(ls -r /usr/bin/python3.[0-9]* 2>/dev/null | grep -E 'python3\.[0-9]+$'); do
        command -v "$candidato" >/dev/null 2>&1 || continue
        "$candidato" -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" 2>/dev/null || continue
        "$candidato" -c "import venv, tkinter" >/dev/null 2>&1 && { echo "$candidato"; return; }
    done
    echo python3
}

venv_ok() {
    [ -x "$VENV/bin/python3" ] && "$VENV/bin/python3" -c "pass" >/dev/null 2>&1
}

# Venv criado com um Python sem tkinter enquanto existe outro com tkinter
# (ex: python3-tk instalado depois): recria pra liberar a interface gráfica.
PYTHON_BASE="$(escolher_python)"
if venv_ok && ! "$VENV/bin/python3" -c "import tkinter" >/dev/null 2>&1 \
        && "$PYTHON_BASE" -c "import tkinter" >/dev/null 2>&1; then
    msg "Ambiente Python sem tkinter, mas '$PYTHON_BASE' tem — recriando."
    rm -rf "$VENV"
fi

if venv_ok; then
    msg "Ambiente Python já existe — pulando criação."
else
    [ -e "$VENV" ] && msg "Ambiente Python antigo quebrado — recriando."
    rm -rf "$VENV"
    msg "Criando ambiente Python isolado ($("$PYTHON_BASE" --version 2>&1))..."
    if "$PYTHON_BASE" -m venv --system-site-packages "$VENV"; then
        "$VENV/bin/pip" install --quiet --upgrade pip setuptools wheel \
            || aviso "não deu pra atualizar pip/setuptools (seguindo mesmo assim)."
        msg "Ambiente Python criado."
    else
        aviso "não deu pra criar o ambiente Python. Verifique o pacote 'python3-venv'."
        rm -rf "$VENV"
    fi
fi

if [ -x "$VENV/bin/python3" ]; then
    msg "Verificando dependências Python..."

    faltando=()
    for par in "${DEPENDENCIAS[@]}"; do
        modulo="${par%%:*}"
        pacote="${par##*:}"
        # find_spec só checa se o módulo existe, sem executá-lo. Um
        # "import" real do pyautogui lê $DISPLAY na hora e dá KeyError
        # sem sessão gráfica (como durante o próprio postinst).
        if ! "$VENV/bin/python3" -c "import importlib.util,sys; sys.exit(0 if importlib.util.find_spec('$modulo') else 1)" >/dev/null 2>&1; then
            faltando+=("$pacote")
        fi
    done

    if [ "${#faltando[@]}" -eq 0 ]; then
        msg "Todas as dependências Python já estão instaladas — pulando."
    else
        msg "Instalando dependências Python: ${faltando[*]}"
        if ! "$VENV/bin/pip" install --quiet "${faltando[@]}"; then
            aviso "não deu pra instalar tudo agora (sem internet?). Rode depois: opentars --setup"
        fi
    fi

    if "$VENV/bin/python3" -c "import tkinter" >/dev/null 2>&1; then
        msg "Interface gráfica disponível (tkinter OK)."
    else
        aviso "tkinter não encontrado — a interface gráfica (opentars-gui) não vai abrir."
        echo "        Instale com: sudo apt install python3-tk"
        echo "        O modo terminal (opentars) funciona normalmente."
    fi
else
    aviso "sem ambiente Python isolado, pulando dependências Python."
fi

# ------------------------------------------------------------------
# 3. Modelo ajudante (classificador leve) — baixa só se ainda não tiver.
# ------------------------------------------------------------------
servico_pronto=0
if command -v ollama >/dev/null 2>&1; then
    # Se o Ollama acabou de ser instalado, o serviço leva um instante pra subir.
    for _ in $(seq 1 10); do
        if ollama list >/dev/null 2>&1; then
            servico_pronto=1
            break
        fi
        sleep 2
    done

    if [ "$servico_pronto" -eq 0 ]; then
        aviso "o serviço do Ollama não respondeu a tempo — pulando o modelo ajudante."
        echo "        Rode depois: ollama pull $MODELO_AJUDANTE"
    elif ollama list 2>/dev/null | awk 'NR>1 {print $1}' | grep -qx "$MODELO_AJUDANTE"; then
        msg "Modelo ajudante '$MODELO_AJUDANTE' já está baixado — pulando."
    else
        msg "Baixando modelo ajudante '$MODELO_AJUDANTE' (~300 MB)..."
        if ollama pull "$MODELO_AJUDANTE"; then
            msg "'$MODELO_AJUDANTE' baixado com sucesso."
        else
            aviso "não deu pra baixar '$MODELO_AJUDANTE' agora. Rode depois: ollama pull $MODELO_AJUDANTE"
        fi
    fi
else
    aviso "Ollama não disponível — pulando o modelo ajudante."
fi

# ------------------------------------------------------------------
# Aviso final: sem nenhum modelo de conversa, o openTARS abre mas não
# tem com o que responder. Só avisa — a escolha do modelo é do usuário.
# ------------------------------------------------------------------
if [ "$servico_pronto" -eq 1 ]; then
    outros=$(ollama list 2>/dev/null | awk 'NR>1 {print $1}' | grep -vx "$MODELO_AJUDANTE" | wc -l)
    if [ "$outros" -eq 0 ]; then
        echo ""
        msg "Você ainda não tem nenhum modelo de conversa baixado."
        echo "        Baixe pelo menos um, por exemplo: ollama pull qwen3:8b"
    fi
fi

echo ""
echo "=== openTARS pronto! Abra pelo menu de aplicativos ou digite 'opentars' no terminal. ==="
echo ""

exit 0
