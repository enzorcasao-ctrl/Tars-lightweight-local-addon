#!/bin/bash
# Monta o .deb do openTARS a partir dos arquivos-fonte.
# Uso: bash empacotamento/build.sh   (gera dist/opentars_<versão>_all.deb)

set -euo pipefail

VERSAO="1.1.1"
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
FONTE="$RAIZ/empacotamento"
PKG="$RAIZ/build/opentars_${VERSAO}"
SAIDA="$RAIZ/dist"

rm -rf "$PKG"
mkdir -p "$PKG/DEBIAN" \
         "$PKG/usr/bin" \
         "$PKG/usr/share/opentars" \
         "$PKG/usr/share/applications" \
         "$PKG/usr/share/icons/hicolor/scalable/apps" \
         "$PKG/usr/share/doc/opentars" \
         "$SAIDA"

# Programa
install -m 644 "$RAIZ/tars.py"       "$PKG/usr/share/opentars/tars.py"
install -m 644 "$RAIZ/tars_gui.py"   "$PKG/usr/share/opentars/tars_gui.py"
install -m 755 "$FONTE/setup.sh"     "$PKG/usr/share/opentars/setup.sh"

# Comandos (+ atalhos com o nome antigo)
install -m 755 "$FONTE/bin/opentars"     "$PKG/usr/bin/opentars"
install -m 755 "$FONTE/bin/opentars-gui" "$PKG/usr/bin/opentars-gui"
ln -s opentars     "$PKG/usr/bin/tars"
ln -s opentars-gui "$PKG/usr/bin/tars-gui"

# Menu e ícone
install -m 644 "$FONTE/desktop/opentars.desktop"          "$PKG/usr/share/applications/"
install -m 644 "$FONTE/desktop/opentars-terminal.desktop" "$PKG/usr/share/applications/"
install -m 644 "$FONTE/icone/opentars.svg" "$PKG/usr/share/icons/hicolor/scalable/apps/opentars.svg"

# Documentação
install -m 644 "$FONTE/doc/copyright" "$PKG/usr/share/doc/opentars/copyright"
gzip -9n -c "$FONTE/doc/changelog" > "$PKG/usr/share/doc/opentars/changelog.gz"
chmod 644 "$PKG/usr/share/doc/opentars/changelog.gz"

# Controle
TAMANHO=$(du -sk --exclude=DEBIAN "$PKG" | cut -f1)
sed -e "s/@VERSAO@/$VERSAO/" -e "s/@TAMANHO@/$TAMANHO/" "$FONTE/debian/control" > "$PKG/DEBIAN/control"
install -m 755 "$FONTE/debian/postinst" "$PKG/DEBIAN/postinst"
install -m 755 "$FONTE/debian/postrm"   "$PKG/DEBIAN/postrm"

dpkg-deb --root-owner-group --build "$PKG" "$SAIDA/opentars_${VERSAO}_all.deb"
echo "Gerado: $SAIDA/opentars_${VERSAO}_all.deb"
