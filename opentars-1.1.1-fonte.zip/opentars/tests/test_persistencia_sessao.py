import os
import json
import tempfile

tmpfile = tempfile.mktemp(suffix=".json")
os.environ["TARS_ARQUIVO_SESSOES"] = tmpfile

from _util import carregar_tars
tars = carregar_tars()

# Simula uma conversa e salva
sessao = tars.obter_sessao("qwen3:8b")
sessao.append({"role": "user", "content": "oi"})
sessao.append({"role": "assistant", "content": "Olá!"})
sessao.append({"role": "user", "content": "ve minha tela", "images": ["BASE64ENORME..."]})
tars.salvar_sessoes()

assert os.path.exists(tmpfile)
bruto = json.loads(open(tmpfile).read())
assert "qwen3:8b" in bruto
assert not any("images" in m for m in bruto["qwen3:8b"]), "imagem nao deveria ser salva"
print("OK: sessao salva sem imagens:", bruto)

# Simula reiniciar o processo: carrega de novo
carregadas = tars.carregar_sessoes()
assert "qwen3:8b" in carregadas
assert carregadas["qwen3:8b"][0]["role"] == "system"
assert carregadas["qwen3:8b"][0]["content"] == tars.SYSTEM_PROMPT
textos = [m["content"] for m in carregadas["qwen3:8b"] if m["role"] == "user"]
assert "oi" in textos
print("OK: sessao recarregada com system prompt atual e historico preservado")

# /limpar apaga
tars.sessoes.update(carregadas)
tars.limpar_sessao("qwen3:8b")
assert "qwen3:8b" not in tars.sessoes
carregadas2 = tars.carregar_sessoes()
assert "qwen3:8b" not in carregadas2
print("OK: /limpar remove o historico do disco tambem")

os.remove(tmpfile)
print("\nTUDO OK.")
