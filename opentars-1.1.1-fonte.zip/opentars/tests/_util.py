"""Utilitário compartilhado pelos testes: carrega tars.py isolado, sem
precisar dos pacotes de sistema (pyautogui, psutil) instalados — eles
são só usados pra controlar mouse/teclado e ler CPU/RAM, nada disso é
necessário pra testar a lógica (seleção de modelo, detecção de tarefa,
resolução de app/site, etc).

Uso, em qualquer test_*.py desta pasta:

    from _util import carregar_tars
    tars = carregar_tars()
"""

import importlib.util
import os
import sys
import types

CAMINHO_TARS = os.path.join(os.path.dirname(__file__), "..", "tars.py")


def carregar_tars():
    if "pyautogui" not in sys.modules:
        sys.modules["pyautogui"] = types.ModuleType("pyautogui")

    if "psutil" not in sys.modules:
        stub = types.ModuleType("psutil")
        stub.process_iter = lambda *a, **k: []
        sys.modules["psutil"] = stub

    spec = importlib.util.spec_from_file_location("tars", CAMINHO_TARS)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo
