"""Seletor de modelo da interface gráfica.

Bug: listar_modelos_instalados() devolve um set, e o ttk.Combobox não
entende set — virava UM item só com o texto do set inteiro
("'mistral-small3.2:24b', 'gemma3:1b'..."), e escolher esse item fixava
um "modelo" inexistente.

Precisa de tkinter e de um display (ex: Xvfb); sem isso, é pulado.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import tkinter  # noqa: F401
except ImportError:
    print("PULADO: tkinter não disponível")
    sys.exit(0)

if not os.environ.get("DISPLAY"):
    print("PULADO: sem DISPLAY")
    sys.exit(0)

os.environ.setdefault("XAUTHORITY", "/dev/null")

try:
    tkinter.Tk().destroy()
except tkinter.TclError as e:
    print(f"PULADO: display inacessível ({e})")
    sys.exit(0)

import tars as core  # noqa: E402

INSTALADOS = {"mistral-small3.2:24b", "gemma3:1b", "qwen3:0.6b", "gemma3:270m"}
core.listar_modelos_instalados = lambda forcar=False: set(INSTALADOS)
core.tela_inicial = lambda: None
carregados = []
core._carregar_em_segundo_plano = lambda m: carregados.append(m)

import tars_gui  # noqa: E402

out = sys.__stdout__
resultado = {"ok": False, "erro": None}
j = tars_gui.JanelaTars()


def teste():
    try:
        v = tuple(j.combo_modelo["values"])
        assert sorted(v) == sorted(INSTALADOS), f"valores do combobox: {v!r}"
        assert str(j.combo_modelo.cget("state")) == "disabled"

        # AUTO -> MANUAL já fixa um modelo real
        j.var_modo.set("MANUAL")
        j._ao_trocar_modo()
        assert core.modo_modelo == "MANUAL" and core.modelo_manual in INSTALADOS
        assert str(j.combo_modelo.cget("state")) == "readonly"

        # escolher outro modelo na lista
        j.var_modelo.set("mistral-small3.2:24b")
        j._ao_trocar_modelo()
        assert core.modelo_manual == "mistral-small3.2:24b"
        assert core.escolher_modelo("oi") == "mistral-small3.2:24b"
        assert "mistral-small3.2:24b" in carregados

        # "/modelo auto" digitado na caixa de texto sincroniza os seletores
        core.interpretar_comando_modelo("/modelo auto")
        j._popular_modelos()
        assert j.var_modo.get() == "AUTO" and j.var_modelo.get() == ""
        assert str(j.combo_modelo.cget("state")) == "disabled"

        # "/modelo <nome>" digitado também
        core.interpretar_comando_modelo("/modelo qwen3:0.6b")
        j._popular_modelos()
        assert j.var_modo.get() == "MANUAL" and j.var_modelo.get() == "qwen3:0.6b"

        resultado["ok"] = True
    except Exception as e:
        resultado["erro"] = e
    finally:
        j.quit()


j.after(800, teste)
j.mainloop()
sys.stdout = sys.__stdout__

if resultado["ok"]:
    print("OK: seletor de modelo da GUI", file=out)
    sys.exit(0)

print(f"FALHOU: {resultado['erro']!r}", file=out)
sys.exit(1)
