#!/usr/bin/env python3
"""
Interface gráfica simples pro TARS — mesma lógica de sempre (Ollama,
escolha automática de modelo, ferramentas de desktop), só que numa
janela em vez do terminal.

Usa só Tkinter (já vem com o Python, nenhuma dependência nova) e
reaproveita 100% do "cérebro" que já existe em tars.py: nenhuma regra
de categorização, prompt ou ferramenta foi duplicada aqui — esta
janela só chama as mesmas funções que o modo terminal chama, e mostra
a mesma saída (cores incluídas) numa caixa de texto em vez do stdout.
"""

import os
import queue
import re
import sys
import threading
import tkinter as tk
from tkinter import scrolledtext, ttk

import tars as core


# ============================================================
# CORES: reaproveita os códigos ANSI que tars.py já usa (Cor.*)
# e traduz pra cores de verdade na caixa de texto do Tkinter —
# assim a saída na janela fica igual à do terminal, sem duplicar
# nenhuma regra de "quando colorir o quê".
# ============================================================

_ANSI_PARA_TAG = {
    "0": None,          # reset
    "1": "negrito",
    "30": "preto", "31": "vermelho", "32": "verde", "33": "amarelo",
    "34": "azul", "35": "magenta", "36": "ciano", "37": "branco",
    "90": "cinza",
}

_CORES_TAG = {
    "cinza": "#8a8f98",
    "vermelho": "#ff6b6b",
    "verde": "#5fd97a",
    "amarelo": "#ffd166",
    "azul": "#5aa8ff",
    "magenta": "#d68cff",
    "ciano": "#5fe0d0",
    "preto": "#1e1e1e",
    "branco": "#e6e6e6",
}

_PADRAO_ANSI = re.compile(r"\033\[(\d+)m")


def _inserir_com_ansi(widget, texto):
    """Insere texto com códigos ANSI (\\033[Nm) numa Text widget do
    Tkinter, convertendo cada código na tag de cor correspondente —
    igual ao terminal, sem precisar reescrever nenhuma regra de cor."""

    tags_ativas = set()
    pos = 0

    for m in _PADRAO_ANSI.finditer(texto):
        pedaco = texto[pos:m.start()]
        if pedaco:
            widget.insert(tk.END, pedaco, tuple(tags_ativas))

        codigo = m.group(1)
        if codigo == "0":
            tags_ativas.clear()
        else:
            tag = _ANSI_PARA_TAG.get(codigo)
            if tag:
                tags_ativas.add(tag)

        pos = m.end()

    resto = texto[pos:]
    if resto:
        widget.insert(tk.END, resto, tuple(tags_ativas))


class _EscritorParaFila:
    """Substitui sys.stdout durante uma chamada ao "cérebro" do TARS:
    em vez de imprimir no terminal (que essa janela não tem), empilha
    cada pedaço de texto numa fila que a thread principal do Tkinter
    lê e mostra na caixa de texto. Isso evita reescrever qualquer
    função de tars.py só pra ela "devolver" texto em vez de imprimir —
    o mesmo código de sempre continua rodando sem alteração nenhuma."""

    def __init__(self, fila):
        self.fila = fila

    def write(self, texto):
        if texto:
            self.fila.put(texto)

    def flush(self):
        pass


class JanelaTars(tk.Tk):

    def __init__(self):
        super().__init__(className="opentars")

        self.title("openTARS")
        self.geometry("880x620")
        self.minsize(560, 400)
        self.configure(bg="#1e1e1e")

        self._fila_saida = queue.Queue()
        self._ocupado = False

        self._montar_widgets()
        self._configurar_tags()

        self.protocol("WM_DELETE_WINDOW", self._ao_fechar)

        # Redireciona sys.stdout pra fila DESDE JÁ, e pro resto da
        # vida da janela — não só durante cada chamada. Isso importa
        # porque coisas como o "aquecimento" de modelo em segundo
        # plano (_carregar_em_segundo_plano) rodam numa thread própria
        # que só termina bem depois de tela_inicial() já ter
        # retornado; se a troca de stdout durasse só enquanto essa
        # função está rodando, a mensagem desse aquecimento (que
        # aparece depois) iria pro terminal de verdade — que essa
        # janela nem tem — e se perderia sem ninguém ver.
        self._stdout_original = sys.stdout
        sys.stdout = _EscritorParaFila(self._fila_saida)

        # Carrega o catálogo de modelos e mostra a tela inicial (a
        # MESMA função usada no terminal) numa thread separada, pra
        # não travar a janela enquanto o Ollama responde.
        self._rodar_em_segundo_plano(core.tela_inicial, apos=self._popular_modelos)
        self._puxar_fila()

    # ------------------------------------------------------------
    # Montagem da janela
    # ------------------------------------------------------------

    def _montar_widgets(self):

        topo = tk.Frame(self, bg="#1e1e1e")
        topo.pack(fill=tk.X, padx=10, pady=(10, 4))

        tk.Label(
            topo, text="Modo:", bg="#1e1e1e", fg="#e6e6e6",
            font=("Sans", 10),
        ).pack(side=tk.LEFT)

        self.var_modo = tk.StringVar(value="AUTO")
        combo_modo = ttk.Combobox(
            topo, textvariable=self.var_modo, values=["AUTO", "MANUAL"],
            state="readonly", width=8,
        )
        combo_modo.pack(side=tk.LEFT, padx=(4, 12))
        combo_modo.bind("<<ComboboxSelected>>", self._ao_trocar_modo)

        tk.Label(
            topo, text="Modelo:", bg="#1e1e1e", fg="#e6e6e6",
            font=("Sans", 10),
        ).pack(side=tk.LEFT)

        self.var_modelo = tk.StringVar(value="")
        self.combo_modelo = ttk.Combobox(
            topo, textvariable=self.var_modelo, state="disabled", width=28,
        )
        self.combo_modelo.pack(side=tk.LEFT, padx=(4, 12))
        self.combo_modelo.bind("<<ComboboxSelected>>", self._ao_trocar_modelo)

        tk.Button(
            topo, text="Limpar conversa", command=self._limpar_conversa,
            bg="#333", fg="#e6e6e6", relief=tk.FLAT, padx=8,
        ).pack(side=tk.RIGHT)

        self.texto = scrolledtext.ScrolledText(
            self, wrap=tk.WORD, bg="#1e1e1e", fg="#e6e6e6",
            insertbackground="#e6e6e6", font=("Monospace", 11),
            state=tk.DISABLED, borderwidth=0, padx=10, pady=8,
        )
        self.texto.pack(fill=tk.BOTH, expand=True, padx=10, pady=4)

        rodape = tk.Frame(self, bg="#1e1e1e")
        rodape.pack(fill=tk.X, padx=10, pady=(4, 10))

        self.entrada = tk.Entry(
            rodape, bg="#2b2b2b", fg="#e6e6e6", insertbackground="#e6e6e6",
            font=("Sans", 11), relief=tk.FLAT,
        )
        self.entrada.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=6, padx=(0, 8))
        self.entrada.bind("<Return>", self._ao_enviar)
        self.entrada.focus_set()

        self.botao_enviar = tk.Button(
            rodape, text="Enviar", command=self._ao_enviar,
            bg="#3a6ff7", fg="white", relief=tk.FLAT, padx=16,
        )
        self.botao_enviar.pack(side=tk.RIGHT)

    def _configurar_tags(self):
        self.texto.tag_configure("negrito", font=("Monospace", 11, "bold"))
        for nome, hexcor in _CORES_TAG.items():
            self.texto.tag_configure(nome, foreground=hexcor)

    # ------------------------------------------------------------
    # Fila de saída (thread de trabalho -> thread da UI)
    # ------------------------------------------------------------

    def _puxar_fila(self):
        try:
            while True:
                pedaco = self._fila_saida.get_nowait()
                self.texto.configure(state=tk.NORMAL)
                _inserir_com_ansi(self.texto, pedaco)
                self.texto.see(tk.END)
                self.texto.configure(state=tk.DISABLED)
        except queue.Empty:
            pass
        finally:
            self.after(60, self._puxar_fila)

    def _rodar_em_segundo_plano(self, funcao, *args, apos=None):
        """Roda uma função do "cérebro" do TARS numa thread separada
        (sys.stdout já está redirecionado pra fila desde o __init__,
        então tudo que a função imprimir aparece na caixa de texto
        normalmente, mesmo se ela mesma disparar outras threads).
        Desabilita o envio de novas mensagens enquanto estiver
        ocupado, pra nunca ter duas conversas com o Ollama ao mesmo
        tempo se pisando."""

        self._ocupado = True
        self.botao_enviar.configure(state=tk.DISABLED)

        def alvo():
            try:
                funcao(*args)
            except Exception as e:
                self._fila_saida.put(f"\n[TARS] erro inesperado: {e}\n")
            finally:
                self._ocupado = False
                self.after(0, lambda: self.botao_enviar.configure(state=tk.NORMAL))
                if apos:
                    self.after(0, apos)

        threading.Thread(target=alvo, daemon=True).start()

    # ------------------------------------------------------------
    # Ações da interface
    # ------------------------------------------------------------

    def _popular_modelos(self):
        """Atualiza os dois seletores a partir do estado real do núcleo
        (core.modo_modelo / core.modelo_manual). Roda depois de cada
        mensagem, então um "/modelo qwen3:8b" ou "/modelo auto" digitado
        na caixa de texto também aparece refletido aqui em cima."""
        try:
            # listar_modelos_instalados() devolve um set; o Combobox só
            # entende lista/tupla — um set vira UM item só com o texto
            # do set inteiro ("'mistral...', 'gemma3...'").
            instalados = sorted(core.listar_modelos_instalados())
        except Exception:
            instalados = []

        self.combo_modelo["values"] = instalados

        self.var_modo.set(core.modo_modelo)
        if core.modo_modelo == "MANUAL":
            self.combo_modelo.configure(state="readonly")
            self.var_modelo.set(core.modelo_manual or "")
        else:
            self.combo_modelo.configure(state="disabled")
            self.var_modelo.set("")

    def _selecionar_manual(self, modelo):
        core.modo_modelo = "MANUAL"
        core.modelo_manual = modelo
        self.var_modelo.set(modelo)
        self._fila_saida.put(
            core.c(f"\n✓ Modelo manual selecionado: {modelo}\n", core.Cor.VERDE)
        )
        # Já começa a carregar, como o "/modelo <nome>" do terminal faz.
        try:
            core._carregar_em_segundo_plano(modelo)
        except Exception:
            pass

    def _ao_trocar_modo(self, _evento=None):
        novo_modo = self.var_modo.get()

        if novo_modo == "AUTO":
            core.modo_modelo = "AUTO"
            core.modelo_manual = None
            self.var_modelo.set("")
            self.combo_modelo.configure(state="disabled")
            self._fila_saida.put(core.c("\n✓ Modo AUTO ativado.\n", core.Cor.VERDE))
            return

        # MANUAL sem modelo escolhido faria o núcleo cair de volta na
        # escolha automática em silêncio. Então já fixa um: o que está
        # carregado agora, ou o primeiro da lista.
        self.combo_modelo.configure(state="readonly")
        instalados = list(self.combo_modelo["values"])
        if not instalados:
            core.modo_modelo = "MANUAL"
            self._fila_saida.put(core.c(
                "\n⚠ Nenhum modelo instalado encontrado. Baixe um com: ollama pull qwen3:8b\n",
                core.Cor.AMARELO,
            ))
            return

        atual = core.modelo_manual or core.modelo_atual
        self._selecionar_manual(atual if atual in instalados else instalados[0])

    def _ao_trocar_modelo(self, _evento=None):
        modelo = self.var_modelo.get()
        if modelo and modelo != core.modelo_manual:
            self._selecionar_manual(modelo)

    def _limpar_conversa(self):
        self.texto.configure(state=tk.NORMAL)
        self.texto.delete("1.0", tk.END)
        self.texto.configure(state=tk.DISABLED)
        # reaproveita o mesmo comando "/limpar" do modo terminal, que
        # já zera o histórico em disco e em memória certinho.
        self._rodar_em_segundo_plano(core.interpretar_comando_modelo, "/limpar")

    def _ao_enviar(self, _evento=None):
        if self._ocupado:
            return

        texto = self.entrada.get().strip()
        if not texto:
            return

        self.entrada.delete(0, tk.END)
        self._fila_saida.put(f"\nVocê › {texto}\n")

        def processar():
            if core.interpretar_comando_modelo(texto):
                return

            tarefa = core.detectar_tarefa(texto) if core.modo_modelo == "AUTO" else None
            modelo = core.escolher_modelo(texto, tarefa=tarefa)

            if core.modo_modelo == "AUTO":
                print(core.c(f"\n[AUTO] tarefa detectada: {tarefa} → modelo: {modelo}", core.Cor.AZUL))
            else:
                print(core.c(f"\n[MANUAL] modelo fixado: {modelo}", core.Cor.AMARELO))

            core.perguntar_modelo(modelo, texto, tarefa=tarefa)
            core.salvar_sessoes()

        self._rodar_em_segundo_plano(processar, apos=self._popular_modelos)

    def _ao_fechar(self):
        try:
            core.salvar_sessoes()
            core.encerrar_todas_ias()
        except Exception:
            pass
        sys.stdout = self._stdout_original
        self.destroy()


def main():
    # Em algumas distros o Tkinter precisa de um tema explícito pra
    # não ficar com uma cara datada — "clam" funciona em qualquer
    # ambiente sem depender de nenhum tema instalado à parte.
    app = JanelaTars()
    style = ttk.Style(app)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    app.mainloop()


if __name__ == "__main__":
    main()
