"""3.0 na janela: botão Voz (menu, Falar agora, Ouvir TARS), pedido falado
responde falando, rotina na hora entra como pedido, plano aparece.

Precisa de tkinter e de um display (ex: Xvfb); sem isso, é pulado."""

import os
import sys
import tempfile
import threading

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("XDG_CONFIG_HOME", tempfile.mkdtemp(prefix="opentars-config-"))
import _util  # noqa: E402,F401

try:
    import tkinter  # noqa: F401
except ImportError:
    print("PULADO: tkinter não disponível")
    sys.exit(0)
if not os.environ.get("DISPLAY"):
    print("PULADO: sem DISPLAY")
    sys.exit(0)
os.environ.setdefault("XAUTHORITY", "/dev/null")
try:
    tkinter.Tk().destroy()
except tkinter.TclError as e:
    print(f"PULADO: display inacessível ({e})")
    sys.exit(0)

import tars as core  # noqa: E402

core.listar_modelos_instalados = lambda forcar=False: {"qwen3:4b"}
core.iniciar_conversa = lambda: 0
core.ollama_online = lambda: True
core.catalogar_modelos = lambda forcar=False: {"qwen3:4b": {"tag": "qwen3:4b", "familia": "qwen3", "categoria": "geral",
                                                            "parametros_b": 4.0, "capacidades": {"tools"},
                                                            "capacidades_conhecidas": True}}
core.avisos_de_ambiente = lambda: []
core.aquecer_ajudante = lambda: None
core._carregar_em_segundo_plano = lambda m: None
pedidos, falados = [], []


def processar(texto):
    pedidos.append(texto)
    core.emitir("plano", etapas=["abre o gmail", "abre o spotify"]) if " e " in texto else None
    return f"Feito: {texto}"


core.processar_mensagem = processar


class FaladorFalso:
    def __init__(self):
        self.falando = threading.Event()

    def falar(self, texto, idioma, ao_terminar=None):
        falados.append(texto)
        if ao_terminar:
            ao_terminar()
        return True

    def parar(self):
        pass


falador = FaladorFalso()
core.falador = lambda: falador

import tars_gui  # noqa: E402

out = sys.__stdout__
resultado = {"ok": False, "erro": None}
j = tars_gui.JanelaTars()


def esperar_livre(depois, tentativas=60):
    if j.ocupado and tentativas:
        j.after(100, lambda: esperar_livre(depois, tentativas - 1))
    else:
        j.after(150, depois)


def etapa1():
    # voz não instalada: Ctrl+M avisa o que falta; o menu abre
    core.o_que_falta_voz = lambda: ["faster-whisper", "gravador"]
    j._falar_agora()
    texto = j.texto.get("1.0", "end")
    assert "faster-whisper" in texto and "alsa-utils" in texto and "--instalar-voz" in texto, texto[-300:]
    j._menu_voz()
    j.after(100, lambda: (j.focus_set(), j.event_generate("<Escape>")))
    out.write("OK: sem a voz instalada, Ctrl+M diz o que falta e o menu Voz oferece instalar\n")

    # voz pronta: "Ouvir TARS" liga um Ouvinte; um pedido falado entra e a resposta é falada
    core.o_que_falta_voz = lambda: []
    criados = []

    class OuvinteFalso:
        def __init__(self, ao_pedido, idioma, modo="ativacao", ao_estado=None, falador=None):
            self.ao_pedido, self.modo, self.ao_estado = ao_pedido, modo, ao_estado
            self.ativo_ = False
            self.chamado_ate = 0
            criados.append(self)

        @property
        def ativo(self):
            return self.ativo_

        def iniciar(self):
            self.ativo_ = True
            self.ao_estado("ouvindo")

        def parar(self):
            self.ativo_ = False

    core.voz_lib.Ouvinte = OuvinteFalso
    j._ligar_ativacao(True)
    assert core.config_voz()["ativacao"] and "●" in j.botao_voz._texto
    ouv = criados[-1]
    j.after(200, lambda: ouv.ao_pedido("abre o firefox"))
    j.after(300, lambda: esperar_livre(etapa2))


def etapa2():
    assert pedidos[-1] == "abre o firefox" and falados[-1] == "Feito: abre o firefox", (pedidos, falados)
    assert "Ouvindo" in j.status_voz.cget("text"), j.status_voz.cget("text")
    # Ctrl+M com o "Ouvir TARS" ligado: o próximo trecho é o pedido
    j._falar_agora()
    assert j._ouvinte.chamado_ate > 0 and "Pode falar" in j.status_voz.cget("text")
    out.write("OK: 'Ouvir TARS' liga; pedido falado entra na conversa e a resposta é falada; Ctrl+M pula o 'TARS'\n")

    # pedido digitado: não fala (responder falando desligado)
    n = len(falados)
    j.enviar("qual a capital do chile")
    esperar_livre(lambda: etapa3(n))


def etapa3(n):
    assert len(falados) == n, "digitado + 'responder falando' desligado: fica quieto"
    # rotina na hora: entra como pedido, com aviso na conversa; o plano aparece
    j._rotina_venceu({"id": "abc", "pedido": "abre o gmail e o spotify"})
    esperar_livre(etapa4)


def etapa4():
    texto = j.texto.get("1.0", "end")
    assert pedidos[-1] == "abre o gmail e o spotify" and "Rotina agendada: abre o gmail e o spotify" in texto
    assert "Plano:" in texto and "2. abre o spotify" in texto, texto[-400:]
    j._ligar_ativacao(False)
    assert not core.config_voz()["ativacao"] and j._ouvinte is None
    out.write("OK: rotina na hora vira pedido (com aviso) e o plano de 2 etapas aparece na conversa\n")
    resultado["ok"] = True
    j._ao_fechar()


def seguro(funcao):
    def rodar():
        try:
            funcao()
        except Exception as e:  # noqa: BLE001
            import traceback
            resultado["erro"] = traceback.format_exc()
            j._ao_fechar()
    return rodar


for nome in ("etapa1", "etapa2", "etapa3", "etapa4"):
    original = globals()[nome]
    globals()[nome] = (lambda f: (lambda *a: seguro(lambda: f(*a))()))(original)

j.after(800, etapa1)
j.mainloop()
if resultado["erro"]:
    out.write(resultado["erro"])
    sys.exit(1)
assert resultado["ok"]
out.write("\nTUDO OK.\n")
