"""3.0: servidor compatível com a OpenAI (vLLM, LM Studio, llama.cpp) e
mouse/teclado no Wayland pelo ydotool.

Sobe um servidor HTTP de verdade (em thread) que fala /v1/models e
/v1/chat/completions com streaming SSE, mandando a chamada de ferramenta
em pedaços como o vLLM faz."""

import json
import os
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

os.environ["TARS_IDIOMA"] = "pt_BR"
from _util import carregar_tars  # noqa: E402

tars = carregar_tars()
api = tars.api

# ------------------------------------------------------------
# 1. Conversão da conversa (Ollama -> OpenAI)
# ------------------------------------------------------------
conversa = [
    {"role": "system", "content": "regras"},
    {"role": "user", "content": "abre a calculadora e tira um print"},
    {"role": "assistant", "content": "", "tool_calls": [
        {"function": {"name": "open_application", "arguments": {"app": "calculadora"}}},
        {"function": {"name": "take_screenshot", "arguments": {}}}]},
    {"role": "tool", "tool_name": "open_application", "content": "{\"success\": true}"},
    {"role": "tool", "tool_name": "take_screenshot", "content": "{\"success\": true}"},
    {"role": "user", "content": "[print]", "images": ["QUJD"]},
    {"role": "tool", "content": "órfão"},
]
o = api.para_openai(conversa)
assert o[2]["tool_calls"][0]["id"] == "call_1" and o[2]["tool_calls"][1]["id"] == "call_2"
assert o[2]["tool_calls"][0]["function"]["arguments"] == '{"app": "calculadora"}'
assert o[3] == {"role": "tool", "tool_call_id": "call_1", "content": "{\"success\": true}"}
assert o[4]["tool_call_id"] == "call_2"
assert o[5]["content"][1] == {"type": "image_url", "image_url": {"url": "data:image/png;base64,QUJD"}}
assert o[6]["role"] == "user" and "órfão" in o[6]["content"]
assert api.normalizar_url("localhost:1234") == "http://localhost:1234/v1"
assert api.normalizar_url("http://x:8000/v1/") == "http://x:8000/v1"
print("OK: conversa do Ollama vira formato OpenAI (ids das chamadas, argumentos em texto, imagens)")

# ------------------------------------------------------------
# 2. Servidor falso de verdade
# ------------------------------------------------------------
recebidos = []


def sse(obj):
    return f"data: {json.dumps(obj)}\n\n".encode()


class Servidor(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path == "/v1/models":
            corpo = json.dumps({"data": [{"id": "Qwen/Qwen2.5-7B-Instruct"}, {"id": "nomic-embed-text"},
                                         {"id": "qwen2.5-vl-3b"}]}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(corpo)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        corpo = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        recebidos.append((corpo, self.headers.get("Authorization")))
        if not corpo.get("stream"):
            texto = '{"categoria": "acao"}' if corpo.get("response_format") else "ok"
            dados = json.dumps({"choices": [{"message": {"role": "assistant", "content": texto}}]}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(dados)
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        ultima = corpo["messages"][-1]
        if ultima["role"] == "tool":
            partes = [sse({"choices": [{"delta": {"reasoning_content": "já abriu"}}]}),
                      sse({"choices": [{"delta": {"content": "Abri a "}}]}),
                      sse({"choices": [{"delta": {"content": "calculadora."}, "finish_reason": "stop"}]})]
        else:
            partes = [
                sse({"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "x1", "type": "function",
                                                            "function": {"name": "open_", "arguments": ""}}]}}]}),
                sse({"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"name": "application",
                                                                                     "arguments": "{\"app\": "}}]}}]}),
                sse({"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": "\"calculadora\"}"}}]},
                                  "finish_reason": "tool_calls"}]}),
            ]
        for p in partes + [b"data: [DONE]\n\n"]:
            self.wfile.write(p)
            self.wfile.flush()


http = HTTPServer(("127.0.0.1", 0), Servidor)
threading.Thread(target=http.serve_forever, daemon=True).start()
url = f"http://127.0.0.1:{http.server_port}"
tars.i18n.salvar_config(servidor_api=api.normalizar_url(url), chave_api="segredo")

assert tars.listar_modelos_api(forcar=True) == {"api:Qwen/Qwen2.5-7B-Instruct", "api:qwen2.5-vl-3b"}
tars.listar_modelos_instalados = lambda forcar=False: set()   # sem Ollama nenhum
cat = tars.catalogar_modelos(forcar=True)
q = cat["api:Qwen/Qwen2.5-7B-Instruct"]
assert q["parametros_b"] == 7.0 and "tools" in q["capacidades"] and q["vram_estimado_gb"] is None
assert "vision" in cat["api:qwen2.5-vl-3b"]["capacidades"]
assert tars.carregar_modelo("api:Qwen/Qwen2.5-7B-Instruct") is True
assert tars.carregar_modelo("api:nao-existe") is False
print(f"OK: {url}/v1/models -> catálogo com api:<nome> (7B pelo nome, visão pelo nome, sem embeddings)")

# ------------------------------------------------------------
# 3. Conversa com ferramenta, de ponta a ponta
# ------------------------------------------------------------
eventos = []
tars.definir_ouvinte_saida(lambda tipo, dados: eventos.append((tipo, dados)))
tars.contexto_ia = lambda: 8192
tars.modo_modelo = "MANUAL"
tars.listar_janelas_x = lambda: None
abertos = []
tars._DISPATCH_FERRAMENTAS["open_application"] = lambda a: abertos.append(a["app"]) or {
    "sucesso": True, "mensagem": "SUCCESS: opened."}
tars.conversa = []
resposta = tars.perguntar_modelo("api:Qwen/Qwen2.5-7B-Instruct", "abre a calculadora", tarefa="acao")
assert resposta == "Abri a calculadora." and abertos == ["calculadora"], (resposta, abertos)
corpo, chave = recebidos[-1]
assert chave == "Bearer segredo" and corpo["model"] == "Qwen/Qwen2.5-7B-Instruct"
assert corpo["messages"][-2]["tool_calls"][0]["function"]["name"] == "open_application"
assert corpo["messages"][-1]["role"] == "tool" and corpo["messages"][-1]["tool_call_id"] == "call_1"
assert any(tipo == "resposta" for tipo, _ in eventos)
assert not any(tipo == "pensamento" for tipo, _ in eventos), "pedido simples: o raciocínio não aparece (pensar=False)"
print("OK: chamada de ferramenta em pedaços (streaming) vira open_application(calculadora); a resposta aparece na hora")

texto = tars._chat_unico("api:Qwen/Qwen2.5-7B-Instruct", "classifique", formato={"type": "object"})
assert texto == '{"categoria": "acao"}' and recebidos[-1][0]["response_format"]["type"] == "json_schema"
print("OK: pergunta curta com formato JSON usa response_format do servidor")

tars.i18n.salvar_config(servidor_api="")
assert tars.listar_modelos_api(forcar=True) == set()
http.shutdown()

# ------------------------------------------------------------
# 4. Wayland: ydotool no lugar do pyautogui
# ------------------------------------------------------------
wl = tars.wayland
comandos = []
p = wl.PyautoguiYdotool((1920, 1080), executar=comandos.append)
p.click(x=100, y=200)
p.mouseDown(10, 20)
p.moveTo(300, 40)
p.mouseUp(300, 40)
p.hotkey("ctrl", "v")
p.press("enter")
p.write("olá mundo")
p.scroll(3)
assert comandos[0] == ["mousemove", "--absolute", "-x", "100", "-y", "200"] and comandos[1] == ["click", "0xc0"]
assert ["click", "0x40"] in comandos and ["click", "0x80"] in comandos
assert ["key", "29:1", "47:1", "47:0", "29:0"] in comandos and ["key", "28:1", "28:0"] in comandos
assert ["type", "--", "olá mundo"] in comandos and ["mousemove", "--wheel", "-x", "0", "-y", "-3"] in comandos
assert p.position() == (300, 40) and p.size() == (1920, 1080)
comandos.clear()
p.moveTo(500, 500)
p.mouseDown(500, 500)
p.moveTo(520, 510)
p.moveTo(40, 40)
p.mouseUp(40, 40)
p.moveTo(60, 60)
moves = [c for c in comandos if c[0] == "mousemove"]
assert moves[0][1] == "--absolute" and moves[-1][1] == "--absolute"
assert moves[2:5] == [["mousemove", "-x", "20", "-y", "10"], ["mousemove", "-x", "-480", "-y", "-470"],
                      ["mousemove", "-x", "0", "-y", "0"]], moves


class Saida:
    def __init__(self, texto):
        self.stdout, self.stderr = texto, ""


antigo = lambda *a, **k: Saida("Usage: mousemove [OPTION...] <x> <y>")  # noqa: E731
novo = lambda *a, **k: Saida("Usage: ydotool mousemove [OPTION...] [--absolute] -x <xpos> -y <ypos>")  # noqa: E731
tars_wl_which = wl.shutil.which
wl.shutil.which = lambda p: "/usr/bin/ydotool"
assert "too old" in wl.motivo_indisponivel(antigo)
wl._socket = lambda: None
assert "ydotoold" in wl.motivo_indisponivel(novo)
wl._socket = lambda: "/tmp/.ydotool_socket"
assert wl.motivo_indisponivel(novo) is None
wl.shutil.which = lambda p: None
assert "not installed" in wl.motivo_indisponivel(novo)
wl.shutil.which = tars_wl_which
print("OK: Wayland com ydotool 1.x: clique, arrasto, atalho (ctrl+v), Enter, texto e rolagem; ydotool velho ou sem ydotoold é detectado")

print("\nTUDO OK.")
