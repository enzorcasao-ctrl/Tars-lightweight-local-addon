"""3.0 Miller: o "opentars" sozinho confere o ambiente e diz onde conversar
(a conversa fica na janela e na voz); os argumentos continuam funcionando."""

import io
import contextlib
import sys
import types

from _util import carregar_tars

tars = carregar_tars()

chamado = {}
falso = types.ModuleType("tars_autoteste")
falso.executar = lambda nucleo, completo=False: chamado.update(completo=completo) or 0
sys.modules["tars_autoteste"] = falso

sys.argv = ["opentars"]
saida = io.StringIO()
with contextlib.redirect_stdout(saida):
    try:
        tars.main()
    except SystemExit as e:
        codigo = e.code
assert codigo == 0 and chamado == {"completo": False}, (codigo, chamado)
assert "opentars-gui" in saida.getvalue() and "--voz" in saida.getvalue(), saida.getvalue()
print("OK: 'opentars' sozinho roda o diagnóstico e aponta pra janela e pra voz")

sys.argv = ["opentars", "--version"]
saida = io.StringIO()
with contextlib.redirect_stdout(saida):
    tars.main()
assert "3.0 Miller" in saida.getvalue(), saida.getvalue()
sys.argv = ["opentars", "--help"]
saida = io.StringIO()
with contextlib.redirect_stdout(saida):
    tars.main()
assert "--explicar" in saida.getvalue() and "conversa no terminal" not in saida.getvalue()
assert not hasattr(tars, "tela_inicial") and not hasattr(tars, "MODELO_AJUDANTE_ANTIGO")
assert not {"move_mouse", "get_screen_size", "get_mouse_position", "get_current_directory"} & set(tars._DISPATCH_FERRAMENTAS)
print("OK: --version e --help continuam; conversa no terminal, ferramentas aposentadas e restos do gemma3:270m saíram")

print("\nTUDO OK.")
