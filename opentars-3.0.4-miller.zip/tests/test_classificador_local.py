"""2.9.1: classificador local e escolha da tarefa sem depender do ajudante.

Num PC real, o ajudante (qwen2.5:0.5b) respondia "tecnico" pra 29 de 31
frases do --avaliar-classificador. Aqui:
  - as frases de treino não repetem (nem quase repetem) as de teste;
  - o classificador local acerta, sozinho, a maior parte das frases que
    ele nunca viu, e quando diz que está seguro quase não erra;
  - com um ajudante "quebrado" (sempre fix_linux_problem), o modo AUTO
    ainda acerta a grande maioria;
  - ajudante que responde sempre a mesma coisa (ou reprovado na
    avaliação) deixa de ser consultado;
  - os casos que davam errado: "entra no gmail pra mim", "e aí, como você
    está hoje?"."""

import json
import os
import tempfile
import time
from pathlib import Path

os.environ["TARS_IDIOMA"] = "pt_BR"
from _util import carregar_tars  # noqa: E402
from frases_classificador import FRASES  # noqa: E402

tars = carregar_tars()
import tars_classificador as cl  # noqa: E402
import tars_escolha as escolha  # noqa: E402
from tars_exemplos import EXEMPLOS  # noqa: E402
from tars_exemplos_mais import MAIS  # noqa: E402

RAIZ = Path(__file__).resolve().parent.parent
AVALIACAO = {l: [tuple(p) for p in json.loads((RAIZ / "idiomas" / f"{l}.json").read_text(encoding="utf-8"))["avaliacao"]]
             for l in sorted(p.stem for p in (RAIZ / "idiomas").glob("*.json"))}
TESTE = list(FRASES) + [p for lista in AVALIACAO.values() for p in lista]


def chave(frase):
    return " ".join(cl.tokens(cl.normalizar(frase)))


def palavras(frase):
    return set(cl.tokens(cl.normalizar(frase))) - cl.VAZIAS


# ------------------------------------------------------------
# 1. Treino separado do teste
# ------------------------------------------------------------
treino = {chave(f): c for c, lista in EXEMPLOS.items() for f in lista}
repetidas = [f for f, _ in TESTE if chave(f) in treino]
assert not repetidas, f"frases de teste dentro dos exemplos: {repetidas}"
quase = []
for c, lista in MAIS.items():
    for f in lista:
        for g, _ in TESTE:
            a, b = palavras(f), palavras(g)
            if a and len(a & b) / len(a | b) >= 0.75:
                quase.append((f, g))
assert not quase, f"exemplos novos quase iguais a frases de teste: {quase}"
assert sum(map(len, EXEMPLOS.values())) >= 850, "os exemplos da 2.9.1 foram somados"
print(f"OK: {sum(map(len, EXEMPLOS.values()))} exemplos, nenhum repetido das {len(TESTE)} frases de teste")

# ------------------------------------------------------------
# 2. Classificador local sozinho
# ------------------------------------------------------------
cl.esquecer()
inicio = time.time()
modelo = cl.preparar()
treino_s = time.time() - inicio
acertos = seguros = acertos_seguros = 0
inicio = time.time()
for frase, esperado in FRASES:
    r = cl.classificar(frase)
    ok = r["notas"][0][1] == esperado
    acertos += ok
    if r["certo"]:
        seguros += 1
        acertos_seguros += ok
ms = 1000 * (time.time() - inicio) / len(FRASES)
n = len(FRASES)
assert acertos / n >= 0.80, f"local sozinho: {acertos}/{n}"
assert seguros >= n / 2 and acertos_seguros / seguros >= 0.93, f"seguro: {acertos_seguros}/{seguros}"
assert ms < 10, f"{ms:.1f} ms por frase"
print(f"OK: local sozinho acerta {acertos}/{n} frases nunca vistas; seguro em {seguros}, "
      f"com {acertos_seguros}/{seguros} certas ({ms:.1f} ms por frase, treino {treino_s:.2f} s)")

# ------------------------------------------------------------
# 3. Modo AUTO com o ajudante do PC do usuário: "tecnico" pra tudo
# ------------------------------------------------------------
class Resp:
    status_code = 200

    def __init__(self, conteudo):
        self.c = conteudo

    def json(self):
        return {"message": {"content": self.c}}


chamadas = []


def post_tecnico(url, json, timeout):
    chamadas.append(json)
    return Resp('{"motivo": "computer stuff", "categoria": "fix_linux_problem"}')


tars._SESSION.post = post_tecnico
tars.listar_modelos_instalados = lambda forcar=False: {tars.MODELO_AJUDANTE, "qwen3:8b"}
tars.modelo_embedding = lambda *a, **k: None
tars._nomes_de_apps = lambda: frozenset()


def nota_auto(conjunto):
    ok = 0
    for frase, esperado in conjunto:
        tars._ultima_tarefa.update(categoria=None, ts=0)
        ok += tars.detectar_tarefa(frase) == esperado
    return ok


ok86 = nota_auto(FRASES)
ok_en = nota_auto(AVALIACAO["en"])
assert ok86 / len(FRASES) >= 0.82, f"AUTO com ajudante quebrado: {ok86}/{len(FRASES)}"
assert ok_en >= 30, f"as 35 frases do relatório do usuário: {ok_en}/35"
assert len(chamadas) < len(FRASES) + 35, "o ajudante só é chamado nos empates"
print(f"OK: ajudante respondendo 'tecnico' pra tudo -> AUTO acerta {ok86}/{len(FRASES)} "
      f"(e {ok_en}/35 no relatório do usuário); ajudante chamado {len(chamadas)}x")

# ------------------------------------------------------------
# 4. Saúde do ajudante
# ------------------------------------------------------------
s = escolha.SaudeAjudante()
for i in range(7):
    assert not s.registrar("tecnico", ["acao", "tecnico"])
assert s.registrar("tecnico", ["visao", "tecnico"]) and not s.confiavel()
s = escolha.SaudeAjudante()
for cat in ["acao", "busca", "geral", "acao", "visao", "codigo", "acao", "simples", "geral", "busca"]:
    s.registrar(cat, ["acao", cat])
assert s.confiavel(), "respostas variadas: continua valendo"
s = escolha.SaudeAjudante()
for _ in range(10):
    s.registrar("acao", ["acao"])
assert s.confiavel(), "sem opção não conta"

arquivo = Path(tempfile.mkdtemp()) / "avaliacao_ajudante.json"
s = escolha.SaudeAjudante(arquivo)
assert s.anotar_avaliacao("qwen2.5:0.5b", 4 / 35) and not s.confiavel("qwen2.5:0.5b")
assert s.confiavel("outro:1b"), "vale só pro modelo avaliado"
assert not escolha.SaudeAjudante(arquivo).confiavel("qwen2.5:0.5b"), "fica guardado"
assert not s.anotar_avaliacao("qwen2.5:0.5b", 30 / 35) and s.confiavel("qwen2.5:0.5b"), "melhorou: volta"
print("OK: ajudante que responde sempre a mesma tarefa (ou reprovado na avaliação) deixa de ser consultado")

# Reprovado: decidir_tarefa nem chama o ajudante
tars.saude_ajudante = escolha.SaudeAjudante(arquivo)
tars.saude_ajudante.anotar_avaliacao(tars.MODELO_AJUDANTE, 0.1)
chamadas.clear()
d = tars.decidir_tarefa("lê pra mim o aviso que tá no meio da tela")
assert not chamadas, "reprovado: não chama"
assert any(c == "ajudante" and "ignorado" in txt for c, txt in d.trilha) or d.via != "ajudante", d
print(f"OK: reprovado, o desempate fica com as outras camadas ({d.categoria} via {d.via})")

# ------------------------------------------------------------
# 5. Os casos que davam errado
# ------------------------------------------------------------
tars.saude_ajudante = escolha.SaudeAjudante()
tars._classificar_com_ia = lambda *a, **k: None
casos = [
    ("entra no gmail pra mim", "simples"),
    ("go to gmail for me", "simples"),
    ("vídeos de receita de lasanha no youtube", "busca"),
    ("spotify pausa a música", "acao"),
]
for frase, esperado in casos:
    d = tars.decidir_tarefa(frase, anterior="geral")
    assert d.categoria == esperado, (frase, d)
# "e aí..." é cumprimento, não "e (depois)...": não herda a tarefa anterior
assert not escolha.eh_continuacao(cl.normalizar("e aí, como você está hoje?"))
assert escolha.eh_continuacao(cl.normalizar("e depois fecha"))
tars.lembrar_tarefa("busca")
d = tars.decidir_tarefa("e aí, como você está hoje?")
assert d.categoria == "simples" and not any(c == "contexto" for c, _ in d.trilha), d
print("OK: 'entra no gmail pra mim' abre o site; 'e aí, como você está hoje?' é cumprimento")

print("\nTUDO OK.")
