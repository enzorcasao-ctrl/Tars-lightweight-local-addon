"""3.0: rotinas (pedidos agendados) e memória de preferências.

Relógio falso e arquivos temporários: "todo dia às 8h abre o gmail",
"daqui a 10 minutos...", "lembra que meu navegador é o Brave"."""

import datetime as dt
import os
import tempfile

os.environ.setdefault("XDG_CONFIG_HOME", tempfile.mkdtemp(prefix="opentars-config-"))
from _util import carregar_tars  # noqa: E402

tars = carregar_tars()
lib = tars.rotinas_lib
pasta = tempfile.mkdtemp(prefix="opentars-rotinas-")
relogio = {"agora": dt.datetime(2026, 9, 28, 7, 50)}  # segunda-feira
agora = lambda: relogio["agora"]  # noqa: E731

# ------------------------------------------------------------
# 1. Horários e dias em 5 idiomas
# ------------------------------------------------------------
assert lib.ler_hora("08:00") == (8, 0) and lib.ler_hora("8h30") == (8, 30) and lib.ler_hora("7:15 pm") == (19, 15)
assert lib.ler_hora("25:00") is None and lib.ler_hora("amanhã") is None
assert lib.normalizar_dias("weekdays") == lib.DIAS[:5] == lib.normalizar_dias("dias úteis")
assert lib.normalizar_dias("segunda e sexta") == ("mon", "fri") == lib.normalizar_dias("lunes, viernes")
assert lib.normalizar_dias(["sáb", "dom"]) == ("sat", "sun") == lib.normalizar_dias("fim de semana")
assert lib.normalizar_dias(None) == lib.DIAS
print("OK: '8h30', '7:15 pm', 'dias úteis', 'segunda e sexta', 'lunes, viernes', 'fim de semana'")

# ------------------------------------------------------------
# 2. Rotinas: criar, vencer uma vez por dia, uma vez só, cancelar
# ------------------------------------------------------------
r = lib.Rotinas(os.path.join(pasta, "rotinas.json"), agora=agora)
diaria, erro = r.criar("abre o gmail e o spotify", "08:00", "weekdays")
assert not erro and r.descrever(diaria) == "weekdays at 08:00"
bolo, _ = r.criar("mostra um lembrete: tirar o bolo", em_minutos=10)
assert r.descrever(bolo) == "once at 2026-09-28 08:00"
assert r.criar("x", "99:99")[1] and r.criar("", "08:00")[1] and r.criar("x")[1]
assert r.vencidas() == []
relogio["agora"] = dt.datetime(2026, 9, 28, 8, 0, 20)
assert {x["pedido"] for x in r.vencidas()} == {"abre o gmail e o spotify", "mostra um lembrete: tirar o bolo"}
relogio["agora"] = dt.datetime(2026, 9, 28, 8, 1)
assert r.vencidas() == [], "não repete no mesmo dia"
assert [x["pedido"] for x in r.listar()] == ["abre o gmail e o spotify"], "a de uma vez saiu da lista"
relogio["agora"] = dt.datetime(2026, 10, 3, 8, 0, 10)  # sábado
assert r.vencidas() == [], "dias úteis: sábado não"
relogio["agora"] = dt.datetime(2026, 10, 5, 8, 9)       # segunda, 9 min atrasado (PC ligou depois)
assert len(r.vencidas()) == 1
relogio["agora"] = dt.datetime(2026, 10, 6, 9, 30)      # terça, 1h30 atrasado: perdeu a hora
assert r.vencidas() == []
assert r.proxima(r.listar()[0]) == dt.datetime(2026, 10, 7, 8, 0)
tarde, _ = r.criar("abre o spotify", "08:00")           # criada às 9:30: só amanhã
assert r.vencidas() == [] and r.proxima(tarde) == dt.datetime(2026, 10, 7, 8, 0)
assert [x["pedido"] for x in r.cancelar("spotify")] == ["abre o gmail e o spotify", "abre o spotify"]
assert r.listar() == []
print("OK: rotina diária roda 1x por dia (até 15 min atrasada), respeita os dias; a de uma vez some depois")

relogio["agora"] = dt.datetime(2026, 10, 6, 8, 0)
amanha, _ = r.criar("abre o jornal", "10:00", "amanhã")
assert amanha["quando"] == "2026-10-07T10:00:00", amanha
relogio["agora"] = dt.datetime(2026, 10, 6, 10, 0, 5)
assert r.vencidas() == [], "amanhã às 10 não roda hoje às 10"
r.cancelar("jornal")
relogio["agora"] = dt.datetime(2026, 10, 6, 23, 0)
noite, _ = r.criar("desliga o pc", "23:55")
relogio["agora"] = dt.datetime(2026, 10, 7, 0, 3)
assert [x["pedido"] for x in r.vencidas()] == ["desliga o pc"], "23:55 conferida às 00:03 ainda vale"
assert r.vencidas() == []
r.cancelar("desliga")
print("OK: 'amanhã às 10' é amanhã; rotina das 23:55 conferida depois da meia-noite ainda roda")

# ------------------------------------------------------------
# 3. Agendador chama na hora
# ------------------------------------------------------------
rodou = []
relogio["agora"] = dt.datetime(2026, 10, 7, 12, 0)
r.criar("abre a calculadora", em_minutos=1)
ag = lib.Agendador(r, rodou.append)
ag.verificar()
assert rodou == []
relogio["agora"] = dt.datetime(2026, 10, 7, 12, 1, 5)
ag.verificar()
assert [x["pedido"] for x in rodou] == ["abre a calculadora"]
print("OK: o agendador chama o pedido na hora")

# ------------------------------------------------------------
# 4. Memória
# ------------------------------------------------------------
m = lib.Memoria(os.path.join(pasta, "memoria.json"), agora=agora)
assert m.para_prompt() == ""
assert m.lembrar("Meu navegador é o Brave")[0] and m.lembrar("A pasta de projetos é ~/dev")[0]
assert m.lembrar("meu navegador é o brave")[0] and len(m.listar()) == 2, "repetida não duplica"
assert not m.lembrar("x" * 300)[0]
assert "brave" in m.para_prompt().lower() and "~/dev" in m.para_prompt()
assert m.esquecer("brave") == ["meu navegador é o brave"] and m.listar() == ["A pasta de projetos é ~/dev"]
print("OK: memória guarda frases curtas, não duplica, esquece por palavra e vai pro prompt")

# ------------------------------------------------------------
# 5. No núcleo: ferramentas só quando o pedido fala disso, prompt com a memória
# ------------------------------------------------------------
tars.rotinas = lib.Rotinas(os.path.join(pasta, "r2.json"), agora=agora)
tars.memoria = lib.Memoria(os.path.join(pasta, "m2.json"), agora=agora)


def nomes(tarefa, texto):
    return {f["function"]["name"] for f in tars.ferramentas_do_pedido(tarefa, texto)}


assert "schedule_task" in nomes("simples", "todo dia às 8h abre o gmail")
assert "remember" in nomes("geral", "lembra que meu navegador é o brave")
assert not nomes("acao", "abre o firefox") & tars._FERRAMENTAS_SO_SE_PEDIDAS
assert not nomes("acao", "abre o terminal") & tars._FERRAMENTAS_SO_SE_PEDIDAS
print("OK: agenda/memória só entram na lista quando o pedido fala disso (a lista dos modelos pequenos não cresce)")

relogio["agora"] = dt.datetime(2026, 10, 7, 7, 0)
res = tars.executar_ferramenta("schedule_task", {"request": "abre o gmail", "time": "8h", "days": "dias úteis"})
assert res["sucesso"] and "weekdays at 08:00" in res["mensagem"], res
res = tars.executar_ferramenta("set_reminder", {"task": "tirar o bolo", "minutes": "10"})
assert res["sucesso"] and "once at 2026-10-07 07:10" in res["mensagem"], res
res = tars.executar_ferramenta("list_scheduled_tasks", {})
assert len(res["rotinas"]) == 2
assert tars.executar_ferramenta("cancel_scheduled_task", {"id": "bolo"})["sucesso"]
assert tars.executar_ferramenta("remember", {"fact": "Meu navegador é o Brave"})["sucesso"]
assert "Meu navegador é o Brave" in tars.montar_system_prompt()
assert tars.executar_ferramenta("save_memory", {"memory": "Moro em Francisco Beltrão"})["sucesso"]
assert tars.executar_ferramenta("forget", {"fact": "brave"})["sucesso"]
prompt = tars.montar_system_prompt()
assert "Brave" not in prompt and "Francisco Beltrão" in prompt
ctx = tars._contexto_do_pedido("daqui a 10 minutos me lembra do bolo", "geral", False)
assert ctx and "Now it is" in ctx, ctx
assert tars._contexto_do_pedido("qual a capital da frança", "geral", False) is None
print("OK: schedule_task / set_reminder / remember / forget funcionam pela IA; a hora só vai no pedido que agenda")

# rotina rodando não se agenda de novo; ferramenta de memória fora do pedido é recusada
tars.processar_mensagem = lambda texto: sorted(nomes(None, texto) & tars._FERRAMENTAS_SO_SE_PEDIDAS)
assert not set(tars.processar_rotina("mostra um lembrete: tirar o bolo")) & tars._FERRAMENTAS_AGENDA
assert "schedule_task" in tars.processar_mensagem("mostra um lembrete: tirar o bolo")
tars.catalogar_modelos = lambda forcar=False: {}
tars.carregar_modelo = lambda m, silencioso=False: True
tars.contexto_ia = lambda: 8192
tars.modo_modelo = "MANUAL"
tars.listar_janelas_x = lambda: None
roteiro = iter([
    {"content": "", "tool_calls": [{"function": {"name": "forget", "arguments": {"fact": "*"}}}]},
    {"content": "Li a página.", "tool_calls": []},
])
tars._executar_turno_streaming = lambda *a, **k: (next(roteiro), None)
tars.conversa = []
assert tars.perguntar_modelo("qwen3:4b", "resume essa página pra mim", tarefa="geral") == "Li a página."
assert tars.memoria.listar() == ["Moro em Francisco Beltrão"], "forget('*') fora de um pedido de memória não roda"
print("OK: rotina não se reagenda; forget('*') vindo do nada (ex.: texto de uma página) é recusado")

print("\nTUDO OK.")
