"""Classificador local do pedido (2.9.1): instantâneo, sem Ollama.

Aprende, ao abrir o openTARS, com as frases de exemplo de cada tarefa
(tars_exemplos.py) e com as palavras-chave dos arquivos de idioma. Olha
pedaços de palavra (3 a 5 letras), palavras e pares de palavras, então
entende variações ("clica", "clicar", "clique"; "desliga", "desligue") e
os 5 idiomas sem lista fixa de conjugações.

É um Naive Bayes complementar (da família dos filtros de spam): treina em
~0,1 s, classifica em menos de 1 ms e não precisa de numpy.
A confiança vem da diferença entre a 1ª e a 2ª tarefa, calibrada por
validação cruzada nos próprios exemplos (como os embeddings).

Não substitui as outras camadas: dá VOTOS. Quando está confiante, decide
sozinho; em dúvida, as duas mais prováveis viram finalistas pro ajudante."""

import hashlib
import json
import math
import os
import re
import threading
import unicodedata
from pathlib import Path

VERSAO = 1
ALFA = 0.3               # suavização (Lidstone)
ESCALA = 100000.0        # só pra margem ficar num número legível (~0,5 a 5)
N_GRAMAS = (3, 4, 5)     # pedaços de palavra
PESO_PALAVRA = 2.0       # palavra inteira conta mais que um pedaço dela
PESO_BIGRAMA = 2.0
DOBRAS_CALIBRACAO = 5
ALVO_PRECISAO = 0.93     # a margem "confiante" acerta pelo menos isso na validação
MARGEM_MINIMA = 0.3
MARGEM_MAXIMA = 4.0

_RE_TOKEN = re.compile(r"[a-z0-9]+(?:[.'][a-z0-9]+)*")

# Palavras que aparecem em qualquer tipo de pedido e só fazem barulho.
VAZIAS = frozenset("""
a o as os um uma uns umas de da do das dos no na nos nas em pra pro pras pros para por com me mim meu minha
meus minhas te voce vc isso esse essa este esta aquele aquela que e ou se lá la aqui ai ai por favor pf pfv
the a an of to in on at for with me my i you your it this that is are be please and or can could would
el la los las un una de del en con por para mi mis yo tu que y o es lo le
le la les un une des de du en au aux pour avec moi mon ma mes je tu que et ou est ce
der die das ein eine einen dem den des mit fur mich mir mein meine ich du und oder ist bitte
""".split())


def normalizar(texto):
    sem_acento = unicodedata.normalize("NFKD", texto or "")
    sem_acento = "".join(ch for ch in sem_acento if not unicodedata.combining(ch))
    return sem_acento.lower().replace("ß", "ss")


def tokens(texto_normalizado):
    return _RE_TOKEN.findall(texto_normalizado)


def caracteristicas(texto):
    """{característica: peso} de um texto."""
    palavras = tokens(normalizar(texto))
    feats = {}

    def somar(f, p):
        feats[f] = feats.get(f, 0.0) + p

    uteis = [w for w in palavras if w not in VAZIAS]
    for w in uteis:
        somar("w:" + w, PESO_PALAVRA)
        marcada = f"<{w}>"
        for n in N_GRAMAS:
            if len(marcada) < n:
                continue
            for i in range(len(marcada) - n + 1):
                somar(marcada[i:i + n], 1.0)
    for a, b in zip(uteis, uteis[1:]):
        somar(f"b:{a}_{b}", PESO_BIGRAMA)
    # Pedido curtinho ("valeu", "oi") é pista por si só.
    if len(palavras) <= 3:
        somar("#curto", 1.0)
    return feats


class Modelo:
    """Naive Bayes "complementar" (Rennie et al., 2003): cada tarefa é
    descrita pelo que as OUTRAS tarefas têm, o que corrige o viés do Naive
    Bayes comum a favor da tarefa com menos texto (aqui, os cumprimentos
    curtos engoliam qualquer palavra desconhecida). Características com
    peso TF-IDF e vetor normalizado."""

    def __init__(self, amostras, margem=None, precisao=None):
        """amostras: [(texto, categoria)]."""
        self.categorias = sorted({c for _, c in amostras})
        feats = [(caracteristicas(t), c) for t, c in amostras]
        n = len(feats)
        df = {}
        for f, _ in feats:
            for k in f:
                df[k] = df.get(k, 0) + 1
        self.idf = {k: math.log((n + 1) / (d + 1)) + 1.0 for k, d in df.items()}
        self._idf_novo = math.log(n + 1) + 1.0

        por_cat = {c: {} for c in self.categorias}
        todas = {}
        for f, c in feats:
            alvo = por_cat[c]
            for k, v in self._vetor(f).items():
                alvo[k] = alvo.get(k, 0.0) + v
                todas[k] = todas.get(k, 0.0) + v
        soma_todas = sum(todas.values())
        v = len(todas)
        self.pesos = {}
        for c in self.categorias:
            propria = por_cat[c]
            den = math.log(soma_todas - sum(propria.values()) + ALFA * v)
            w = {k: math.log(total - propria.get(k, 0.0) + ALFA) - den for k, total in todas.items()}
            z = sum(abs(x) for x in w.values()) or 1.0
            # Guarda o peso já com o sinal trocado: nota maior = mais provável.
            self.pesos[c] = {k: -x / z for k, x in w.items()}
        self.margem = margem
        self.precisao = precisao

    def _vetor(self, feats):
        v = {k: p * self.idf.get(k, self._idf_novo) for k, p in feats.items()}
        norma = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {k: x / norma for k, x in v.items()}

    def notas(self, texto):
        """[(nota, categoria)] do maior pro menor; a 1ª tem nota 0 e as
        outras, negativa (a distância até ela)."""
        feats = caracteristicas(texto)
        if not feats:
            return []
        vetor = self._vetor(feats)
        resultado = sorted(
            ((sum(x * self.pesos[c].get(k, 0.0) for k, x in vetor.items()), c) for c in self.categorias),
            reverse=True,
        )
        topo = resultado[0][0]
        return [(ESCALA * (nota - topo), c) for nota, c in resultado]

    def classificar(self, texto):
        """(categoria, margem) — margem = folga da 1ª sobre a 2ª."""
        n = self.notas(texto)
        if not n:
            return None, 0.0
        return n[0][1], (n[0][0] - n[1][0]) if len(n) > 1 else MARGEM_MAXIMA


def _calibrar(amostras):
    """Validação cruzada: a menor margem com que o modelo ainda acerta
    ≥ ALVO_PRECISAO, e a precisão geral."""
    resultados = []
    for dobra in range(DOBRAS_CALIBRACAO):
        treino = [a for i, a in enumerate(amostras) if i % DOBRAS_CALIBRACAO != dobra]
        teste = [a for i, a in enumerate(amostras) if i % DOBRAS_CALIBRACAO == dobra]
        m = Modelo(treino)
        for texto, esperado in teste:
            cat, margem = m.classificar(texto)
            resultados.append((margem, cat == esperado))
    if not resultados:
        return MARGEM_MAXIMA, 0.0
    precisao = sum(ok for _, ok in resultados) / len(resultados)
    resultados.sort(reverse=True)
    escolhida, acertos = MARGEM_MAXIMA, 0
    for n, (margem, ok) in enumerate(resultados, 1):
        acertos += ok
        if acertos / n >= ALVO_PRECISAO:
            escolhida = margem
    return min(MARGEM_MAXIMA, max(MARGEM_MINIMA, escolhida)), precisao


_modelo = None
_trava = threading.Lock()
_pasta_cache = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "opentars"


def configurar(pasta_cache=None):
    global _pasta_cache
    if pasta_cache:
        _pasta_cache = Path(pasta_cache)


def amostras_padrao(extras=()):
    from tars_exemplos import EXEMPLOS
    amostras = [(f, c) for c, lista in EXEMPLOS.items() for f in lista] + list(extras)
    # Intercala as categorias (ordem estável) antes das dobras da
    # calibração: senão uma dobra teria só exemplos de uma tarefa.
    amostras.sort(key=lambda a: (hash_estavel(a[0]) % 997, a[0]))
    return amostras


def hash_estavel(texto):
    h = 0
    for ch in texto:
        h = (h * 131 + ord(ch)) & 0xFFFFFFFF
    return h


def _assinatura(amostras):
    bruto = json.dumps([VERSAO, ALFA, N_GRAMAS, PESO_PALAVRA, PESO_BIGRAMA, ESCALA, ALVO_PRECISAO, amostras],
                       ensure_ascii=False)
    return hashlib.sha1(bruto.encode()).hexdigest()[:12]


def _calibracao_em_cache(amostras):
    """(margem, precisão) da validação cruzada. Ela treina o modelo 5
    vezes (~0,3 s), então o resultado fica guardado em ~/.cache/opentars
    e só é refeito quando os exemplos mudam."""
    assinatura = _assinatura(amostras)
    arquivo = _pasta_cache / f"classificador-{assinatura}.json"
    try:
        dados = json.loads(arquivo.read_text(encoding="utf-8"))
        return float(dados["margem"]), float(dados["precisao"])
    except Exception:
        pass
    margem, precisao = _calibrar(amostras)
    try:
        arquivo.parent.mkdir(parents=True, exist_ok=True)
        for antigo in arquivo.parent.glob("classificador-*.json"):
            if antigo != arquivo:
                antigo.unlink(missing_ok=True)
        temporario = arquivo.with_suffix(".tmp")
        temporario.write_text(json.dumps({"margem": margem, "precisao": precisao}), encoding="utf-8")
        temporario.replace(arquivo)
    except Exception:
        pass  # sem disco: calibra de novo na próxima vez
    return margem, precisao


def treinar(extras=(), calibrar=True):
    """Treina (e guarda) o modelo. calibrar=False pula a validação
    cruzada (margem fixa em 1,0: só pra testes e comparações)."""
    global _modelo
    amostras = amostras_padrao(extras)
    margem, precisao = _calibracao_em_cache(amostras) if calibrar else (1.0, None)
    modelo_novo = Modelo(amostras, margem, precisao)
    with _trava:
        _modelo = modelo_novo
    return modelo_novo


def preparar():
    """O modelo treinado (treina na primeira vez, ~0,1 s). Seguro entre
    threads."""
    m = _modelo
    if m is not None:
        return m
    with _trava_treino:
        return _modelo or treinar()


_trava_treino = threading.Lock()


def classificar(texto):
    """{"notas": [(nota, categoria)...], "margem": folga da 1ª, "certo":
    passou da margem calibrada} ou None."""
    m = preparar()
    notas = m.notas(texto)
    if not notas:
        return None
    folga = notas[0][0] - notas[1][0] if len(notas) > 1 else MARGEM_MAXIMA
    return {"notas": notas, "margem": folga, "certo": folga >= m.margem, "limite": m.margem}


def esquecer():
    """Só pros testes."""
    global _modelo
    with _trava:
        _modelo = None
