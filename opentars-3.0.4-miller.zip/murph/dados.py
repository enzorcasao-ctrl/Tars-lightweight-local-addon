"""Dados da Murph ajudante: treino = exemplos do openTARS; teste = frases
que o openTARS guarda SEPARADAS pra avaliação (nenhum classificador treina nelas)."""
import json, os, sys
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ); sys.path.insert(0, os.path.join(RAIZ, "tests"))
from tars_exemplos import EXEMPLOS
from frases_classificador import FRASES

TAREFAS = ["visao", "codigo", "tecnico", "acao", "busca", "simples", "geral"]
IDIOMAS = ["pt_BR", "en", "es", "fr", "de"]

def treino():
    return [(f, cat) for cat, lista in EXEMPLOS.items() for f in lista]

def teste():
    avaliacao = []
    for idioma in IDIOMAS:
        d = json.load(open(os.path.join(RAIZ, "idiomas", f"{idioma}.json"), encoding="utf-8"))
        avaliacao += [(f, c, idioma) for f, c in d["avaliacao"]]
    extra = [(f, c, "misto") for f, c in FRASES]
    return avaliacao, extra
