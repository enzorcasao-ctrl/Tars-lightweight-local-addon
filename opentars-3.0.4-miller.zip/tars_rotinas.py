"""openTARS 3.0: rotinas (pedidos agendados) e memória (preferências).

Rotina = um pedido, como a pessoa falaria ("abre o gmail e o spotify"),
mais QUANDO: num horário (todo dia, dias úteis, fim de semana, ou dias
escolhidos) ou uma vez só (daqui a N minutos / hoje às HH:MM). Quem roda
é o openTARS aberto (janela ou terminal): na hora, o pedido entra como se
a pessoa tivesse digitado.

Memória = frases curtas que a pessoa pediu pra lembrar ("meu navegador é
o Brave", "a pasta de projetos é ~/dev"). Vão no prompt de todo pedido.

Tudo em ~/.config/opentars (rotinas.json, memoria.json). Lógica pura:
o relógio e os arquivos são injetáveis nos testes."""

import datetime as dt
import json
import os
import re
import threading
import time
import unicodedata
import uuid
from pathlib import Path


def pasta_config():
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "opentars"


def _ler(caminho, padrao):
    try:
        return json.loads(Path(caminho).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return padrao


def _gravar(caminho, dados):
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    temporario = caminho.with_suffix(".tmp")
    temporario.write_text(json.dumps(dados, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(temporario, caminho)


def _normalizar(texto):
    texto = unicodedata.normalize("NFKD", str(texto or "").lower())
    return " ".join("".join(c for c in texto if not unicodedata.combining(c)).split())


# ------------------------------------------------------------
# Dias
# ------------------------------------------------------------
DIAS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
_NOMES_DIAS = {
    "mon": ("mon", "monday", "seg", "segunda", "lunes", "lun", "lundi", "montag", "mo"),
    "tue": ("tue", "tuesday", "ter", "terca", "martes", "mar", "mardi", "dienstag", "di"),
    "wed": ("wed", "wednesday", "qua", "quarta", "miercoles", "mie", "mercredi", "mittwoch", "mi"),
    "thu": ("thu", "thursday", "qui", "quinta", "jueves", "jue", "jeudi", "donnerstag", "do"),
    "fri": ("fri", "friday", "sex", "sexta", "viernes", "vie", "vendredi", "freitag", "fr"),
    "sat": ("sat", "saturday", "sab", "sabado", "samedi", "samstag", "sa"),
    "sun": ("sun", "sunday", "dom", "domingo", "dimanche", "sonntag", "so"),
}
_GRUPOS = {
    "daily": DIAS, "every day": DIAS, "everyday": DIAS, "todo dia": DIAS, "todos os dias": DIAS,
    "diario": DIAS, "todos los dias": DIAS, "tous les jours": DIAS, "taglich": DIAS, "jeden tag": DIAS,
    "weekdays": DIAS[:5], "weekday": DIAS[:5], "dias uteis": DIAS[:5], "dia util": DIAS[:5],
    "dias laborables": DIAS[:5], "entre semana": DIAS[:5], "semaine": DIAS[:5], "werktags": DIAS[:5],
    "weekends": DIAS[5:], "weekend": DIAS[5:], "fim de semana": DIAS[5:], "fins de semana": DIAS[5:],
    "fin de semana": DIAS[5:], "week-end": DIAS[5:], "wochenende": DIAS[5:],
}


def normalizar_dias(dias):
    """'weekdays', ['seg', 'qua'], 'segunda e sexta', None -> tupla de 'mon'..'sun'
    (None/vazio = todo dia)."""
    if not dias:
        return DIAS
    if isinstance(dias, str):
        n = _normalizar(dias)
        for grupo, lista in _GRUPOS.items():
            if n == grupo:
                return tuple(lista)
        dias = re.split(r"[,;/]|\s+(?:e|and|y|et|und)\s+|\s+", n)
    escolhidos = set()
    for d in dias:
        n = _normalizar(d).rstrip(".")
        n = re.sub(r"-?feira$", "", n)
        if n in _GRUPOS:
            escolhidos.update(_GRUPOS[n])
            continue
        for codigo, nomes in _NOMES_DIAS.items():
            if n in nomes:
                escolhidos.add(codigo)
    return tuple(d for d in DIAS if d in escolhidos) or DIAS


def ler_hora(texto):
    """'08:00', '8h', '8h30', '20:15', '8 am', '8:30 pm' -> (h, m) ou None."""
    n = _normalizar(texto).replace(" ", "")
    m = re.fullmatch(r"(\d{1,2})(?:[:h.](\d{2})?)?(am|pm)?h?", n)
    if not m:
        return None
    h, minuto = int(m.group(1)), int(m.group(2) or 0)
    if m.group(3) == "pm" and h < 12:
        h += 12
    if m.group(3) == "am" and h == 12:
        h = 0
    if not (0 <= h < 24 and 0 <= minuto < 60):
        return None
    return h, minuto


# ------------------------------------------------------------
# Rotinas
# ------------------------------------------------------------
_UMA_VEZ = {"once", "one time", "today", "uma vez", "hoje", "una vez", "hoy", "une fois", "aujourd'hui",
            "einmal", "heute"}
_AMANHA = {"tomorrow", "amanha", "manana", "demain", "morgen"}
TOLERANCIA_ATRASO_S = 15 * 60   # openTARS estava fechado/ocupado: roda se atrasou até 15 min


class Rotinas:
    def __init__(self, caminho=None, agora=None):
        self.caminho = Path(caminho or pasta_config() / "rotinas.json")
        self.agora = agora or dt.datetime.now
        self._trava = threading.Lock()

    def listar(self):
        return list(_ler(self.caminho, []))

    def _salvar(self, lista):
        _gravar(self.caminho, lista)

    def criar(self, pedido, hora=None, dias=None, em_minutos=None):
        """Devolve (rotina, erro)."""
        pedido = " ".join(str(pedido or "").split())
        if not pedido:
            return None, "empty request"
        agora = self.agora()
        rotina = {"id": uuid.uuid4().hex[:6], "pedido": pedido, "criada": agora.isoformat(timespec="seconds")}
        if em_minutos not in (None, ""):
            try:
                minutos = float(em_minutos)
            except (TypeError, ValueError):
                return None, "in_minutes must be a number"
            if minutos <= 0 or minutos > 60 * 24 * 7:
                return None, "in_minutes must be between 1 and 10080"
            rotina.update(tipo="uma_vez", quando=(agora + dt.timedelta(minutes=minutos)).isoformat(timespec="seconds"))
        elif hora:
            hm = ler_hora(hora)
            if not hm:
                return None, f"can't read the time '{hora}' (use HH:MM, 24h)"
            quando = _normalizar(dias) if isinstance(dias, str) else ""
            if quando in _UMA_VEZ or quando in _AMANHA:
                alvo = agora.replace(hour=hm[0], minute=hm[1], second=0, microsecond=0)
                if quando in _AMANHA or alvo <= agora:
                    alvo += dt.timedelta(days=1)
                rotina.update(tipo="uma_vez", quando=alvo.isoformat(timespec="seconds"))
            else:
                rotina.update(tipo="repetir", hora=f"{hm[0]:02d}:{hm[1]:02d}", dias=list(normalizar_dias(dias)))
                if agora >= agora.replace(hour=hm[0], minute=hm[1], second=0, microsecond=0):
                    rotina["ultima"] = agora.date().isoformat()  # hoje já passou: começa amanhã
        else:
            return None, "say when: time (HH:MM) or in_minutes"
        with self._trava:
            lista = self.listar()
            lista.append(rotina)
            self._salvar(lista)
        return rotina, None

    def cancelar(self, alvo):
        """Cancela pelo id ou por um pedaço do pedido. Devolve as canceladas."""
        chave = _normalizar(alvo)
        with self._trava:
            lista = self.listar()
            fora = [r for r in lista if r["id"] == str(alvo).strip() or (chave and chave in _normalizar(r["pedido"]))]
            if fora:
                self._salvar([r for r in lista if r not in fora])
        return fora

    def proxima(self, rotina, depois_de=None):
        """Próximo datetime em que a rotina roda (depois de 'depois_de')."""
        agora = depois_de or self.agora()
        if rotina.get("tipo") == "uma_vez":
            return dt.datetime.fromisoformat(rotina["quando"])
        h, m = map(int, rotina["hora"].split(":"))
        dias = set(rotina.get("dias") or DIAS)
        for i in range(8):
            dia = (agora + dt.timedelta(days=i)).replace(hour=h, minute=m, second=0, microsecond=0)
            if dia > agora and DIAS[dia.weekday()] in dias:
                return dia
        return None

    def vencidas(self):
        """Rotinas que devem rodar AGORA (já marcadas como rodadas). As de
        uma vez saem da lista; as que se repetem guardam a última vez."""
        agora = self.agora()
        prontas = []
        with self._trava:
            lista = self.listar()
            mudou = False
            manter = []
            for r in lista:
                if r.get("tipo") == "uma_vez":
                    quando = dt.datetime.fromisoformat(r["quando"])
                    if quando <= agora:
                        mudou = True
                        if (agora - quando).total_seconds() <= TOLERANCIA_ATRASO_S:
                            prontas.append(r)
                        continue  # roda (ou perdeu a hora) e sai da lista
                    manter.append(r)
                    continue
                h, m = map(int, r["hora"].split(":"))
                hoje = agora.replace(hour=h, minute=m, second=0, microsecond=0)
                # ontem também: 23:55 conferida às 00:03 ainda está no prazo
                for horario in (hoje, hoje - dt.timedelta(days=1)):
                    atraso = (agora - horario).total_seconds()
                    ja_rodou = r.get("ultima") == horario.date().isoformat()
                    if (0 <= atraso <= TOLERANCIA_ATRASO_S and DIAS[horario.weekday()] in (r.get("dias") or DIAS)
                            and not ja_rodou):
                        r = dict(r, ultima=horario.date().isoformat())
                        prontas.append(r)
                        mudou = True
                        break
                manter.append(r)
            if mudou:
                self._salvar(manter)
        return prontas

    def descrever(self, rotina):
        """Texto curto (em inglês, pra IA) de quando a rotina roda."""
        if rotina.get("tipo") == "uma_vez":
            return f"once at {rotina['quando'].replace('T', ' ')[:16]}"
        dias = rotina.get("dias") or list(DIAS)
        if tuple(dias) == DIAS:
            quando = "every day"
        elif tuple(dias) == DIAS[:5]:
            quando = "weekdays"
        elif tuple(dias) == DIAS[5:]:
            quando = "weekends"
        else:
            quando = ", ".join(dias)
        return f"{quando} at {rotina['hora']}"


class Agendador:
    """Thread que olha as rotinas a cada 'intervalo' segundos e chama
    ao_vencer(rotina) na hora."""

    def __init__(self, rotinas, ao_vencer, intervalo=20):
        self.rotinas = rotinas
        self.ao_vencer = ao_vencer
        self.intervalo = intervalo
        self._parar = threading.Event()
        self._thread = None

    def iniciar(self):
        if self._thread is not None and self._thread.is_alive():
            return
        self._parar.clear()
        self._thread = threading.Thread(target=self._rodar, daemon=True)
        self._thread.start()

    def parar(self):
        self._parar.set()

    def verificar(self):
        for rotina in self.rotinas.vencidas():
            try:
                self.ao_vencer(rotina)
            except Exception:
                pass

    def _rodar(self):
        while not self._parar.is_set():
            self.verificar()
            self._parar.wait(self.intervalo)


# ------------------------------------------------------------
# Memória
# ------------------------------------------------------------
LIMITE_MEMORIAS = 40
LIMITE_CHARS_MEMORIA = 200


class Memoria:
    def __init__(self, caminho=None, agora=None):
        self.caminho = Path(caminho or pasta_config() / "memoria.json")
        self.agora = agora or dt.datetime.now
        self._trava = threading.Lock()

    def listar(self):
        return [m["texto"] for m in _ler(self.caminho, []) if isinstance(m, dict) and m.get("texto")]

    def lembrar(self, texto):
        """Guarda (ou atualiza, se já houver uma parecida). Devolve (ok, erro)."""
        texto = " ".join(str(texto or "").split())
        if not texto:
            return False, "empty"
        if len(texto) > LIMITE_CHARS_MEMORIA:
            return False, f"too long (max {LIMITE_CHARS_MEMORIA} characters): keep it short"
        with self._trava:
            itens = [m for m in _ler(self.caminho, []) if isinstance(m, dict) and m.get("texto")]
            chave = _normalizar(texto)
            itens = [m for m in itens if _normalizar(m["texto"]) != chave]
            itens.append({"texto": texto, "quando": self.agora().isoformat(timespec="seconds")})
            _gravar(self.caminho, itens[-LIMITE_MEMORIAS:])
        return True, None

    def esquecer(self, alvo):
        """Tira as memórias que contêm 'alvo' (ou todas com '*'). Devolve as tiradas."""
        chave = _normalizar(alvo)
        if not chave:
            return []
        with self._trava:
            itens = [m for m in _ler(self.caminho, []) if isinstance(m, dict) and m.get("texto")]
            fora = [m["texto"] for m in itens if chave == "*" or chave in _normalizar(m["texto"])]
            if fora:
                _gravar(self.caminho, [m for m in itens if m["texto"] not in fora])
        return fora

    def para_prompt(self):
        itens = self.listar()
        if not itens:
            return ""
        linhas = "\n".join(f"- {x}" for x in itens)
        return ("\nWHAT THE USER ASKED YOU TO REMEMBER (use it: e.g. their browser, folders, names; "
                "don't ask again what is here):\n" + linhas + "\n")


# ------------------------------------------------------------
# O pedido fala de lembrar / agendar? (aí a IA ganha essas ferramentas)
# ------------------------------------------------------------
_RE_MEMORIA = re.compile(
    r"\b(lembr(?!ete)\w*|memoriz\w*|esquec\w*|remember\w*|memori[sz]e\w*|forget\w*|recuerd\w*|olvid\w*|"
    r"souvien\w*|retien\w*|oubli\w*|merk\w*|vergiss\w*|erinner\w*|what do you know about me|"
    r"o que (voce )?sabe (sobre|de) mim)\b")
_RE_AGENDA = re.compile(
    r"\b(agend\w*|rotina\w*|lembrete\w*|alarme\w*|despert\w*|todo dia|todos os dias|toda (segunda|terca|"
    r"quarta|quinta|sexta)|dias uteis|daqui a \d+|as \d{1,2}(h|:\d\d)?|schedul\w*|routine\w*|remind\w*|"
    r"alarm\w*|every (day|morning|night|weekday|monday|tuesday|wednesday|thursday|friday)|in \d+ (min|minute|"
    r"hour)\w*|at \d{1,2}(:\d\d)? ?(am|pm)?|programar\w*|recordatorio\w*|cada dia|todos los dias|"
    r"dentro de \d+|a las \d{1,2}|planifi\w*|rappel\w*|tous les jours|chaque (jour|matin)|dans \d+ min\w*|"
    r"a \d{1,2}h|wecker|jeden (tag|morgen)|taglich|in \d+ minut\w*|um \d{1,2}( uhr)?)\b")


def fala_de_memoria(texto):
    return bool(_RE_MEMORIA.search(_normalizar(texto)))


def fala_de_agenda(texto):
    return bool(_RE_AGENDA.search(_normalizar(texto)))

