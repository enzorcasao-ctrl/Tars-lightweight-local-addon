# openTARS — nucleo/chat.py
# O laço de conversa com ferramentas: turnos, falhas, troca de modelo, visão.
#
# Parte do núcleo: o tars.py executa este arquivo DENTRO do próprio
# namespace (ver _carregar_nucleo), então tudo aqui é tars.<nome> e as
# partes enxergam umas às outras sem import. Os testes que trocam
# tars.<função> por uma falsa continuam valendo pra todas as partes.
# flake8: noqa

# ============================================================
# CHAT COM OLLAMA
# ============================================================

_MODELOS_SEM_THINKING = set()

# Modelos que confirmadamente não aceitam o parâmetro 'tools' (ex:
# gemma3:270m). Sem isso, escolher um modelo assim quebrava TODA
# mensagem com um 400 do Ollama — o openTARS sempre manda 'tools'.
_MODELOS_SEM_TOOLS = set()

# Modelos que não enxergam imagem (sem 'vision' no catálogo, ou o Ollama
# respondeu "does not support multimodal"). O print de tela não vai pra
# eles: um modelo com visão descreve a tela em texto.
_MODELOS_SEM_VISAO = set()


def modelo_enxerga(modelo):
    if modelo in _MODELOS_SEM_VISAO:
        return False
    try:
        info = catalogar_modelos().get(modelo)
    except Exception:
        info = None
    if info and info.get("capacidades_conhecidas"):
        return "vision" in info["capacidades"]
    return True  # não sabemos: tenta (e aprende com o erro)


def _erro_de_imagem(erro):
    """O modelo não aceita imagem nenhuma. Diferente de "tools not supported
    with images" (Ollama antigo): aí a imagem serve, as ferramentas não."""
    e = (erro or "").lower()
    if "tool" in e:
        return "multimodal" in e
    return "multimodal" in e or (("image" in e or "vision" in e) and "support" in e)


def _modelo_de_visao(excluir=()):
    """O modelo com visão que descreve prints pros modelos que não
    enxergam: o menor que roda bem nesta máquina."""
    try:
        catalogo = catalogar_modelos()
    except Exception:
        return None
    candidatos = [m for m in catalogo.values()
                  if "vision" in m["capacidades"] and m["tag"] not in _MODELOS_SEM_VISAO
                  and m["tag"] not in excluir and m["categoria"] != "embedding"]
    if not candidatos:
        return None
    gpu_info = detectar_gpu()

    def chave(m):
        v = m.get("vram_estimado_gb")
        cabe = v is None or gpu_info is None or classificar_encaixe(v, gpu_info) in ("gpu", "misto")
        return (not cabe, v if v is not None else 999)
    return min(candidatos, key=chave)["tag"]


def _descrever_print(imagem_b64, pedido, modelo_atual):
    """Texto descrevendo o print (janelas, botões, textos e posições em
    pixels DESTA imagem), feito por um modelo com visão. None se não
    houver nenhum ou se ele falhar."""
    visao = _modelo_de_visao(excluir=(modelo_atual,))
    if not visao:
        return None, None
    print(c(f"[openTARS] {t('msg.descrevendo_tela', modelo=modelo_atual, visao=visao)}", Cor.AMARELO))
    prompt = (
        "Describe this screenshot for an assistant that cannot see it and must operate "
        f"the computer to do: \"{pedido}\". List the open windows, the buttons, fields and "
        "texts that matter, each with its approximate center in pixel coordinates of this "
        f"image ({_escala_print.get('largura', '?')}x{_escala_print.get('altura', '?')}, origin "
        "at the top-left). Be concise and factual; no advice."
    )
    texto = _chat_unico(visao, prompt, temperatura=0.1, timeout=TIMEOUT_HTTP_LONGO,
                        keep_alive=KEEP_ALIVE, imagens=[imagem_b64])
    if not texto:
        _MODELOS_SEM_VISAO.add(visao)
        return None, None
    return texto, visao


def _print_em_texto(imagem_b64, pedido, modelo, janela=None):
    """Mensagem (sem imagem) que substitui o print pra um modelo que não
    enxerga."""
    descricao, visao = _descrever_print(imagem_b64, pedido, modelo)
    if descricao:
        if janela and _sem_arvore(janela):
            # Os nomes da descrição NÃO servem pro click_element nesse app.
            como = ("This app does not expose its buttons: click with click_mouse(x, y, target=<what it is>) "
                    "using the coordinates above (they are approximate: 'target' makes openTARS aim exactly), "
                    "and write with type_in_element(text=..., window=..., submit=true).")
        else:
            como = ("To click, use click_element(name) if the app exposes its buttons; if it fails, "
                    "use click_mouse(x, y, target=<what it is>) with the coordinates above (approximate: "
                    "'target' makes openTARS aim exactly). To drag, use drag_mouse. To write, use type_text.")
        return (
            "[Automatic message from openTARS, not from the user] You cannot see images, so "
            f"the vision model {visao} described the screenshot you took:\n{descricao}\n\n"
            f"Continue the user's request: \"{pedido}\". {como}"
        )
    return (
        "[Automatic message from openTARS, not from the user] The screenshot was taken, but "
        "you cannot see images and no vision model is installed. Don't take screenshots: "
        "use list_elements(window=<app>) to read a window's buttons and texts, and "
        f"click_element to press them. Continue the user's request: \"{pedido}\"."
    )


def _tirar_imagens_da_conversa(mensagens, pedido, modelo):
    """Troca toda imagem da conversa por texto (o modelo recusou imagem)."""
    for m in mensagens:
        imagens = m.pop("images", None)
        if imagens:
            m["content"] = _print_em_texto(imagens[-1], pedido, modelo)


# Pedido de parar a resposta atual (botão "Parar" da janela, Ctrl+C).
_cancelar = threading.Event()


class RespostaCancelada(Exception):
    pass


# O que perguntar_modelo devolve quando o usuário para a resposta.
RESPOSTA_INTERROMPIDA = "(interrompido)"


_resposta_ativa = {"r": None}


def cancelar_resposta():
    """Interrompe a resposta/tarefa em andamento assim que possível: no
    meio do texto, enquanto o Ollama ainda lê a conversa (fecha a
    conexão), ou entre uma ferramenta e outra."""
    _cancelar.set()
    resposta = _resposta_ativa["r"]
    if resposta is not None:
        try:
            resposta.close()
        except Exception:
            pass


def _verificar_cancelamento():
    if _cancelar.is_set():
        raise RespostaCancelada()


def _preparar_payload_ollama(payload):
    """Remove de antemão os parâmetros que a gente já sabe (pelo
    catálogo, via /api/show, ou por uma falha anterior nesta sessão)
    que esse modelo não aceita."""

    modelo = payload.get("model")
    payload = dict(payload)

    try:
        info = catalogar_modelos().get(modelo)
    except Exception:
        info = None

    if info and info.get("capacidades_conhecidas"):
        capacidades = info["capacidades"]
        if "tools" not in capacidades:
            _MODELOS_SEM_TOOLS.add(modelo)
        if "thinking" not in capacidades:
            _MODELOS_SEM_THINKING.add(modelo)

    if modelo in _MODELOS_SEM_THINKING:
        payload.pop("think", None)

    if modelo in _MODELOS_SEM_TOOLS:
        payload.pop("tools", None)

    return payload


def _erro_de_recurso_nao_suportado(texto, recurso):
    t = (texto or "").lower()
    return recurso in t and ("support" in t or "suport" in t)


def _chamar_ollama_stream(payload):
    """Chamada de streaming ao Ollama. Se o Ollama disser que o modelo
    não suporta 'think' ou 'tools', tenta de novo sem isso e lembra pro
    resto da sessão.

    Antes qualquer erro (falta de memória, Ollama reiniciando) disparava
    as tentativas sem think/tools, e um sucesso depois de uma falha
    passageira marcava o modelo como "sem ferramentas" pra sempre."""

    modelo = payload.get("model")
    tentativa = _preparar_payload_ollama(payload)

    for _ in range(3):
        try:
            resposta = ollama_request(tentativa, stream=True)
        except Exception as e:
            return None, t("msg.erro_comunicar_ollama", erro=e)

        if resposta.status_code == 200:
            return resposta, None

        try:
            detalhe = resposta.text
        except Exception:
            detalhe = ""

        if "think" in tentativa and _erro_de_recurso_nao_suportado(detalhe, "think"):
            _MODELOS_SEM_THINKING.add(modelo)
            tentativa = {k: v for k, v in tentativa.items() if k != "think"}
            continue

        if "tools" in tentativa and _erro_de_recurso_nao_suportado(detalhe, "tool"):
            _MODELOS_SEM_TOOLS.add(modelo)
            tentativa = {k: v for k, v in tentativa.items() if k != "tools"}
            continue

        return None, t("msg.erro_ollama_http", codigo=resposta.status_code, detalhe=detalhe.strip() or "-")

    return None, t("msg.ollama_recusou")


def _executar_turno_streaming(modelo, mensagens, tools, pensar=True):
    """Envia a conversa ao Ollama em modo streaming e vai mostrando o
    pensamento e a resposta em tempo real. Devolve conteúdo, pensamento
    e as tool_calls. pensar=False desliga o raciocínio dos modelos que
    pensam (qwen3...): ver deve_pensar()."""

    if api.eh_modelo_api(modelo):
        return _turno_api(modelo, mensagens, tools, pensar)

    payload = {
        "model": modelo,
        "messages": mensagens,
        "stream": True,
        "keep_alive": KEEP_ALIVE,
        "think": bool(pensar),
        "options": {"temperature": TEMPERATURA_CONVERSA, "num_ctx": contexto_ia()},
    }

    if tools:
        payload["tools"] = tools

    resposta, erro = _chamar_ollama_stream(payload)

    if erro:
        return None, erro

    partes_conteudo = []
    partes_pensamento = []
    tool_calls = []

    pensando_ativo = False
    escrevendo_ativo = False

    _resposta_ativa["r"] = resposta
    try:
        if _cancelar.is_set():
            raise RespostaCancelada()

        for linha in resposta.iter_lines():

            if _cancelar.is_set():
                resposta.close()
                if pensando_ativo or escrevendo_ativo:
                    emitir("fim_stream")
                raise RespostaCancelada()

            if not linha:
                continue

            try:
                chunk = json.loads(linha)
            except Exception:
                continue

            if chunk.get("error"):
                return None, t("msg.erro_ollama", detalhe=chunk["error"])

            msg = chunk.get("message", {}) or {}

            pensamento = msg.get("thinking")

            if pensamento:
                emitir("pensamento", texto=pensamento, inicio=not pensando_ativo)
                pensando_ativo = True
                partes_pensamento.append(pensamento)

            pedaco = msg.get("content")

            if pedaco:
                emitir("resposta", texto=pedaco, inicio=not escrevendo_ativo, apos_pensamento=pensando_ativo)
                escrevendo_ativo = True
                partes_conteudo.append(pedaco)

            # Versões novas do Ollama podem mandar as chamadas de
            # ferramenta em mais de um pedaço: junta todas.
            if msg.get("tool_calls"):
                tool_calls.extend(msg["tool_calls"])

            if chunk.get("done"):
                if chunk.get("done_reason") == "length":
                    print(c(f"\n[openTARS] {t('msg.limite_contexto', tokens=contexto_ia())}", Cor.AMARELO))
                break

    except RespostaCancelada:
        raise
    except Exception as e:
        if _cancelar.is_set():  # conexão fechada pelo botão Parar
            if pensando_ativo or escrevendo_ativo:
                emitir("fim_stream")
            raise RespostaCancelada()
        return None, t("msg.erro_streaming", erro=e)
    finally:
        _resposta_ativa["r"] = None

    if pensando_ativo or escrevendo_ativo:
        emitir("fim_stream")

    return {
        "content": "".join(partes_conteudo).strip(),
        "thinking": "".join(partes_pensamento).strip(),
        "tool_calls": tool_calls,
    }, None


def _turno_api(modelo, mensagens, tools, pensar=True):
    """Igual a _executar_turno_streaming, num servidor compatível com a
    OpenAI (vLLM, LM Studio, llama.cpp): mesmos eventos na tela, mesma
    resposta (conteúdo, pensamento, chamadas no formato do Ollama)."""
    corpo = api.corpo_chat(modelo, mensagens, tools=tools, stream=True, temperatura=TEMPERATURA_CONVERSA)
    try:
        resposta = _post_api(corpo, stream=True)
        if resposta.status_code != 200 and tools and resposta.status_code in (400, 422):
            detalhe = resposta.text[:300]
            if "tool" in detalhe.lower():
                resposta.close()
                _MODELOS_SEM_TOOLS.add(modelo)
                corpo.pop("tools", None)
                resposta = _post_api(corpo, stream=True)
        if resposta.status_code != 200:
            detalhe = resposta.text[:300].strip()
            resposta.close()
            return None, t("msg.erro_servidor_api", codigo=resposta.status_code, detalhe=detalhe)
    except requests.exceptions.ConnectionError:
        return None, t("msg.servidor_api_offline", url=servidor_api())
    except Exception as e:
        return None, t("msg.erro_streaming", erro=e)

    leitor = api.LeitorStream()
    pensando_ativo = escrevendo_ativo = False
    _resposta_ativa["r"] = resposta
    try:
        for linha in resposta.iter_lines():
            if _cancelar.is_set():
                resposta.close()
                if pensando_ativo or escrevendo_ativo:
                    emitir("fim_stream")
                raise RespostaCancelada()
            for tipo, valor in leitor.alimentar(linha):
                if tipo == "pensamento" and pensar:
                    emitir("pensamento", texto=valor, inicio=not pensando_ativo)
                    pensando_ativo = True
                elif tipo == "resposta":
                    emitir("resposta", texto=valor, inicio=not escrevendo_ativo, apos_pensamento=pensando_ativo)
                    escrevendo_ativo = True
                elif tipo == "erro":
                    return None, t("msg.erro_servidor_api", codigo="stream", detalhe=valor)
            if leitor.terminou:
                break
    except RespostaCancelada:
        raise
    except Exception as e:
        if _cancelar.is_set():
            if pensando_ativo or escrevendo_ativo:
                emitir("fim_stream")
            raise RespostaCancelada()
        return None, t("msg.erro_streaming", erro=e)
    finally:
        _resposta_ativa["r"] = None
        resposta.close()

    if pensando_ativo or escrevendo_ativo:
        emitir("fim_stream")
    if leitor.motivo == "length":
        print(c(f"\n[openTARS] {t('msg.limite_contexto', tokens=contexto_ia())}", Cor.AMARELO))
    conteudo = re.sub(r"<think>.*?</think>", "", "".join(leitor.conteudo), flags=re.DOTALL).strip()
    return {"content": conteudo, "thinking": "".join(leitor.pensamento).strip(),
            "tool_calls": leitor.chamadas}, None


LIMITE_CUTUCADAS_RESPOSTA_VAZIA = 2

# Falhas seguidas: a partir de 3 da MESMA ferramenta, a IA é mandada
# mudar de estratégia; com 8 de qualquer uma, para e explica ao usuário.
LIMITE_FALHAS_MESMA_FERRAMENTA = 3
LIMITE_FALHAS_SEGUIDAS = 8


# Mensagens automáticas (vão pra IA, com role=user): começam com "[" —
# é assim que _e_pedido_do_usuario sabe que não foi a pessoa que escreveu.

def _mensagem_do_print(pedido):
    return (
        "[Automatic message from openTARS, not from the user] This is the "
        "screenshot you took with take_screenshot. Use it to continue the "
        f"user's request: \"{pedido}\". To click, use pixel coordinates of this "
        "image. Don't describe the image: go on with the next action (or answer, "
        "if the task is done)."
    )


def _mensagem_use_ferramentas(pedido):
    return (
        "[Automatic message from openTARS] You DO have tools for this "
        "(open_application, close_application, click_element, take_screenshot, "
        "execute_terminal and others). Don't say you can't: call the right tool "
        f"now for the user's request: \"{pedido}\"."
    )


_PADROES_SUCESSO = [re.compile(p) for p in (
    r"^(pronto|feito|prontinho|done|all set|finished|listo|hecho|c'?est fait|voila|fertig|erledigt)\b",
    r"\b(abri|fechei|cliquei|enviei|digitei|pesquisei|criei|apaguei|movi|executei|consegui)\b",
    r"\b(i (have )?(opened|closed|clicked|sent|typed|searched|created|deleted|moved|ran))\b",
    r"\b(successfully|com sucesso|con exito|avec succes|erfolgreich)\b",
)]


def _diz_que_conseguiu(texto):
    t = normalizar(texto or "")
    return bool(t) and len(t) < 1200 and any(p.search(t) for p in _PADROES_SUCESSO) \
        and not _parece_recusa(texto)


def _mensagem_sucesso_falso(pedido):
    return (
        "[Automatic message from openTARS] Careful: your LAST tool call FAILED (see its result), "
        "so the task is not done yet. Either fix it now with another approach, or tell the user "
        f"honestly what did not work. Don't say it worked. Request: \"{pedido}\"."
    )


LIMITE_REESCALAR = 2          # trocas de modelo por pedido (erro, recusa, nada funcionou)
LIMITE_JANELAS_CONTEXTO = 8
CONTEXTO_JANELAS = os.environ.get("TARS_CONTEXTO_JANELAS", "1") not in ("0", "off", "nao", "no")


def _mensagem_sem_ferramenta(pedido):
    return (
        "[Automatic message from openTARS] You answered as if it were done, but you did NOT call "
        "any tool, so nothing happened on the computer. Call the right tool(s) now to actually do "
        f"it: \"{pedido}\". Only after a tool result confirms it, say it's done."
    )


def _mensagem_outro_modelo(pedido):
    return (
        "[Automatic message from openTARS] The attempts above (by another model) all failed. You "
        "are taking over: use a DIFFERENT approach from the ones that failed (another tool, "
        "another window name, typing instead of clicking...). If there is really no way, tell the "
        f"user what blocks it. Request: \"{pedido}\"."
    )


def _desfecho(tarefa, conteudo, usou_ferramenta, algum_sucesso, mentiu):
    """Pro histórico do modelo: deu certo (True), falhou (False) ou não dá
    pra dizer (None: ex. todas as ferramentas falharam por causa do
    computador e a IA explicou direito)."""
    if not conteudo or mentiu:
        return False
    if _parece_recusa(conteudo) and not usou_ferramenta:
        return False
    if tarefa in ("acao", "visao", "busca"):
        return True if algum_sucesso else None
    return True


def _janelas_para_contexto():
    try:
        janelas = listar_janelas_x()
        ativa = janela_ativa_x() if janelas else None
    except Exception:
        return []
    if not janelas:
        return []
    protegidos = _pids_protegidos()
    saida = []
    for j in janelas:
        titulo = (j.get("titulo") or "").strip()
        if not titulo or j.get("pid") in protegidos:
            continue
        titulo = titulo if len(titulo) <= 50 else titulo[:47] + "..."
        saida.append(f"'{titulo}'" + (" (focused)" if j.get("id") == ativa else ""))
        if len(saida) >= LIMITE_JANELAS_CONTEXTO:
            break
    return saida


def _contexto_do_pedido(texto, tarefa, multi_etapas):
    """O que a IA precisa saber antes de agir: as janelas abertas (não
    precisa abrir o que já está aberto, sabe o nome certo da janela) e, se
    o pedido tem várias etapas, que é pra fazer TODAS."""
    linhas = []
    if CONTEXTO_JANELAS and tarefa in ("acao", "visao"):
        janelas = _janelas_para_contexto()
        if janelas:
            linhas.append("Open windows right now: " + "; ".join(janelas) + ".")
    if multi_etapas:
        partes = _etapas_do_pedido(texto)
        if len(partes) >= 2:
            plano = " ".join(f"{i}. {p}" for i, p in enumerate(partes, 1))
            linhas.append(f"This request has {len(partes)} steps. Plan: {plano}. Do ALL of them, in order, "
                          "checking each one worked (its tool result) before the next, and only then give "
                          "your final answer (don't stop after the first one).")
    if rotinas_lib.fala_de_agenda(texto):
        # A hora vai aqui, e não no prompt de sistema: mudar o começo da
        # conversa a cada minuto faria o Ollama reler tudo a cada pedido.
        linhas.append(f"Now it is {time.strftime('%A %H:%M')}.")
    if not linhas:
        return None
    return "[Context from openTARS, not a new request] " + " ".join(linhas)


# ------------------------------------------------------------
# 3.0: planejar e conferir
# ------------------------------------------------------------
# Ferramentas que só OLHAM (não contam como etapa feita).
_FERRAMENTAS_SO_OLHAM = {
    "take_screenshot", "list_elements", "list_windows", "list_files", "pc_info", "wait_seconds",
}


def _etapas_do_pedido(texto):
    return escolha.partes_do_pedido(normalizar(texto), _verbos_de_acao())


def _mensagem_plano_incompleto(pedido, etapas, feitas):
    lista = " ".join(f"{i}. {p}" for i, p in enumerate(etapas, 1))
    return (
        f"[Automatic message from openTARS] Plan check: this request has {len(etapas)} steps ({lista}), "
        f"but only {feitas} action(s) worked so far. Do the missing step(s) now. If one really cannot "
        f"be done, tell the user which one and why. Don't say everything is done. Request: \"{pedido}\"."
    )


def _mensagem_sem_efeito(pedido):
    return (
        "[Automatic message from openTARS] Your last click/drag changed NOTHING on screen, so it "
        "probably missed. Check (take_screenshot or list_elements) and retry with target=<what to "
        "click> before saying it's done; if it really can't be done, tell the user honestly. "
        f"Request: \"{pedido}\"."
    )


def _mensagem_faca_voce(pedido):
    return (
        "[Automatic message from openTARS] Don't hand the task back to the user: you have the "
        "tools to do it yourself. Read the last tool result again and follow the way it gives "
        "(e.g. type_in_element with window and submit=true to write in an app that doesn't expose "
        "its buttons, or take_screenshot + click_mouse). If you must invent content (a question, a "
        f"message), invent it. Do it now for: \"{pedido}\"."
    )


def _mensagem_continuar(pedido):
    return (
        "[Automatic message from openTARS] You neither called a tool nor "
        f"answered. Continue the user's request: \"{pedido}\" — call the next "
        "tool or, if you are done, say in one sentence what was done."
    )


_NOMES_FERRAMENTAS = None


def _ferramentas_no_texto(texto):
    """Chamadas de ferramenta escritas no texto da resposta, no formato
    [{"function": {"name", "arguments"}}], ou [] se não houver."""
    global _NOMES_FERRAMENTAS
    if _NOMES_FERRAMENTAS is None:
        _NOMES_FERRAMENTAS = {f["function"]["name"] for f in TOOLS}
    if '"name"' not in texto or not any(nome in texto for nome in _NOMES_FERRAMENTAS):
        return []
    decodificador = json.JSONDecoder()
    chamadas, pos = [], 0
    while True:
        pos = texto.find("{", pos)
        if pos < 0:
            break
        try:
            obj, fim = decodificador.raw_decode(texto, pos)
        except ValueError:
            pos += 1
            continue
        pos = fim
        if isinstance(obj, dict) and isinstance(obj.get("function"), dict):
            obj = obj["function"]
        argumentos = obj.get("arguments", obj.get("parameters")) if isinstance(obj, dict) else None
        if isinstance(argumentos, str):
            try:
                argumentos = json.loads(argumentos)
            except ValueError:
                argumentos = None
        if isinstance(obj, dict) and obj.get("name") in _NOMES_FERRAMENTAS and isinstance(argumentos, dict):
            chamadas.append({"function": {"name": obj["name"], "arguments": argumentos}})
    return chamadas


def _argumentos_da_chamada(funcao):
    argumentos = funcao.get("arguments", {})
    if isinstance(argumentos, str):
        try:
            argumentos = json.loads(argumentos)
        except Exception:
            argumentos = {}
    return argumentos if isinstance(argumentos, dict) else {}


def _carregar_com_fallback(modelo, tarefa):
    """Carrega o modelo pedido; no modo AUTO, se falhar, desce a cadeia
    de alternativas da tarefa."""

    candidatos = [modelo]
    if modo_modelo == "AUTO" and tarefa:
        candidatos += [m for m in construir_cadeia_fallback(tarefa) if m != modelo]

    for candidato in candidatos:
        if carregar_modelo(candidato):
            return candidato, candidatos
        print(c(f"[AUTO] {t('msg.falha_carregar_alternativa', modelo=candidato)}", Cor.AMARELO))

    return None, candidatos


# Resultados de ferramenta vão pra IA com chaves em inglês (o código usa
# as chaves em português; a IA entende melhor um JSON todo em inglês).
_CHAVES_PARA_IA = {
    "sucesso": "success", "mensagem": "message", "acao": "action", "aplicativo": "app",
    "encontrado_como": "found_as", "janela": "window", "janelas": "windows",
    "janelas_fechadas": "closed_windows", "janelas_abertas": "open_windows",
    "titulo": "title", "largura": "width", "altura": "height", "minimizada": "minimized",
    "em_foco": "focused", "diretorio": "directory", "caminho": "path", "arquivos": "files",
    "codigo": "exit_code", "entrada": "input", "servico": "service",
    "ram_percentual": "ram_percent", "ram_disponivel_gb": "ram_available_gb",
    "disco_percentual": "disk_percent", "disco_livre_gb": "disk_free_gb",
    "elementos": "elements", "elemento": "element", "textos": "texts",
}


def _para_ia(valor):
    if isinstance(valor, dict):
        return {_CHAVES_PARA_IA.get(k, k): _para_ia(v) for k, v in valor.items()}
    if isinstance(valor, list):
        return [_para_ia(v) for v in valor]
    return valor


def perguntar_modelo(modelo, texto, tarefa=None, multi_etapas=False):

    pendentes = []  # ferramentas pedidas e ainda não executadas neste ciclo

    try:
        modelo_carregado, tentados = _carregar_com_fallback(modelo, tarefa)
    except OllamaOffline:
        modelo_carregado, tentados = None, [modelo]

    if not modelo_carregado and not ollama_online():
        # "Não consegui carregar o modelo" escondia a causa: o Ollama
        # está desligado (ex: parado pra usar o vLLM).
        mensagem_erro = t("aviso.ollama_offline", host=OLLAMA_HOST)
        print(c(f"\n[openTARS] {mensagem_erro}", Cor.VERMELHO))
        return mensagem_erro

    if not modelo_carregado:
        mensagem_erro = t("msg.nenhum_modelo_carregou", tentados=", ".join(tentados))
        print(c(f"\n[openTARS] {mensagem_erro}", Cor.VERMELHO))
        return mensagem_erro

    modelo = modelo_carregado
    usados = [modelo]
    mensagens = obter_sessao(modelo)
    _remover_turnos_recusados(mensagens)
    mensagens.append({"role": "user", "content": texto})
    contexto = _contexto_do_pedido(texto, tarefa, multi_etapas)
    if contexto:
        mensagens.append({"role": "user", "content": contexto})

    inicio_total = time.time()
    cutucadas = 0
    usou_ferramenta = False
    lembrou_ferramentas = False
    pensar = deve_pensar(tarefa, texto, multi_etapas)
    janela_do_print = None
    ultima_falhou = insistiu = conferiu_sucesso = cobrou_acao = False
    algum_sucesso = mentiu = False
    desfecho = None               # pro histórico: True deu certo, False falhou, None não conta
    reescaladas = 0
    ferramentas = ferramentas_do_pedido(tarefa, texto)
    falhas_seguidas = {}          # ferramenta -> falhas desde o último sucesso
    chamadas_que_falharam = {}    # (ferramenta, argumentos) -> motivo
    # 3.0: planejar e conferir
    etapas = _etapas_do_pedido(texto) if multi_etapas else []
    acoes_feitas = 0              # ações (não só olhar) que deram certo DE VERDADE
    sem_efeito_seguidos = 0       # cliques/arrastos "certos" que não mudaram a tela
    ultima_sem_efeito = cobrou_plano = cobrou_efeito = False
    if len(etapas) >= 2:
        emitir("plano", etapas=etapas)

    def trocar_de_modelo(chave_mensagem):
        """Passa o pedido pro próximo modelo da fila (no modo AUTO, até
        LIMITE_REESCALAR vezes por pedido). O que falhou fica no placar."""
        nonlocal modelo, reescaladas
        if modo_modelo != "AUTO" or reescaladas >= LIMITE_REESCALAR:
            return False
        fila = construir_cadeia_fallback(tarefa_da_fila(tarefa or "acao", multi_etapas))
        proximo = next((m for m in fila if m not in usados), None)
        if not proximo:
            return False
        try:
            if not carregar_modelo(proximo):
                return False
        except OllamaOffline:
            return False
        historico_modelos.registrar(modelo, _tarefa_do_historico(tarefa), False)
        print(c(f"[AUTO] {t(chave_mensagem, modelo=modelo, novo=proximo)}", Cor.AMARELO))
        usados.append(proximo)
        modelo = proximo
        reescaladas += 1
        return True

    try:
        for ciclo in range(LIMITE_CICLOS_FERRAMENTAS):

            _verificar_cancelamento()

            imagem_no_turno = any(m.get("images") for m in mensagens)

            resultado, erro = _executar_turno_streaming(modelo, mensagens, ferramentas, pensar=pensar)

            if erro and imagem_no_turno and _erro_de_imagem(erro):
                # "Model does not support multimodal": esse modelo não
                # enxerga. Toda imagem da conversa vira texto (descrita
                # por um modelo com visão) e as ferramentas continuam.
                _MODELOS_SEM_VISAO.add(modelo)
                _tirar_imagens_da_conversa(mensagens, texto, modelo)
                resultado, erro = _executar_turno_streaming(modelo, mensagens, ferramentas, pensar=pensar)
            elif erro and imagem_no_turno:
                # Alguns Ollama antigos não aceitam 'tools' junto com
                # imagem: tenta de novo sem as ferramentas.
                print(c(f"[openTARS] {t('msg.imagem_sem_ferramentas', erro=erro)}", Cor.AMARELO))
                resultado, erro = _executar_turno_streaming(modelo, mensagens, None, pensar=pensar)

            if erro:
                # Modelo que quebrou (sem memória, chamada de ferramenta que
                # o Ollama não entendeu...): o próximo da fila continua a
                # MESMA conversa, com o que já foi feito.
                if not _erro_de_imagem(erro) and trocar_de_modelo("msg.tentando_outro_modelo"):
                    continue
                desfecho = False
                print(c(f"\n[openTARS] {erro}", Cor.VERMELHO))
                return erro

            conteudo = resultado["content"]
            tool_calls = resultado["tool_calls"]

            # Modelo que escreve a chamada da ferramenta como TEXTO
            # (<tool_call>{...}</tool_call>, um JSON solto): vira chamada
            # de verdade, em vez de aparecer pro usuário como resposta.
            if not tool_calls and conteudo:
                no_texto = _ferramentas_no_texto(conteudo)
                if no_texto:
                    tool_calls, conteudo = no_texto, ""

            if not tool_calls and not conteudo and ciclo > 0 and cutucadas < LIMITE_CUTUCADAS_RESPOSTA_VAZIA:
                # Modelo "pensou" mas não respondeu nem chamou ferramenta
                # no meio de uma tarefa: pede pra continuar em vez de
                # encerrar pela metade.
                cutucadas += 1
                print(c(f"[openTARS] {t('msg.ia_parou')}", Cor.AMARELO))
                mensagens.append({"role": "user", "content": _mensagem_continuar(texto)})
                continue

            if (
                not tool_calls and not usou_ferramenta and not lembrou_ferramentas
                and modelo not in _MODELOS_SEM_TOOLS and _parece_recusa(conteudo)
            ):
                # "Não consigo abrir aplicativos": lembra que consegue, uma
                # vez. A recusa não entra no histórico.
                lembrou_ferramentas = True
                ferramentas = ferramentas_do_pedido(None, texto)  # talvez faltasse a ferramenta certa
                print(c(f"[openTARS] {t('msg.ia_recusou')}", Cor.AMARELO))
                mensagens.append({"role": "user", "content": _mensagem_use_ferramentas(texto)})
                continue

            if (
                not tool_calls and not usou_ferramenta and lembrou_ferramentas
                and modo_modelo == "AUTO" and _parece_recusa(conteudo)
            ):
                # Recusou de novo mesmo lembrado: esse modelo não serve pra
                # esse pedido. Passa pro próximo da fila (uma vez).
                proximo = next((m for m in construir_cadeia_fallback(tarefa or "acao")
                                if m not in usados), None)
                try:
                    carregou = bool(proximo) and carregar_modelo(proximo)
                except OllamaOffline:
                    carregou = False
                if carregou:
                    historico_modelos.registrar(modelo, _tarefa_do_historico(tarefa), False)
                    print(c(f"[AUTO] {t('msg.trocando_modelo', modelo=modelo, novo=proximo)}", Cor.AMARELO))
                    usados.append(proximo)
                    modelo = proximo
                    lembrou_ferramentas = False
                    while mensagens and mensagens[-1].get("role") == "user" and mensagens[-1].get("content", "").startswith("["):
                        mensagens.pop()
                    continue

            if (
                not tool_calls and usou_ferramenta and ultima_falhou and not insistiu
                and tarefa in ("acao", "visao", None) and _devolveu_pro_usuario(conteudo)
            ):
                # Uma ferramenta falhou e a IA mandou o usuário fazer na mão
                # ("clique na caixa e digite"), com as ferramentas certas
                # disponíveis. Uma vez: manda ela mesma fazer.
                insistiu = True
                ferramentas = ferramentas_do_pedido(None, texto)
                print(c(f"[openTARS] {t('msg.ia_recusou')}", Cor.AMARELO))
                mensagens.append({"role": "user", "content": _mensagem_faca_voce(texto)})
                continue

            if (
                not tool_calls and usou_ferramenta and ultima_falhou and not conferiu_sucesso
                and _diz_que_conseguiu(conteudo)
            ):
                # "Pronto, abri!" logo depois de uma ferramenta que FALHOU:
                # a IA está inventando. Uma vez: conserta ou conta a verdade.
                conferiu_sucesso = mentiu = True
                mensagens.append({"role": "user", "content": _mensagem_sucesso_falso(texto)})
                continue

            if (
                not tool_calls and not usou_ferramenta and not cobrou_acao
                and tarefa in ("acao", "visao") and modelo not in _MODELOS_SEM_TOOLS
                and _diz_que_conseguiu(conteudo)
            ):
                # "Pronto, abri o Firefox!" sem ter chamado ferramenta
                # nenhuma: nada aconteceu no computador. Uma vez: faça.
                cobrou_acao = mentiu = True
                ferramentas = ferramentas_do_pedido(None, texto)
                mensagens.append({"role": "user", "content": _mensagem_sem_ferramenta(texto)})
                continue

            if (
                not tool_calls and usou_ferramenta and ultima_sem_efeito and not cobrou_efeito
                and _diz_que_conseguiu(conteudo)
            ):
                # "Pronto!" logo depois de um clique que não mudou nada na
                # tela: confere antes. Uma vez.
                cobrou_efeito = mentiu = True
                mensagens.append({"role": "user", "content": _mensagem_sem_efeito(texto)})
                continue

            if (
                not tool_calls and len(etapas) >= 2 and acoes_feitas < len(etapas) and not cobrou_plano
                and tarefa in ("acao", "visao", None) and modelo not in _MODELOS_SEM_TOOLS
            ):
                # Pedido de várias etapas encerrado antes de fazer todas:
                # mostra o plano e o que falta. Uma vez.
                cobrou_plano = True
                print(c(f"[openTARS] {t('msg.plano_incompleto', feitas=acoes_feitas, total=len(etapas))}",
                        Cor.AMARELO))
                mensagens.append({"role": "user", "content": _mensagem_plano_incompleto(texto, etapas,
                                                                                          acoes_feitas)})
                continue

            if not tool_calls:
                mensagens.append({"role": "assistant", "content": conteudo})
                if not conteudo:
                    print(c(f"[openTARS] {t('msg.sem_texto', modelo=modelo)}", Cor.AMARELO))
                desfecho = _desfecho(tarefa, conteudo, usou_ferramenta, algum_sucesso, mentiu)
                emitir("tempo", modo=modo_modelo, modelo=modelo, segundos=time.time() - inicio_total)
                return conteudo

            mensagens.append({"role": "assistant", "content": conteudo, "tool_calls": tool_calls})
            usou_ferramenta = True
            desistiu = False
            pendentes[:] = [ch.get("function", {}).get("name", "") for ch in tool_calls]
            ultima_imagem = None

            for chamada in tool_calls:

                _verificar_cancelamento()

                funcao = chamada.get("function", {})
                nome = funcao.get("name", "")
                argumentos = _argumentos_da_chamada(funcao)
                chave_chamada = (nome, json.dumps(argumentos, sort_keys=True, ensure_ascii=False))
                oferecidas = {f["function"]["name"] for f in ferramentas}
                if nome in _FERRAMENTAS_SO_SE_PEDIDAS and nome not in oferecidas:
                    # Memória/agenda só quando o PEDIDO fala disso: uma página
                    # lida ou um modelo confuso não apaga a memória nem agenda nada.
                    resultado_ferramenta = {"sucesso": False, "mensagem": (
                        f"{nome} is not available for this request (the user did not ask to remember, "
                        "forget or schedule anything). Don't use it.")}
                elif chave_chamada in chamadas_que_falharam:
                    # Mesma chamada, mesmos argumentos, já falhou neste pedido.
                    resultado_ferramenta = {"sucesso": False, "mensagem": (
                        f"You already tried exactly this {nome} call and it failed: "
                        f"{chamadas_que_falharam[chave_chamada]} Do something different.")}
                else:
                    resultado_ferramenta = executar_ferramenta(nome, argumentos)
                pendentes.pop(0)
                if nome == "take_screenshot":
                    janela_do_print = argumentos.get("window") or None

                ultima_falhou = not resultado_ferramenta.get("sucesso")
                sem_efeito = bool(resultado_ferramenta.get("sem_efeito"))
                if nome not in _FERRAMENTAS_SO_OLHAM:
                    ultima_sem_efeito = sem_efeito
                if resultado_ferramenta.get("sucesso") and sem_efeito:
                    # "Clicou", mas a tela não mudou: não é progresso. Conta
                    # pra desistir (andar em círculos clicando no nada).
                    sem_efeito_seguidos += 1
                    if sum(falhas_seguidas.values()) + sem_efeito_seguidos >= LIMITE_FALHAS_SEGUIDAS:
                        desistiu = True
                elif resultado_ferramenta.get("sucesso"):
                    algum_sucesso = True
                    falhas_seguidas.clear()
                    sem_efeito_seguidos = 0
                    if nome not in _FERRAMENTAS_SO_OLHAM:
                        acoes_feitas += 1
                else:
                    chamadas_que_falharam[chave_chamada] = str(resultado_ferramenta.get("mensagem", ""))[:300]
                    falhas_seguidas[nome] = falhas_seguidas.get(nome, 0) + 1
                    total_falhas = sum(falhas_seguidas.values()) + sem_efeito_seguidos
                    if falhas_seguidas[nome] >= LIMITE_FALHAS_MESMA_FERRAMENTA:
                        resultado_ferramenta["mensagem"] = (
                            f"{resultado_ferramenta.get('mensagem', '')} STOP: {nome} failed "
                            f"{falhas_seguidas[nome]} times in a row. Don't call it again for this; "
                            "change approach (another tool) or tell the user what is blocking you."
                        )
                    if total_falhas >= LIMITE_FALHAS_SEGUIDAS:
                        desistiu = True

                # A imagem do print nunca entra no JSON de texto (custaria
                # uma fortuna de tokens): vai como mensagem de visão.
                imagem_b64 = resultado_ferramenta.pop("_imagem_b64", None)
                if imagem_b64:
                    ultima_imagem = imagem_b64

                mensagens.append({
                    "role": "tool",
                    "tool_name": nome,  # ajuda o modelo a ligar resultado e chamada
                    "content": json.dumps(_para_ia(resultado_ferramenta), ensure_ascii=False),
                })

            # A imagem vai DEPOIS de todos os resultados: cada resultado
            # tem que vir logo após as chamadas que o geraram.
            if ultima_imagem and not modelo_enxerga(modelo):
                # Modelo sem visão: o print não vai (o Ollama recusaria o
                # pedido inteiro); vai a descrição em texto.
                mensagens.append({"role": "user", "content": _print_em_texto(ultima_imagem, texto, modelo, janela_do_print)})
            elif ultima_imagem:
                # Prints antigos saem da conversa: cada um ocupa ~1 mil
                # tokens de contexto e só a tela atual importa.
                for anterior in mensagens:
                    if anterior.get("images"):
                        anterior.pop("images")
                        anterior["content"] = "[previous screenshot removed: see the latest one]"

                # Vai como "user" (é onde o Ollama aceita imagem), mas
                # sem parecer um pedido novo: antes o modelo lia
                # "usuário mandou um print" e esquecia a tarefa.
                mensagens.append({
                    "role": "user",
                    "content": _mensagem_do_print(texto),
                    "images": [ultima_imagem],
                })

            if desistiu and not algum_sucesso and trocar_de_modelo("msg.tentando_outro_modelo"):
                # Nada funcionou (e nada mudou no computador): outro modelo
                # tenta, vendo o que já falhou (e sem poder repetir igual).
                falhas_seguidas.clear()
                sem_efeito_seguidos = 0
                desistiu = False
                mensagens.append({"role": "user", "content": _mensagem_outro_modelo(texto)})
                continue

            if desistiu:
                desfecho = False
                # Muitas falhas seguidas: a IA está andando em círculos.
                # Uma última rodada SEM ferramentas pra ela explicar ao
                # usuário o que travou, em vez de gastar as 20 etapas.
                print(c(f"[openTARS] {t('msg.muitas_falhas', n=LIMITE_FALHAS_SEGUIDAS)}", Cor.AMARELO))
                mensagens.append({"role": "user", "content": (
                    "[Automatic message from openTARS] Too many tool calls failed in a row. Stop "
                    "using tools: in 2-3 sentences, tell the user what you tried, what blocked you, "
                    "and what they can do (e.g. click it themselves, or another way to ask).")})
                resultado, erro = _executar_turno_streaming(modelo, mensagens, None, pensar=False)
                conteudo = (resultado or {}).get("content") or t("msg.muitas_falhas", n=LIMITE_FALHAS_SEGUIDAS)
                mensagens.append({"role": "assistant", "content": conteudo})
                emitir("tempo", modo=modo_modelo, modelo=modelo, segundos=time.time() - inicio_total)
                return conteudo

            emitir("analisando", modelo=modelo)

        desfecho = False
        mensagem_limite = t("msg.limite_etapas", n=LIMITE_CICLOS_FERRAMENTAS)
        print(c(f"\n[openTARS] {mensagem_limite}", Cor.VERMELHO))
        return mensagem_limite

    except (RespostaCancelada, KeyboardInterrupt):
        _cancelar.clear()
        # Toda chamada de ferramenta precisa de um resultado, senão o
        # próximo pedido vai com a conversa quebrada.
        for nome in pendentes:
            mensagens.append({
                "role": "tool",
                "tool_name": nome,
                "content": json.dumps({"success": False, "message": "Cancelled by the user."}),
            })
        mensagens.append({"role": "assistant", "content": "(interrupted by the user)"})
        print(c(f"\n[openTARS] {t('msg.interrompido')}", Cor.AMARELO))
        return RESPOSTA_INTERROMPIDA

    finally:
        _podar_historico(mensagens)
        if tarefa and modo_modelo == "AUTO":
            historico_modelos.registrar(modelo, _tarefa_do_historico(tarefa), desfecho)


def processar_mensagem(texto):
    """Um pedido do usuário do começo ao fim: comandos (/modelo,
    /limpar...), escolha do modelo, resposta e salvamento. Usado pelo
    terminal e pela janela, que antes repetiam essa lógica cada um."""

    # Limpa aqui (e não no meio do caminho): um Parar apertado enquanto
    # o openTARS ainda escolhe o modelo continua valendo.
    _cancelar.clear()

    if interpretar_comando_modelo(texto):
        return None

    tarefa = detectar_tarefa(texto) if modo_modelo == "AUTO" else None
    decisao = _ultima_decisao["d"] if tarefa else None
    if tarefa:
        lembrar_tarefa(tarefa)
    # Várias etapas também contam no modo MANUAL (pensar + lembrete).
    multi = decisao.multi_etapas if decisao else escolha.eh_multi_etapas(normalizar(texto), _verbos_de_acao())
    modelo = escolher_modelo(texto, tarefa=tarefa, complexa=multi)

    emitir("tarefa", modo=modo_modelo, tarefa=tarefa, modelo=modelo, via=decisao.via if decisao else None)

    try:
        return perguntar_modelo(modelo, texto, tarefa=tarefa, multi_etapas=multi)
    finally:
        salvar_sessoes()
