# openTARS — nucleo/rotinas.py
# Rotinas (pedidos agendados) e memória de preferências (3.0): as
# ferramentas que a IA usa e o agendador que roda os pedidos na hora.
# A lógica (horários, arquivos) fica em tars_rotinas.py.
#
# Parte do núcleo: o tars.py executa este arquivo DENTRO do próprio
# namespace (ver _carregar_nucleo), então tudo aqui é tars.<nome> e as
# partes enxergam umas às outras sem import. Os testes que trocam
# tars.<função> por uma falsa continuam valendo pra todas as partes.
# flake8: noqa

# ============================================================
# ROTINAS E MEMÓRIA
# ============================================================

rotinas = rotinas_lib.Rotinas()
memoria = rotinas_lib.Memoria()

# Um pedido por vez: o agendador espera o que estiver em andamento.
TRAVA_PEDIDO = threading.RLock()


def agendar_rotina(a):
    rotina, erro = rotinas.criar(a.get("request") or a.get("task"), a.get("time"), a.get("days"),
                                 a.get("in_minutes"))
    if erro:
        return {"sucesso": False, "mensagem": f"ERROR: {erro}."}
    quando = rotinas.descrever(rotina)
    return {"sucesso": True, "id": rotina["id"], "mensagem": (
        f"SUCCESS: scheduled \"{rotina['pedido']}\" ({quando}), id {rotina['id']}. It runs while openTARS is "
        "open (window, quick bar or terminal). Tell the user when it will run.")}


def listar_rotinas_ferramenta(_a=None):
    lista = rotinas.listar()
    if not lista:
        return {"sucesso": True, "mensagem": "No scheduled tasks."}
    linhas = [f"{r['id']}: \"{r['pedido']}\" — {rotinas.descrever(r)}" for r in lista]
    return {"sucesso": True, "rotinas": linhas, "mensagem": f"{len(lista)} scheduled task(s)."}


def cancelar_rotina_ferramenta(a):
    alvo = a.get("id") or a.get("request") or ""
    fora = rotinas.cancelar(alvo)
    if not fora:
        return {"sucesso": False, "mensagem": f"No scheduled task matches '{alvo}'. Use list_scheduled_tasks."}
    return {"sucesso": True, "mensagem": "SUCCESS: cancelled " + "; ".join(f"\"{r['pedido']}\"" for r in fora) + "."}


def lembrar_ferramenta(a):
    ok, erro = memoria.lembrar(a.get("fact") or a.get("text") or "")
    if not ok:
        return {"sucesso": False, "mensagem": f"ERROR: {erro}."}
    return {"sucesso": True, "mensagem": "SUCCESS: saved. It will be in your instructions from now on."}


def esquecer_ferramenta(a):
    fora = memoria.esquecer(a.get("fact") or a.get("text") or "")
    if not fora:
        return {"sucesso": False, "mensagem": "Nothing saved matches that. The saved facts are in your instructions."}
    return {"sucesso": True, "mensagem": "SUCCESS: forgot: " + "; ".join(fora)}


TOOLS_ROTINAS = [
    _ferramenta(
        "schedule_task",
        "Schedules a request to run later, by itself, as if the user typed it then: at a time, repeating "
        "on some days ('every day at 08:00 open gmail and spotify'), or once ('in 10 minutes remind me to "
        "take the cake out' -> request='show a reminder: take the cake out', in_minutes=10).",
        {
            "request": {"type": "string", "description": "What to do, written as the user would ask it."},
            "time": {"type": "string", "description": "HH:MM, 24h (e.g. '08:00', '19:30')."},
            "days": {"type": "string", "description": "'daily' (default), 'weekdays', 'weekends', 'once', or days "
                                                      "like 'mon,wed,fri'."},
            "in_minutes": {"type": "number", "description": "Instead of time: run once, in this many minutes."},
        },
        ["request"],
    ),
    _ferramenta("list_scheduled_tasks", "Lists the scheduled tasks (id, request, when)."),
    _ferramenta(
        "cancel_scheduled_task",
        "Cancels a scheduled task by its id or by words of its request.",
        {"id": {"type": "string", "description": "Id or words of the request."}},
        ["id"],
    ),
    _ferramenta(
        "remember",
        "Saves a short fact the user wants you to remember in every future conversation (their browser, "
        "folders, names, preferences). Only when the user asks to remember, or states a lasting preference.",
        {"fact": {"type": "string", "description": "The fact, short and in the user's words."}},
        ["fact"],
    ),
    _ferramenta(
        "forget",
        "Forgets saved facts that contain these words ('*' forgets everything).",
        {"fact": {"type": "string"}},
        ["fact"],
    ),
]
TOOLS.extend(TOOLS_ROTINAS)
_cache_esquemas.clear()
_NOMES_FERRAMENTAS_ROTINAS = {f["function"]["name"] for f in TOOLS_ROTINAS}
_FERRAMENTAS_MEMORIA = {"remember", "forget"}
_FERRAMENTAS_AGENDA = {"schedule_task", "list_scheduled_tasks", "cancel_scheduled_task"}
_FERRAMENTAS_SO_SE_PEDIDAS.update(_NOMES_FERRAMENTAS_ROTINAS)

_DISPATCH_FERRAMENTAS.update({
    "schedule_task": agendar_rotina,
    "list_scheduled_tasks": listar_rotinas_ferramenta,
    "cancel_scheduled_task": cancelar_rotina_ferramenta,
    "remember": lembrar_ferramenta,
    "forget": esquecer_ferramenta,
})
_APELIDOS_FERRAMENTAS.update({
    "schedule": "schedule_task", "create_reminder": "schedule_task", "set_reminder": "schedule_task",
    "set_alarm": "schedule_task", "create_routine": "schedule_task", "add_routine": "schedule_task",
    "list_reminders": "list_scheduled_tasks", "list_routines": "list_scheduled_tasks",
    "cancel_reminder": "cancel_scheduled_task", "delete_routine": "cancel_scheduled_task",
    "save_memory": "remember", "memorize": "remember", "save_preference": "remember", "remember_fact": "remember",
    "forget_memory": "forget", "delete_memory": "forget",
})
_APELIDOS_ARGUMENTOS.update({
    "request": ("task", "command", "prompt", "action", "what", "text"),
    "in_minutes": ("minutes", "delay", "delay_minutes", "after_minutes"),
    "fact": ("memory", "text", "content", "preference", "info", "information"),
    "id": ("task_id", "name", "which", "request"),
})


# Rotina rodando agora: ela não pode se agendar de novo ("mostra um
# lembrete..." fala de lembrete, mas é a própria rotina acontecendo).
ROTINA_EM_ANDAMENTO = {"ativa": False}


def processar_rotina(pedido):
    """Roda o pedido de uma rotina (sem ferramentas de agenda)."""
    ROTINA_EM_ANDAMENTO["ativa"] = True
    try:
        return processar_mensagem(pedido)
    finally:
        ROTINA_EM_ANDAMENTO["ativa"] = False


def ferramentas_do_pedido(tarefa, texto):
    """As ferramentas da tarefa + as de memória/agenda, se o pedido fala
    disso (sem pesar a lista das tarefas que nada têm a ver)."""
    base = ferramentas_para(tarefa)
    nomes = {f["function"]["name"] for f in base}
    extras = set()
    if rotinas_lib.fala_de_memoria(texto):
        extras |= _FERRAMENTAS_MEMORIA
    if rotinas_lib.fala_de_agenda(texto) and not ROTINA_EM_ANDAMENTO["ativa"]:
        extras |= _FERRAMENTAS_AGENDA
    faltam = [f for f in TOOLS_ROTINAS if f["function"]["name"] in extras - nomes]
    return base + faltam


def notificar(texto):
    """Notificação do sistema (notify-send), se houver: a rotina aparece
    mesmo com a janela escondida."""
    if not shutil.which("notify-send"):
        return False
    try:
        subprocess.Popen(["notify-send", "-a", "openTARS", "-i", "opentars", "openTARS", texto],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def iniciar_agendador(ao_vencer):
    """Liga a thread que roda as rotinas na hora (janela ou terminal)."""
    agendador = rotinas_lib.Agendador(rotinas, ao_vencer)
    agendador.iniciar()
    return agendador
