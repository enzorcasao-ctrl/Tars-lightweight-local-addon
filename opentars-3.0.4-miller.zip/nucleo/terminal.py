# openTARS — nucleo/terminal.py
# Linha de comando: diagnóstico, voz (--voz) e as opções (--explicar, --servidor...).
#
# Parte do núcleo: o tars.py executa este arquivo DENTRO do próprio
# namespace (ver _carregar_nucleo), então tudo aqui é tars.<nome> e as
# partes enxergam umas às outras sem import. Os testes que trocam
# tars.<função> por uma falsa continuam valendo pra todas as partes.
# flake8: noqa

# ============================================================
# LINHA DE COMANDO
# ============================================================
#
# 3.0 Miller: a conversa fica na janela (opentars-gui) e na voz
# (opentars --voz). O "opentars" sozinho confere o ambiente, e os
# argumentos (--explicar, --servidor, --atalho...) continuam aqui.

def _valor_do_argumento(argumentos, nomes):
    """--idioma en / --idioma=en -> "en" ('' se o argumento vier sem valor)."""
    for i, arg in enumerate(argumentos):
        for nome in nomes:
            if arg == nome:
                return argumentos[i + 1] if i + 1 < len(argumentos) and not argumentos[i + 1].startswith("--") else ""
            if arg.startswith(nome + "="):
                return arg.split("=", 1)[1]
    return None


def _rotina_no_terminal(rotina):
    """Na hora de uma rotina (no modo --voz): roda o pedido como se a
    pessoa tivesse falado (esperando o pedido em andamento terminar)."""
    with TRAVA_PEDIDO:
        print(c(f"\n[openTARS] {t('rotina.rodando', pedido=rotina['pedido'])}", Cor.CIANO))
        notificar(t("rotina.rodando", pedido=rotina["pedido"]))
        resposta = processar_rotina(rotina["pedido"])
        falar_resposta(resposta)
        print()


def main():

    argumentos = sys.argv[1:]

    if any(a in ("--version", "-v", "--versao") for a in argumentos):
        print(f"openTARS {VERSAO} ({VERSAO_EXIBIDA})")
        return

    if any(a in ("--help", "-h", "--ajuda") for a in argumentos):
        print(t("term.ajuda", versao=VERSAO_EXIBIDA))
        return

    idioma = _valor_do_argumento(argumentos, ("--idioma", "--language", "--lang"))
    if idioma is not None:
        if idioma:
            codigo = i18n.definir_idioma(idioma)
            if not codigo:
                print(t("idioma.nao_encontrado", pedido=idioma, lista=", ".join(i18n.idiomas_disponiveis())))
                sys.exit(1)
        else:
            comando_idioma("")
            return

    if "--avaliar-classificador" in argumentos:
        sys.exit(avaliar_classificador())

    for flag in ("--explicar", "--explain"):
        if flag in argumentos:
            pedido = " ".join(a for a in argumentos[argumentos.index(flag) + 1:] if not a.startswith("--"))
            sys.exit(explicar_escolha(pedido))

    if any(a in ("--diagnostico", "--diagnostic", "--autoteste", "--selftest") for a in argumentos):
        import tars_autoteste
        completo = any(a in ("--autoteste", "--selftest") for a in argumentos)
        sys.exit(tars_autoteste.executar(sys.modules[__name__], completo=completo))

    servidor = _valor_do_argumento(argumentos, ("--servidor", "--server"))
    if servidor is not None:
        if servidor.lower() in ("off", "nenhum", "none", "desligar"):
            i18n.salvar_config(servidor_api="")
            print(t("servidor.removido"))
            return
        if servidor:
            i18n.salvar_config(servidor_api=api.normalizar_url(servidor))
        url = servidor_api()
        if not url:
            print(t("servidor.nenhum"))
            return
        modelos = sorted(listar_modelos_api(forcar=True))
        if modelos:
            print(t("servidor.ok", url=url, n=len(modelos), modelos=", ".join(modelos)))
        else:
            print(t("servidor.sem_resposta", url=url))
        return

    if any(a in ("--instalar-voz", "--install-voice") for a in argumentos):
        ok, erro = instalar_voz()
        print(c(t("voz.instalada") if ok else t("voz.erro_instalar", erro=erro), Cor.VERDE if ok else Cor.VERMELHO))
        sys.exit(0 if ok else 1)

    if any(a in ("--voz", "--voice") for a in argumentos):
        pedidos = iniciar_conversa()
        if pedidos:
            print(c(f"[openTARS] {t('term.conversa_carregada', n=pedidos)}", Cor.CINZA))
        try:
            sys.exit(modo_voz_terminal())
        finally:
            encerrar_todas_ias()

    atalho = _valor_do_argumento(argumentos, ("--atalho", "--shortcut"))
    if atalho is not None:
        import tars_atalho
        sys.exit(tars_atalho.comando(atalho))

    # Sem argumento: confere o ambiente e diz onde fica a conversa.
    import tars_autoteste
    codigo = tars_autoteste.executar(sys.modules[__name__], completo=False)
    print()
    print(c(t("term.onde_conversar"), Cor.NEGRITO + Cor.VERDE))
    sys.exit(codigo)
