# openTARS — nucleo/voz.py
# Voz (3.0): falar as respostas, ouvir "TARS", instalar o que falta.
# A parte pesada (microfone, Whisper, Piper) fica em tars_voz.py.
#
# Parte do núcleo: o tars.py executa este arquivo DENTRO do próprio
# namespace (ver _carregar_nucleo), então tudo aqui é tars.<nome> e as
# partes enxergam umas às outras sem import. Os testes que trocam
# tars.<função> por uma falsa continuam valendo pra todas as partes.
# flake8: noqa

# ============================================================
# VOZ
# ============================================================

_falador_voz = {"f": None}


def config_voz():
    """{'falar': bool, 'ativacao': bool} salvos no config.json."""
    dados = i18n.ler_config()
    return {"falar": bool(dados.get("voz_falar")), "ativacao": bool(dados.get("voz_ativacao"))}


def salvar_config_voz(**mudancas):
    i18n.salvar_config(**{f"voz_{k}": bool(v) for k, v in mudancas.items()})


def o_que_falta_voz():
    return voz_lib.o_que_falta(i18n.idioma_atual())


def descrever_falta_voz(falta):
    """['piper-tts', 'gravador'] -> texto no idioma da pessoa."""
    return ", ".join(t(f"voz.falta_{item.replace('-', '_')}") for item in falta)


def falador():
    if _falador_voz["f"] is None:
        _falador_voz["f"] = voz_lib.Falador()
    return _falador_voz["f"]


def falar_resposta(texto, forcar=False, ao_terminar=None):
    """Lê a resposta em voz alta se a pessoa ligou "responder falando".
    ao_terminar: chamado quando a fala acaba (pra ouvir a continuação)."""
    if not texto or texto == RESPOSTA_INTERROMPIDA:
        return False
    if not (forcar or config_voz()["falar"]) or o_que_falta_voz():
        return False
    return falador().falar(texto, i18n.idioma_atual(), ao_terminar=ao_terminar)


def instalar_voz(avisar=None):
    avisar = avisar or (lambda msg: print(c(f"[openTARS] {msg}", Cor.CINZA)))
    faltava = o_que_falta_voz()
    duras = [x for x in faltava if x in ("gravador", "tocador")]
    if duras:
        return False, t("voz.precisa_sistema", itens=descrever_falta_voz(duras))
    ok, erro = voz_lib.instalar(i18n.idioma_atual(), avisar)
    return ok, ("" if ok else erro)


def modo_voz_terminal():
    """opentars --voz: fica ouvindo "TARS" e responde falando."""
    falta = o_que_falta_voz()
    if falta:
        print(c(t("voz.falta", itens=descrever_falta_voz(falta)), Cor.AMARELO))
        return 1
    pedidos = []
    trava = threading.Event()

    def ao_pedido(texto):
        pedidos.append(texto)
        trava.set()

    def ao_estado(estado):
        if estado == "chamado":
            print(c(f"[openTARS] {t('voz.chamado')}", Cor.CIANO))
        elif estado == "conversa":
            print(c(f"[openTARS] {t('gui.voz_conversa')}", Cor.CINZA))
        elif estado == "carregando":
            print(c(f"[openTARS] {t('gui.voz_carregando')}", Cor.CINZA))
        elif estado.startswith("erro:"):
            print(c(f"[openTARS] {t('voz.erro_microfone', erro=estado[5:])}", Cor.VERMELHO))
            trava.set()

    ouvinte = voz_lib.Ouvinte(ao_pedido, i18n.idioma_atual, modo="ativacao", ao_estado=ao_estado,
                              falador=falador())
    ouvinte.iniciar()
    agendador = iniciar_agendador(_rotina_no_terminal)
    print(c(t("voz.ouvindo"), Cor.CIANO))
    try:
        while ouvinte.ativo:
            if not trava.wait(0.5):
                continue
            trava.clear()
            while pedidos:
                texto = pedidos.pop(0)
                print(c(t("term.voce"), Cor.NEGRITO + Cor.VERDE) + f" ({t('voz.por_voz')}) {texto}")
                with TRAVA_PEDIDO:
                    resposta = processar_mensagem(texto)
                if not falar_resposta(resposta, forcar=True, ao_terminar=ouvinte.abrir_conversa):
                    ouvinte.abrir_conversa()
    except KeyboardInterrupt:
        print()
    finally:
        agendador.parar()
        ouvinte.parar()
        falador().parar()
    return 0
