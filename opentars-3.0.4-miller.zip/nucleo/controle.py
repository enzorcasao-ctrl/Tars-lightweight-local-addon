# openTARS — nucleo/controle.py
# Terminal, informações do PC, mouse (mira, arrasto, conferência) e teclado.
#
# Parte do núcleo: o tars.py executa este arquivo DENTRO do próprio
# namespace (ver _carregar_nucleo), então tudo aqui é tars.<nome> e as
# partes enxergam umas às outras sem import. Os testes que trocam
# tars.<função> por uma falsa continuam valendo pra todas as partes.
# flake8: noqa

# ============================================================
# OUTRAS FERRAMENTAS
# ============================================================

def listar_arquivos(caminho="."):
    try:

        pasta = Path(caminho).expanduser()

        if not pasta.exists():
            return {
                "sucesso": False,
                "mensagem": f"The path '{caminho}' does not exist.",
            }

        arquivos = [
            f"[{'DIR' if item.is_dir() else 'FILE'}] {item.name}"
            for item in sorted(pasta.iterdir(), key=lambda x: x.name.lower())
        ]

        return {
            "sucesso": True,
            "caminho": str(pasta.resolve()),
            "arquivos": arquivos[:LIMITE_ARQUIVOS_LISTADOS],
            "mensagem": f"{len(arquivos)} items found.",
        }

    except Exception as e:

        return {
            "sucesso": False,
            "mensagem": str(e),
        }


# Padrões de comando destrutivo o suficiente pra merecer uma
# confirmação antes de rodar — a IA (inclusive um modelo pequeno, que
# erra mais) manda qualquer comando pro terminal sem nenhuma trava
# hoje, e um comando mal interpretado nessa lista pode apagar dados ou
# derrubar o sistema sem chance de desfazer. Não é uma lista exaustiva
# de tudo que pode dar errado — é uma rede de segurança pros casos mais
# óbvios e mais caros.
_PADROES_COMANDO_PERIGOSO = [
    r"\brm\b.*\s-[a-zA-Z]*[rR]",  # rm -r/-rf/-fr/-R: apaga pastas inteiras
    r"\brm\b.*--recursive",
    r"\bfind\b.*\s-delete\b",
    r"\bshred\b",
    r"\bgit\b.*\b(reset\s+--hard|clean\s+-[a-z]*f)",
    r"\bdd\b.*\bif=",
    r"\bmkfs\b",
    r"\bwipefs\b",
    r"\bfdisk\b",
    r"\bparted\b",
    r">\s*/dev/(sd|nvme|hd)",
    r"\bshutdown\b",
    r"\breboot\b",
    r"\bpoweroff\b",
    r"\bhalt\b",
    r"\bchmod\b.*-R.*\s/(\s|$)",
    r"\bchown\b.*-R.*\s/(\s|$)",
    r":\(\)\s*\{\s*:\s*\|\s*:\s*&?\s*\}\s*;\s*:",  # fork bomb
    r"\bmv\b.*\s/(\s|$).*>\s*/dev/null",
]

_CONFIRMAR_COMANDOS_PERIGOSOS = (
    os.environ.get("TARS_SEM_CONFIRMACAO_PERIGOSOS", "0") != "1"
)

# Função (comando) -> bool que a interface gráfica registra pra
# perguntar numa janela. None = pergunta no terminal com input().
confirmar_comando_hook = None


def _comando_e_perigoso(comando):
    return any(
        re.search(padrao, comando, re.IGNORECASE)
        for padrao in _PADROES_COMANDO_PERIGOSO
    )


def _confirmar_comando_perigoso(comando):
    """Pede confirmação explícita no terminal antes de rodar um
    comando que bateu com um padrão destrutivo conhecido. Pode ser
    desligado (por conta e risco do usuário) com a variável de
    ambiente TARS_SEM_CONFIRMACAO_PERIGOSOS=1, útil pra rodar o TARS
    de forma não-interativa."""

    if not _CONFIRMAR_COMANDOS_PERIGOSOS:
        return True

    imprimir_caixa(
        "⚠ " + t("perigo.titulo"),
        [comando[:200], t("perigo.explicacao")],
        cor_titulo=Cor.VERMELHO,
    )

    if confirmar_comando_hook is not None:
        # Interface gráfica: não há terminal pra digitar "s", então ela
        # registra aqui uma função que pergunta numa caixa de diálogo.
        try:
            confirmado = bool(confirmar_comando_hook(comando))
        except Exception:
            confirmado = False
    elif threading.current_thread() is not threading.main_thread():
        # Rotina rodando sozinha no terminal: o input() brigaria com o do
        # prompt (o "s" viraria um pedido novo). Sem ninguém pra confirmar: não roda.
        print(c(t("perigo.sem_confirmacao_rotina"), Cor.AMARELO))
        confirmado = False
    else:
        try:
            resposta = input(c(t("perigo.pergunta") + " ", Cor.AMARELO)).strip()
        except (EOFError, OSError):
            resposta = ""
        confirmado = normalizar(resposta) in _vocab()["respostas_sim"]

    LOG.info(
        "comando_perigoso confirmado=%s comando=%s",
        confirmado,
        _resumir_para_log(comando),
    )

    return confirmado


def executar_terminal(comando):

    if _comando_e_perigoso(comando) and not _confirmar_comando_perigoso(comando):
        return {
            "sucesso": False,
            "mensagem": (
                "Command cancelled: it matched a potentially destructive pattern "
                "and the user did not confirm it."
            ),
        }

    # "firefox &" ou "nohup x &": o programa fica rodando e segurava a
    # saída aberta, e o openTARS esperava o tempo limite inteiro à toa.
    if re.search(r"&\s*$", comando.strip()) and not comando.strip().endswith("&&"):
        try:
            subprocess.Popen(
                comando, shell=True, stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            return {"sucesso": True, "mensagem": "Command started in the background."}
        except Exception as e:
            return {"sucesso": False, "mensagem": str(e)}

    try:

        processo = subprocess.Popen(
            comando,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            # Sem terminal pra digitar: sudo/apt que pedem senha ou "S/n"
            # falham na hora em vez de travar até o tempo limite.
            stdin=subprocess.DEVNULL,
            start_new_session=True,
            env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
        )
        limite = time.time() + TIMEOUT_TERMINAL_COMANDO
        while True:
            try:
                saida, erro_saida = processo.communicate(timeout=0.25)
                break
            except subprocess.TimeoutExpired:
                if _cancelar.is_set() or time.time() > limite:
                    try:
                        os.killpg(processo.pid, 15)
                    except Exception:
                        processo.kill()
                    processo.communicate()
                    if _cancelar.is_set():
                        return {"sucesso": False, "mensagem": "Command interrupted by the user."}
                    raise subprocess.TimeoutExpired(comando, TIMEOUT_TERMINAL_COMANDO)

        resultado = subprocess.CompletedProcess(comando, processo.returncode, saida, erro_saida)

        return {
            "sucesso": resultado.returncode == 0,
            "codigo": resultado.returncode,
            "stdout": resultado.stdout[-LIMITE_STDOUT_CHARS:],
            "stderr": resultado.stderr[-LIMITE_STDERR_CHARS:],
            "mensagem": (
                "Command finished."
                if resultado.returncode == 0
                else "Command finished with an error."
            ),
        }

    except subprocess.TimeoutExpired:

        return {
            "sucesso": False,
            "mensagem": (
                f"The command ran for more than {TIMEOUT_TERMINAL_COMANDO}s and was stopped. "
                "If it needs to run for a long time, suggest that the user runs it in a terminal."
            ),
        }

    except Exception as e:

        return {
            "sucesso": False,
            "mensagem": str(e),
        }


def informacoes_pc():
    memoria = psutil.virtual_memory()
    disco = psutil.disk_usage("/")

    return {
        "sucesso": True,
        "cpu": psutil.cpu_percent(interval=INTERVALO_CPU_PERCENT_SEG),
        "ram_percentual": memoria.percent,
        "ram_total_gb": round(memoria.total / 1024**3, 2),
        "ram_disponivel_gb": round(memoria.available / 1024**3, 2),
        "disco_percentual": disco.percent,
        "disco_livre_gb": round(disco.free / 1024**3, 2),
        "mensagem": "Computer information collected.",
    }


# O print enviado à IA é reduzido (ex: 2560x1440 -> 1280x720) e ela
# responde com coordenadas DESSA imagem. Sem converter de volta, o
# clique cairia no lugar errado (metade do caminho, numa tela 2x maior).
# Atualizado a cada take_screenshot; 1.0 enquanto não houver print.
# Com print de uma janela só, ox/oy guardam onde ela começa na tela.
_escala_print = {"x": 1.0, "y": 1.0, "ox": 0, "oy": 0, "largura": None, "altura": None, "definido": False}


def _escala_tela_inteira():
    """Quanto o print da tela inteira é reduzido (ex: 2.0 numa tela de
    2560px com prints de 1280px). Não depende de já ter tirado print."""
    try:
        largura = pyautogui.size()[0]
    except Exception:
        return 1.0
    return largura / min(largura, LARGURA_MAXIMA_SCREENSHOT) if largura else 1.0


def _usar_quadro_tela_inteira():
    """Volta as coordenadas de clique pro sistema do print de tela
    inteira. Chamado sempre que o openTARS informa posições nesse
    sistema (janelas abertas, tamanho da tela) ou quando a tela muda
    (abrir/focar janela): um recorte de janela antigo deixaria o clique
    com deslocamento errado."""
    escala = _escala_tela_inteira()
    _escala_print.update(x=escala, y=escala, ox=0, oy=0, largura=None, altura=None, definido=True)


def _para_tela(x, y):
    """Coordenadas do último print (as que a IA vê) -> pixels reais.
    Sem print nenhum ainda, vale o sistema do print de tela inteira (o
    tamanho de tela que o prompt informa à IA)."""
    if not _escala_print["definido"]:
        _usar_quadro_tela_inteira()
    return (
        int(round(_escala_print["ox"] + float(x) * _escala_print["x"])),
        int(round(_escala_print["oy"] + float(y) * _escala_print["y"])),
    )


def _para_print(x, y):
    """Pixels reais da tela -> coordenadas do último print."""
    if not _escala_print["definido"]:
        _usar_quadro_tela_inteira()
    return (
        int(round((x - _escala_print["ox"]) / _escala_print["x"])),
        int(round((y - _escala_print["oy"]) / _escala_print["y"])),
    )


# ------------------------------------------------------------
# 2.9.2: mouse preciso (mirar, conferir, arrastar) — lógica em tars_mouse.py
# ------------------------------------------------------------
PAUSA_HOVER_SEG = 0.12          # o app desenha o "hover" antes da captura de antes
ESPERA_DEPOIS_CLIQUE_SEG = 0.45
RAIO_VERIFICAR_CLIQUE = 140     # px reais em volta do clique
DURACAO_PASSO_ARRASTO_SEG = 0.018
PAUSA_SEGURAR_SEG = 0.18        # botão apertado antes de sair do lugar
PAUSA_SOLTAR_SEG = 0.3          # no destino, antes de soltar (o app mostra onde vai cair)


def _capturar_regiao(bbox=None):
    """Captura rápida pra comparar antes/depois (bbox em px reais), ou
    None se não der (Wayland, sem tela). Só serve pra conferir."""
    if SESSAO_GRAFICA == "wayland":
        return None
    try:
        from PIL import ImageGrab
        return ImageGrab.grab(bbox=bbox) if bbox else ImageGrab.grab()
    except Exception:
        return None


def _tamanho_real():
    try:
        largura, altura = pyautogui.size()
        return int(largura), int(altura)
    except Exception:
        return None


def _conferir(acao, x, y):
    """Faz a ação (clique, arrasto) e diz o que mudou na tela: "perto" do
    ponto, "longe" dele, "nada", ou None se não deu pra conferir."""
    tamanho = _tamanho_real()
    bbox = mouse.recorte_em_volta(int(x), int(y), RAIO_VERIFICAR_CLIQUE, *tamanho) if tamanho else None
    antes_perto = _capturar_regiao(bbox) if bbox else None
    antes_tudo = _capturar_regiao() if antes_perto is not None else None
    acao()
    if antes_perto is None:
        return None
    time.sleep(ESPERA_DEPOIS_CLIQUE_SEG)
    perto = mouse.mudanca(antes_perto, _capturar_regiao(bbox))
    if mouse.mudou(perto):
        return "perto"
    if mouse.mudou(mouse.mudanca(antes_tudo, _capturar_regiao())):
        return "longe"
    return "nada" if perto is not None else None


def _perguntar_visao(visao):
    """perguntar(img, prompt, opcoes) da grade, ligado ao modelo 'visao'."""
    def perguntar(img, prompt, opcoes):
        buffer = io.BytesIO()
        img.save(buffer, format="PNG", compress_level=1)
        bruto = _chat_unico(
            visao, prompt, temperatura=0.0, timeout=TIMEOUT_VISAO_GRADE, keep_alive=KEEP_ALIVE,
            formato={"type": "object", "properties": {"celula": {"type": "string", "enum": opcoes}},
                     "required": ["celula"]},
            imagens=[base64.b64encode(buffer.getvalue()).decode("ascii")],
        )
        dados = _json_da_resposta(bruto)
        if isinstance(dados, dict):
            return str(dados.get("celula", "")).strip().upper().replace("NONE", "none")
        achado = re.search(r"\b([A-H][1-8])\b", bruto or "")
        return achado.group(1) if achado else None
    return perguntar


def _ponto_por_acessibilidade(nome, janela):
    """Centro do elemento na tela pela árvore de acessibilidade (sem
    clicar), ou None. Só no X11 e com coordenadas de tela confiáveis."""
    if SESSAO_GRAFICA != "x11" or acess.indisponivel():
        return None
    try:
        alvo, erro = _janela_acessivel(janela)
        if erro or not alvo or not acess.coordenadas_confiaveis(alvo):
            return None
        achado = acess.localizar(alvo, nome)
    except Exception:
        return None
    if not achado:
        return None
    rotulo, (x, y, largura, altura) = achado
    tamanho = _tamanho_real()
    cx, cy = x + largura // 2, y + altura // 2
    if tamanho and not (0 <= cx < tamanho[0] and 0 <= cy < tamanho[1]):
        return None
    return cx, cy, f"found {rotulo} through accessibility"


def _mirar(x=None, y=None, alvo=None, janela=None):
    """Onde clicar, em px REAIS da tela: (tx, ty, como) ou (None, None, erro).

    - só x/y: o ponto do último print, convertido;
    - x/y + alvo: dá zoom em volta do ponto e acha o alvo exato (visão em
      grade); se ele não estiver ali, procura na janela/tela toda;
    - só alvo: acessibilidade, texto na tela (OCR), e por fim a visão."""
    alvo = (alvo or "").strip()
    tem_ponto = x is not None and y is not None
    if tem_ponto and not alvo:
        tx, ty = _para_tela(x, y)
        return tx, ty, ""
    if not tem_ponto and not alvo:
        return None, None, "ERROR: pass x/y (pixels of the last screenshot) or 'target' (what to click)."

    if not tem_ponto:
        achado = _ponto_por_acessibilidade(alvo, janela)
        if achado:
            return achado
        if janela and not _ocr_pronto():
            lido = _ler_janela(janela)
            if lido:
                palavras, ox, oy, _janela_x, _img = lido
                texto = ocr.achar(palavras, alvo)
                if texto:
                    return ox + texto["x"], oy + texto["y"], f"found the text '{texto['texto']}' on screen"

    try:
        if janela:
            capturada = _capturar_janela(janela)
            if not capturada:
                return None, None, f"No open window looks like '{janela}'. Use list_windows."
            imagem, ox, oy, janela_x = capturada
            titulo = janela_x["titulo"]
        else:
            imagem, ox, oy, titulo = _capturar_tela().convert("RGB"), 0, 0, "the whole screen"
    except Exception as e:
        if tem_ponto:
            tx, ty = _para_tela(x, y)
            return tx, ty, ""
        return None, None, f"ERROR capturing the screen: {e}"

    visao = _modelo_de_visao() if CLIQUE_POR_VISAO else None
    if tem_ponto:
        tx, ty = _para_tela(x, y)
        lx, ly = tx - ox, ty - oy
        if not visao:
            nx, ny = mouse.encaixar(imagem, lx, ly)
            como = "moved onto the nearest element" if (nx, ny) != (lx, ly) else ""
            return ox + nx, oy + ny, como
        print(c(f"[openTARS] {t('msg.mirando', alvo=alvo, modelo=visao)}", Cor.CINZA))
        try:
            ponto = mouse.refinar(imagem, lx, ly, alvo, _perguntar_visao(visao))
        except Exception:
            ponto = None
        if ponto:
            distancia = round(((ponto[0] - lx) ** 2 + (ponto[1] - ly) ** 2) ** 0.5)
            return ox + ponto[0], oy + ponto[1], (
                f"{visao} zoomed in and aimed at '{alvo}'"
                + (f" ({distancia} px from the x/y you gave)" if distancia >= 3 else ""))
    if not visao:
        return None, None, (
            f"Could not find '{alvo}': it is not written on screen and no vision model is installed. "
            "Pass x/y from a screenshot.")
    print(c(f"[openTARS] {t('msg.procurando_com_visao', alvo=alvo, modelo=visao)}", Cor.CINZA))
    try:
        ponto = ocr.localizar_por_grade(
            imagem, alvo, _perguntar_visao(visao), titulo, celula_final_max=CELULA_FINAL_VISAO,
            descricao=None if janela else "a screenshot of the whole screen")
    except Exception:
        ponto = None
    if not ponto:
        return None, None, f"The vision model {visao} could not find '{alvo}' in {titulo}."
    return ox + ponto[0], oy + ponto[1], f"{visao} located '{alvo}' by looking at the screen"


def _frase_conferencia(resultado):
    if resultado == "perto":
        return " The screen changed where it clicked."
    if resultado == "longe":
        return " The screen changed (not right at the click point)."
    if resultado == "nada":
        return (" WARNING: nothing changed on screen after the click, so it probably MISSED. Don't say "
                "it worked: call it again with target='<what you want to click>' (openTARS zooms in and "
                "aims), or use click_element.")
    return ""


def clicar_mouse(botao="left", x=None, y=None, alvo=None, janela=None, duplo=False):
    """Handler de click_mouse (e double_click): mira (tars_mouse), clica
    e confere se a tela mudou."""
    botao = botao if botao in ("left", "right", "middle") else "left"
    try:
        if x is None and y is None and not (alvo or "").strip():
            if duplo:
                pyautogui.doubleClick()
            else:
                pyautogui.click(button=botao)
            return {"sucesso": True, "mensagem": ("Double click done." if duplo else
                                                  f"Clicked the {botao} mouse button.")}
        tx, ty, como = _mirar(x, y, alvo, janela)
        if tx is None:
            return {"sucesso": False, "mensagem": como}
        pyautogui.moveTo(tx, ty, duration=DURACAO_MOVER_MOUSE_SEG)
        time.sleep(PAUSA_HOVER_SEG)
        if duplo:
            conferido = _conferir(lambda: pyautogui.doubleClick(x=tx, y=ty), tx, ty)
        else:
            conferido = _conferir(lambda: pyautogui.click(x=tx, y=ty, button=botao), tx, ty)
        px, py = _para_print(tx, ty)
        o_que = "Double-clicked" if duplo else f"Clicked the {botao} mouse button"
        mensagem = f"{o_que} at ({px}, {py})" + (f": {como}" if como else "") + "."
        resultado = {"sucesso": True, "mensagem": mensagem + _frase_conferencia(conferido), "x": px, "y": py}
        if conferido == "nada":
            resultado["sem_efeito"] = True
        return resultado
    except Exception as e:
        return {"sucesso": False, "mensagem": str(e)}


def duplo_clique(x=None, y=None, alvo=None, janela=None):
    return clicar_mouse("left", x, y, alvo, janela, duplo=True)


def _ponto_do_arrasto(x, y, elemento, janela, lugar=None):
    """(tx, ty, como) em px reais pra origem/destino de um arrasto."""
    if lugar:
        tamanho = _tamanho_real()
        ancorado = mouse.ancora(lugar, *tamanho) if tamanho else None
        if ancorado:
            return ancorado[0], ancorado[1], f"'{lugar}' of the screen"
        elemento = elemento or lugar  # não é um lugar da tela: é um elemento
    elemento = (elemento or "").strip()
    if elemento and (x is None or y is None):
        achado = _ponto_por_acessibilidade(elemento, janela)
        if achado:
            return achado
    return _mirar(x, y, elemento or None, janela)


def _arrastar_real(x0, y0, x1, y1, botao):
    pyautogui.moveTo(x0, y0, duration=DURACAO_MOVER_MOUSE_SEG)
    time.sleep(PAUSA_HOVER_SEG)
    pyautogui.mouseDown(x=x0, y=y0, button=botao)
    try:
        time.sleep(PAUSA_SEGURAR_SEG)
        for i, (px, py) in enumerate(mouse.caminho(x0, y0, x1, y1)):
            pyautogui.moveTo(px, py)
            # os 3 primeiros (o "empurrão") devagar: aí o app vê um arrasto
            time.sleep(DURACAO_PASSO_ARRASTO_SEG * (4 if i < 3 else 1))
        time.sleep(PAUSA_SOLTAR_SEG)
    finally:
        pyautogui.mouseUp(x=x1, y=y1, button=botao)


def _janela_do_arrasto(a):
    """Nome da janela, se o que se quer arrastar é a PRÓPRIA janela ("a
    janela do openTARS", a barra de título, ou só o nome de um app aberto,
    sem ponto de origem), senão None. Arrastar uma aba ou um arquivo DENTRO
    da janela continua sendo arrasto de mouse."""
    elemento = (a.get("from_element") or "").strip()
    janela = (a.get("window") or "").strip()
    if a.get("to_element"):
        return None  # soltar em cima de algo: arrasto de verdade
    if elemento and mouse.fala_de_janela(elemento):
        return mouse.sem_palavras_de_janela(elemento) or janela or None
    if a.get("from_x") is not None and a.get("from_y") is not None:
        return None
    if elemento and set(normalizar(elemento).split()) & mouse._PALAVRAS_ABA:
        return None
    if elemento and (not janela or normalizar(janela) == normalizar(elemento)):
        achada = encontrar_janela_por_nome(elemento)
        # o nome é de um app aberto (classe/binário), não só um texto do título
        if achada and _pontuar_janela(achada, _termos_para_janela(elemento)) >= 2:
            return elemento
    if not elemento and janela:
        return janela
    return None


def arrastar_mouse(a):
    """Handler de drag_mouse: segura o botão na origem, leva até o destino
    como uma pessoa faria e solta. Confere se a tela mudou."""
    if ERRO_PYAUTOGUI:
        return {"sucesso": False, "mensagem": f"Cannot control the mouse: {ERRO_PYAUTOGUI}."}
    janela_inteira = _janela_do_arrasto(a)
    if janela_inteira and (a.get("to") or (a.get("to_x") is not None and a.get("to_y") is not None)):
        # "arraste a janela do openTARS pro topo esquerdo": mover janela é com
        # o gerenciador de janelas (antes o mouse ia no TEXTO "openTARS").
        return mover_janela(janela_inteira, lugar=a.get("to"), x=a.get("to_x"), y=a.get("to_y"))
    janela = a.get("window") or None
    botao = a.get("button") if a.get("button") in ("left", "right", "middle") else "left"
    tem_origem = a.get("from_element") or (a.get("from_x") is not None and a.get("from_y") is not None)
    tem_destino = a.get("to") or a.get("to_element") or (a.get("to_x") is not None and a.get("to_y") is not None)
    if not tem_destino:
        return {"sucesso": False, "mensagem": (
            "ERROR: say where to drag it: to='top-left' (or 'right', 'center', 'bottom-right'...), "
            "to_element='<what to drop it on>', or to_x/to_y (pixels of the last screenshot).")}
    try:
        if tem_origem:
            x0, y0, como0 = _ponto_do_arrasto(a.get("from_x"), a.get("from_y"), a.get("from_element"), janela)
            if x0 is None:
                return {"sucesso": False, "mensagem": f"Could not find what to drag: {como0}"}
        else:
            x0, y0 = pyautogui.position()
            como0 = "from where the mouse is"
        # O destino fica fora da janela de origem muitas vezes ("pro topo
        # esquerdo da tela"): só procura DENTRO da janela se for um elemento.
        x1, y1, como1 = _ponto_do_arrasto(a.get("to_x"), a.get("to_y"), a.get("to_element"),
                                          janela, lugar=a.get("to"))
        if x1 is None:
            return {"sucesso": False, "mensagem": f"Could not find where to drop it: {como1}"}
        if abs(x1 - x0) + abs(y1 - y0) < 3:
            return {"sucesso": False, "mensagem": "ERROR: the start and the end of the drag are the same point."}
        conferido = _conferir(lambda: _arrastar_real(x0, y0, x1, y1, botao), x1, y1)
    except Exception as e:
        return {"sucesso": False, "mensagem": f"ERROR dragging: {e}"}
    p0, p1 = _para_print(x0, y0), _para_print(x1, y1)
    detalhes = "; ".join(x for x in (f"start: {como0}" if como0 else "", f"end: {como1}" if como1 else "") if x)
    mensagem = (f"Dragged with the {botao} button held from ({p0[0]}, {p0[1]}) to ({p1[0]}, {p1[1]})"
                + (f" ({detalhes})" if detalhes else "") + ".")
    if conferido == "nada":
        # Pode ser legítimo (a aba já era a primeira), por isso não é erro;
        # mas quase sempre quer dizer que não pegou o item: a IA é avisada.
        return {"sucesso": True, "sem_efeito": True, "mensagem": mensagem + (
            " WARNING: NOTHING changed on screen, so it probably did not grab the item. Unless it was "
            "already there, take a screenshot and call drag_mouse again with from_element='<what to "
            "drag>' (openTARS finds it) or corrected from_x/from_y. Don't say it worked without checking.")}
    return {"sucesso": True, "mensagem": "SUCCESS: " + mensagem + (
        " The screen changed." if conferido in ("perto", "longe") else "")}


def scroll_mouse(valor, x=None, y=None):
    try:
        if x is not None and y is not None:
            pyautogui.moveTo(*_para_tela(x, y), duration=DURACAO_MOVER_PARA_SCROLL_SEG)

        pyautogui.scroll(int(valor))
        return {"sucesso": True, "mensagem": f"Scrolled {valor}."}
    except Exception as e:
        return {"sucesso": False, "mensagem": str(e)}


def _definir_clipboard(texto):
    """Coloca texto na área de transferência via xclip/xsel (o que
    estiver disponível). Usado pra digitar texto multilíngue — o
    pyautogui simula teclas físicas e não digita de forma confiável
    acentos, cedilha ou alfabetos fora do layout US (japonês, árabe,
    cirílico etc.); colar via clipboard funciona pra qualquer idioma
    independente do layout de teclado."""

    comandos = [
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"],
    ]
    if SESSAO_GRAFICA == "wayland":
        # wl-copy fala direto com o compositor Wayland; xclip/xsel só
        # alcançam a área de transferência do XWayland.
        comandos.insert(0, ["wl-copy"])

    for comando in comandos:
        if shutil.which(comando[0]):
            try:
                subprocess.run(
                    comando,
                    input=texto.encode("utf-8"),
                    timeout=TIMEOUT_CLIPBOARD,
                    check=True,
                )
                return True
            except Exception:
                continue

    return False


def digitar_texto(texto):
    try:
        if texto.isascii():
            # Caminho rápido de sempre — nenhuma mudança de
            # comportamento ou desempenho pro caso comum (ASCII).
            pyautogui.write(texto, interval=INTERVALO_DIGITACAO_SEG)
            return {"sucesso": True, "mensagem": "Text typed."}

        # Texto com acentos/outros idiomas: cola via clipboard em vez
        # de tecla-a-tecla, o que também é mais rápido pra textos
        # longos além de mais confiável.
        if _definir_clipboard(texto):
            pyautogui.hotkey("ctrl", "v")
            return {"sucesso": True, "mensagem": "Text typed (pasted through the clipboard)."}

        # Sem xclip/xsel disponível: melhor esforço mesmo assim.
        pyautogui.write(texto, interval=INTERVALO_DIGITACAO_SEG)
        return {
            "sucesso": True,
            "mensagem": (
                "Text typed, but xclip/xsel is not installed: special characters "
                "may not have come out right."
            ),
        }

    except Exception as e:
        return {"sucesso": False, "mensagem": str(e)}


def pressionar_tecla(tecla):
    try:
        pyautogui.press(tecla)
        return {"sucesso": True, "mensagem": f"Pressed '{tecla}'."}
    except Exception as e:
        return {"sucesso": False, "mensagem": str(e)}


def atalho_teclado(teclas):
    try:

        if isinstance(teclas, str):
            teclas = [x.strip() for x in teclas.split("+")]

        pyautogui.hotkey(*teclas)

        return {
            "sucesso": True,
            "mensagem": f"Pressed {'+'.join(teclas)}.",
        }

    except Exception as e:
        return {"sucesso": False, "mensagem": str(e)}


def esperar(segundos):
    """Pausa por um tempo curto — pra quando a própria IA decide que
    precisa dar um tempo entre dois passos de uma tarefa composta (ex:
    abrir um navegador e só então digitar na barra de endereço, já que
    abrir uma janela pesada pode levar mais que o instante que
    open_application já espera sozinho). Limitado a LIMITE_ESPERA_SEG
    pra IA não travar o TARS 'esperando' por muito tempo."""

    try:
        segundos = max(0.0, min(float(segundos), LIMITE_ESPERA_SEG))
    except (TypeError, ValueError):
        segundos = 1.0

    time.sleep(segundos)

    return {
        "sucesso": True,
        "mensagem": f"SUCCESS: waited {segundos:.1f}s.",
    }
