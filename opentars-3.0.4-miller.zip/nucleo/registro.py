# openTARS — nucleo/registro.py
# Log de auditoria, estado global, utilidades de texto e a saída pro usuário (terminal ou janela).
#
# Parte do núcleo: o tars.py executa este arquivo DENTRO do próprio
# namespace (ver _carregar_nucleo), então tudo aqui é tars.<nome> e as
# partes enxergam umas às outras sem import. Os testes que trocam
# tars.<função> por uma falsa continuam valendo pra todas as partes.
# flake8: noqa

# ============================================================
# LOG DE AUDITORIA
# ============================================================

# Toda ferramenta executada (abrir app, rodar comando, fechar
# processo etc.) fica registrada aqui — nome, argumentos e resultado,
# com timestamp. É o que permite, depois de qualquer coisa inesperada
# acontecer, entender o que foi executado e por quê, em vez de
# depender só da memória de quem estava olhando o terminal na hora.
DIRETORIO_LOG = Path(os.environ.get("TARS_DIR_LOG", str(Path.home() / ".tars_log")))
ARQUIVO_LOG = DIRETORIO_LOG / "tars.log"
TAMANHO_MAX_LOG_BYTES = 2 * 1024 * 1024
BACKUPS_LOG = 3
LIMITE_LOG_CAMPO_CHARS = 300


def _configurar_log():
    logger = logging.getLogger("tars")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    try:
        DIRETORIO_LOG.mkdir(parents=True, exist_ok=True)

        handler = RotatingFileHandler(
            ARQUIVO_LOG,
            maxBytes=TAMANHO_MAX_LOG_BYTES,
            backupCount=BACKUPS_LOG,
            encoding="utf-8",
        )
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        )
        logger.addHandler(handler)

    except Exception as e:
        # Auditoria é best-effort: se não der pra escrever o log (disco
        # cheio, permissão negada etc.), o TARS continua funcionando
        # normalmente sem ela, só avisa uma vez. Print puro aqui (sem
        # o helper de cor c()) de propósito: essa função roda antes
        # dele existir na ordem de definição do módulo.
        print(f"[openTARS] {t('msg.log_desativado', erro=e)}")
        logger.addHandler(logging.NullHandler())

    return logger


LOG = _configurar_log()


def _resumir_para_log(valor):
    """Converte um valor qualquer (geralmente os argumentos de uma
    ferramenta) numa string curta o bastante pro log — sem isso, um
    texto digitado enorme ou um resultado de comando de terminal
    grande inflaria o arquivo de log rapidamente."""

    try:
        texto = json.dumps(valor, ensure_ascii=False)
    except Exception:
        texto = str(valor)

    if len(texto) > LIMITE_LOG_CAMPO_CHARS:
        texto = texto[:LIMITE_LOG_CAMPO_CHARS] + "…"

    return texto


# ============================================================
# ESTADO
# ============================================================

modo_modelo = "AUTO"
modelo_manual = None
modelo_atual = None

sessoes = {}

lock_modelo = threading.Lock()

# Sessão HTTP única e reutilizada: evita reabrir conexão TCP/TLS
# a cada chamada ao Ollama (isso importa bastante no loop de tools,
# que pode chamar o Ollama várias vezes por turno).
_SESSION = requests.Session()

# Cache de aplicativos instalados (desktop entries e flatpak).
_cache_desktop = {"dados": None, "ts": 0.0}
_cache_flatpak = {"dados": None, "ts": 0.0}


# ============================================================
# UTILIDADES
# ============================================================

def _tabela_sem_acentos():
    """Letras latinas acentuadas -> sem acento (á->a, ñ->n, ö->o, ß->ss...),
    montada uma vez só: str.translate com ela é bem mais rápido que
    decompor Unicode a cada chamada, e normalizar() roda muito (uma vez
    por processo do sistema, por app instalado, por palavra-chave...)."""
    tabela = {}
    for codigo in range(0xC0, 0x250):
        letra = chr(codigo)
        base = "".join(x for x in unicodedata.normalize("NFKD", letra) if not unicodedata.combining(x))
        if base != letra and base.isascii() and base.isalpha():
            tabela[codigo] = base.lower()
    tabela.update({ord("ß"): "ss", ord("æ"): "ae", ord("œ"): "oe", ord("ø"): "o", ord("đ"): "d", ord("ł"): "l", ord("ı"): "i"})
    return tabela


_TABELA_NORMALIZACAO = _tabela_sem_acentos()

# Separa palavras (Unicode: funciona com qualquer alfabeto).
_RE_TOKENS = re.compile(r"[\W_]+")


def normalizar(texto):
    return texto.lower().strip().translate(_TABELA_NORMALIZACAO)


_RE_SEPARADORES_NOME = re.compile(r"[-_.:/]+")


def normalizar_nome_app(texto):
    """Pra comparar nomes de apps: "Counter-Strike 2" vira "counter strike 2",
    e bate com o "counter strike" que o usuário escreveu."""
    return re.sub(r"\s+", " ", _RE_SEPARADORES_NOME.sub(" ", normalizar(texto or ""))).strip()


# ------------------------------------------------------------
# Vocabulário dos idiomas: palavras-chave, comandos, verbos de busca...
# Montado uma vez a partir dos arquivos de idioma (já normalizado e em
# conjuntos, pra busca instantânea) e refeito só quando o idioma muda.
# ------------------------------------------------------------

_CHAVES_COMANDOS = (
    "cmd.modelos", "cmd.modelo", "cmd.encerrar", "cmd.limpar", "cmd.idioma",
    "cmd.auto", "cmd.auto_argumento", "cmd.sair",
)

_vocab_atual = None


def _preparar_expressoes(expressoes):
    """(palavras soltas, trechos de várias palavras), normalizados e já
    quebrados em palavras como o pedido é: "trouve-moi" vira o trecho
    " trouve moi " e "à l'écran", " a l ecran ". Trecho é procurado com
    espaço dos dois lados (palavras inteiras): "the screen" não bate em
    "the screenshots"."""
    palavras, trechos = set(), []
    for expr in expressoes:
        partes = [x for x in _RE_TOKENS.split(normalizar(str(expr))) if x]
        if len(partes) > 1:
            trechos.append(" " + " ".join(partes) + " ")
        elif partes:
            palavras.add(partes[0])
    return frozenset(palavras), tuple(dict.fromkeys(trechos))


def _normalizados(itens):
    return tuple(dict.fromkeys(n for n in (normalizar(str(x)) for x in itens) if n))


# Palavras das listas de abrir/fechar/buscar que não são verbos ("feche a
# ABA do youtube"): não contam como uma etapa do pedido.
_NAO_SAO_VERBOS = frozenset({"aba", "abas", "tab", "tabs", "pestana", "pestanas", "onglet", "onglets",
                             "reiter", "tabs", "site", "pagina", "page", "website"})


def _montar_vocabulario():
    entrada = i18n.idiomas_de_entrada()
    v = {
        "detectar": {
            grupo: _preparar_expressoes(list(neutras) + i18n.juntar(f"detectar.{grupo}", entrada))
            for grupo, neutras in _PALAVRAS_NEUTRAS.items()
        },
        "busca_verbos": frozenset(_normalizados(i18n.juntar("busca.verbos", entrada))),
        # Verbos de ação (pra achar pedidos com várias etapas): os da lista
        # própria + os das palavras-chave de abrir/fechar/buscar.
        "verbos_acao": frozenset(
            palavra for frase in _normalizados(
                i18n.juntar("detectar.verbos", entrada) + i18n.juntar("detectar.abrir", entrada)
                + i18n.juntar("detectar.fechar", entrada) + i18n.juntar("detectar.busca", entrada)
                + i18n.juntar("busca.verbos", entrada))
            for palavra in frase.split()[:1]
            if palavra not in _NAO_SAO_VERBOS
        ),
        "busca_conectores": _normalizados(i18n.juntar("busca.conectores", entrada)),
        "busca_preposicoes": _normalizados(i18n.juntar("busca.preposicoes", entrada)),
        "navegadores": frozenset(_MARCAS_NAVEGADORES) | frozenset(_normalizados(i18n.juntar("palavras.navegador", entrada))),
        # Comandos são explícitos: valem em qualquer idioma.
        "comandos": {chave: frozenset(_normalizados(i18n.em_todos(chave))) for chave in _CHAVES_COMANDOS},
        "respostas_sim": frozenset(_normalizados(i18n.em_todos("cmd.sim"))),
        "modelo_ignorar": frozenset(_normalizados(i18n.em_todos("modelo.ignorar"))),
    }
    superlativos = {}
    for chave, resolvedor in _CRITERIOS_MODELO.items():
        for frase in _normalizados(i18n.em_todos(chave)):
            superlativos.setdefault(frase, resolvedor)
    v["superlativos"] = superlativos

    # Nomes traduzidos de apps: Name[pt_BR]= no .desktop e catálogos gettext.
    grupos = [tuple(i18n.juntar("_locale", [codigo]) or [codigo]) for codigo in entrada]
    for local in i18n.locales_do_sistema():
        grupos.append((local, local.split("_")[0]) if "_" in local else (local,))
    grupos = tuple(dict.fromkeys(grupos))
    v["grupos_locale"] = grupos
    v["sufixos_desktop"] = tuple(dict.fromkeys([""] + [f"[{x}]" for grupo in grupos for x in grupo]))
    return v


def _vocab():
    global _vocab_atual
    v = _vocab_atual
    if v is None:
        v = _vocab_atual = _montar_vocabulario()
    return v


def _ao_mudar_idioma(_codigo):
    """Idioma novo: palavras-chave novas e nomes de apps relidos."""
    global _vocab_atual
    _vocab_atual = None
    _cache_arquivos_desktop.clear()
    _cache_desktop["dados"] = None


i18n.ao_mudar_idioma(_ao_mudar_idioma)


# ------------------------------------------------------------
# Interface: cores ANSI (funcionam no terminal do Zorin/qualquer
# terminal Linux moderno). Usadas só no que é impresso pro humano —
# nunca dentro do conteúdo de "mensagem" devolvido nas ferramentas,
# porque esse texto vai para o JSON que a IA lê.
# ------------------------------------------------------------

class Cor:
    RESET = "\033[0m"
    NEGRITO = "\033[1m"
    CINZA = "\033[90m"
    VERMELHO = "\033[31m"
    VERDE = "\033[32m"
    AMARELO = "\033[33m"
    AZUL = "\033[34m"
    MAGENTA = "\033[35m"
    CIANO = "\033[36m"


def c(texto, cor):
    return f"{cor}{texto}{Cor.RESET}"


def imprimir_caixa(titulo, linhas, cor_titulo=Cor.CIANO):
    largura = (
        max(LARGURA_MINIMA_CAIXA, len(titulo) + 4, *(len(l) + 4 for l in linhas))
        if linhas
        else max(LARGURA_MINIMA_CAIXA, len(titulo) + 4)
    )

    print()
    print(c("╭" + "─" * largura + "╮", Cor.CINZA))
    print(c("│ ", Cor.CINZA) + c(titulo.ljust(largura - 2), cor_titulo) + c(" │", Cor.CINZA))

    for linha in linhas:
        print(c("│ ", Cor.CINZA) + linha.ljust(largura - 2)[:largura - 2] + c(" │", Cor.CINZA))

    print(c("╰" + "─" * largura + "╯", Cor.CINZA))


def executar_subprocesso(cmd, timeout=TIMEOUT_SUBPROCESSO_PADRAO):
    try:
        resultado = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        return {
            "codigo": resultado.returncode,
            "stdout": resultado.stdout.strip(),
            "stderr": resultado.stderr.strip(),
        }

    except subprocess.TimeoutExpired:
        return {
            "codigo": -1,
            "stdout": "",
            "stderr": "timeout",
        }

    except Exception as e:
        return {
            "codigo": -1,
            "stdout": "",
            "stderr": str(e),
        }


# ============================================================
# SAÍDA PRO USUÁRIO (terminal ou janela)
# ============================================================
#
# O que o openTARS mostra enquanto trabalha (ferramenta rodando, modelo
# carregando, raciocínio e resposta chegando) sai como EVENTO. No
# terminal vira texto colorido; a janela registra um ouvinte e recebe o
# evento já estruturado, em vez de ler e interpretar o texto impresso
# (que muda com o idioma escolhido).

_ouvinte_saida = None


def definir_ouvinte_saida(funcao):
    """A interface gráfica registra aqui uma função(tipo, dados). None
    volta a imprimir no terminal."""
    global _ouvinte_saida
    _ouvinte_saida = funcao


def emitir(tipo, **dados):
    ouvinte = _ouvinte_saida
    if ouvinte is not None:
        try:
            ouvinte(tipo, dados)
        except Exception:
            pass
        return
    renderizar = _TERMINAL.get(tipo)
    if renderizar is not None:
        renderizar(dados)


def nome_ferramenta(nome):
    """"open_application" -> "abrindo app" (no idioma escolhido)."""
    chave = f"ferramenta.{nome}"
    texto = t(chave)
    return nome if texto == chave else texto


def nome_tarefa(tarefa):
    chave = f"tarefa.{tarefa}"
    texto = t(chave)
    return tarefa if texto == chave else texto


def _segundos(valor):
    return f"{valor:.2f}"


def _term_ferramenta(d):
    resumo = f" · {d['resumo']}" if d.get("resumo") else ""
    print(c(f"[openTARS] ▸ {nome_ferramenta(d['nome'])}{resumo}", Cor.CIANO))


def _term_ferramenta_fim(d):
    if d.get("sucesso"):
        print(c(f"[openTARS]   ✓ {_segundos(d['segundos'])}s", Cor.VERDE))
    else:
        print(c(f"[openTARS]   ✗ {t('msg.falhou')} ({_segundos(d['segundos'])}s)", Cor.VERMELHO))


def _term_tarefa(d):
    if d.get("modo") == "AUTO":
        texto = t("msg.tarefa_auto", tarefa=nome_tarefa(d["tarefa"]), modelo=d["modelo"])
        print(c(f"\n[AUTO] {texto}", Cor.AZUL))
    else:
        print(c(f"\n[MANUAL] {t('msg.tarefa_manual', modelo=d['modelo'])}", Cor.AMARELO))


def _term_carregando(d):
    if d.get("segundo_plano"):
        print(c(f"\n[IA] {t('msg.carregando_fundo', modelo=d['modelo'])}", Cor.CINZA))
    else:
        imprimir_caixa(t("msg.carregando_titulo", modelo=d["modelo"]), [t("msg.carregando_demora")])


def _term_carregado(d):
    print(c("\n✓ " + t("msg.carregado", modelo=d["modelo"], segundos=_segundos(d["segundos"])), Cor.VERDE))


def _term_descarregando(d):
    print(c(f"\n[IA] {t('msg.descarregando', modelo=d['modelo'])}", Cor.CINZA))


def _term_pensamento(d):
    if d.get("inicio"):
        print(c(f"\n[{t('msg.pensando')}] ", Cor.CINZA), end="", flush=True)
    print(c(d["texto"], Cor.CINZA), end="", flush=True)


def _term_resposta(d):
    if d.get("inicio"):
        if d.get("apos_pensamento"):
            print()
        print(c("\nopenTARS › ", Cor.NEGRITO + Cor.MAGENTA), end="", flush=True)
    print(d["texto"], end="", flush=True)


def _term_tempo(d):
    cor = Cor.AZUL if d.get("modo") == "AUTO" else Cor.AMARELO
    texto = t("msg.tempo_total", modelo=d["modelo"], segundos=_segundos(d["segundos"]))
    print(c(f"[{d.get('modo')}] {texto}", cor))


def _term_plano(d):
    print(c(f"[openTARS] {t('msg.plano')}", Cor.CIANO))
    for i, etapa in enumerate(d.get("etapas") or [], 1):
        print(c(f"  {i}. {etapa}", Cor.CINZA))


_TERMINAL = {
    "plano": _term_plano,
    "ferramenta": _term_ferramenta,
    "ferramenta_fim": _term_ferramenta_fim,
    "tarefa": _term_tarefa,
    "carregando": _term_carregando,
    "carregado": _term_carregado,
    "descarregando": _term_descarregando,
    "pensamento": _term_pensamento,
    "resposta": _term_resposta,
    "fim_stream": lambda d: print(),
    "tempo": _term_tempo,
    "analisando": lambda d: print(c(f"[IA] {t('msg.analisando', modelo=d['modelo'])}", Cor.CINZA)),
}
