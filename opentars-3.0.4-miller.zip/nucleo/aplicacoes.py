# openTARS — nucleo/aplicacoes.py
# Abrir e fechar aplicativos e sites pelo nome que o usuário usou.
#
# Parte do núcleo: o tars.py executa este arquivo DENTRO do próprio
# namespace (ver _carregar_nucleo), então tudo aqui é tars.<nome> e as
# partes enxergam umas às outras sem import. Os testes que trocam
# tars.<função> por uma falsa continuam valendo pra todas as partes.
# flake8: noqa

# ============================================================
# APLICAÇÕES
# ============================================================

# ------------------------------------------------------------
# Busca assistida por IA: em vez de manter uma lista fixa de aliases
# (app/site → nome real), pergunta pro modelo mais leve (rápido e já
# preparado pra respostas curtas) o que a entrada do usuário
# provavelmente significa. Isso generaliza pra qualquer app/site, não
# só os que alguém lembrou de cadastrar num dicionário.
# ------------------------------------------------------------

def _consultar_modelo_leve(prompt, formato=None):
    """Pergunta rápida e isolada ao modelo mais leve disponível (ver
    modelo_ajudante), sem mexer no estado de qual modelo está 'ativo'
    pra conversa principal — evita descarregar um modelo pesado só pra
    resolver um nome de app ou site no meio de uma tool call. Usa um
    timeout curto de propósito (TIMEOUT_HTTP_AJUDANTE): antes essa
    chamada herdava o timeout de 600s de uma conversa completa, o que
    travaria o pedido do usuário por até 10 minutos se o Ollama
    travasse no meio de uma resolução de nome de app/site."""

    return _chat_unico(
        modelo_ajudante(),
        prompt,
        temperatura=TEMPERATURA_AJUDANTE,
        timeout=TIMEOUT_HTTP_AJUDANTE,
        keep_alive=KEEP_ALIVE_AJUDANTE,
        formato=formato,
    )


def perguntar_candidatos_app(nome_pedido):
    """Em vez de um dicionário fixo de aliases, pergunta pro modelo
    leve quais nomes de executável/pacote Linux provavelmente
    correspondem ao app pedido. Generaliza pra qualquer aplicativo,
    inclusive os que nunca foram cadastrados manualmente."""

    prompt = (
        f"A Linux user asked to open an application called: '{nome_pedido}' "
        "(the name may be in any language).\n"
        "List 1 to 5 likely Linux executable or package names for it (real "
        "binary names, as installed via apt, flatpak or snap).\n"
        "Answer with the list of names."
    )

    conteudo = _consultar_modelo_leve(prompt, formato={
        "type": "object",
        "properties": {"nomes": {"type": "array", "items": {"type": "string"}, "maxItems": LIMITE_CANDIDATOS_APP}},
        "required": ["nomes"],
    })

    if not conteudo:
        return []

    dados = _json_da_resposta(conteudo)
    if isinstance(dados, dict) and isinstance(dados.get("nomes"), list):
        brutos = [str(n) for n in dados["nomes"]]
    else:  # Ollama antigo: texto separado por vírgula
        brutos = re.split(r"[,\n]", conteudo)

    candidatos = [
        parte.strip().strip(".").strip("'\"")
        for parte in brutos
        if parte.strip() and " " not in parte.strip()  # nome de programa não tem espaço
    ]

    return candidatos[:LIMITE_CANDIDATOS_APP]


def _dominio_existe(url):
    """Confere se o domínio de 'url' resolve de verdade via DNS — um
    modelo pequeno pode 'inventar' com muita confiança um domínio que
    simplesmente não existe (ex: pediram o canal de uma empresa no
    YouTube e ele respondeu algo como 'empresa.youtube.com', que nunca
    foi um formato real de URL do YouTube). Isso pega esse caso mais
    óbvio antes de abrir uma página que não existe; não garante que a
    página é a CERTA, só que o domínio é real."""

    host = re.sub(r"^https?://", "", url).split("/")[0].split(":")[0]

    if not host:
        return False

    # socket.setdefaulttimeout (usado antes) vale pro processo inteiro e
    # afetava as conexões com o Ollama rodando em outras threads.
    # Sem "with": ele esperaria a consulta terminar ao sair do bloco, e o
    # timeout não valeria nada com um DNS travado.
    pool = ThreadPoolExecutor(max_workers=1)
    try:
        pool.submit(socket.gethostbyname, host).result(timeout=TIMEOUT_DNS)
        return True
    except Exception:
        return False
    finally:
        pool.shutdown(wait=False)


def perguntar_url_site(nome_pedido):
    """Em vez de um dicionário fixo de sites conhecidos, pergunta pro
    modelo leve qual é a URL oficial do site/serviço pedido — mas um
    modelo pequeno não tem como saber de cor a URL exata de algo
    específico (o canal de uma empresa, uma página interna de um
    site), e nesses casos ele tende a inventar algo plausível em vez
    de admitir que não sabe. Por isso: o prompt pede explicitamente
    pra dizer 'desconhecido' quando não tiver certeza, e mesmo assim a
    URL que voltar é validada por DNS antes de ser usada — se o
    domínio nem existe, é claramente uma alucinação e a chamada
    devolve None (quem chamou cai pra uma busca no Google, que sempre
    acha a página certa)."""

    prompt = (
        f"What is the official URL of this website or service: '{nome_pedido}'?\n"
        "Answer ONLY with the full URL, starting with http:// or https://, "
        "with no other text.\n"
        "If you are not absolutely sure of the exact URL (for example, a "
        "specific page, channel or profile inside a bigger site), answer "
        "exactly: unknown. NEVER invent a URL just to give an answer."
    )

    conteudo = _consultar_modelo_leve(prompt, formato={
        "type": "object",
        "properties": {"url": {"type": "string"}},
        "required": ["url"],
    })

    dados = _json_da_resposta(conteudo)
    if isinstance(dados, dict) and isinstance(dados.get("url"), str):
        conteudo = dados["url"]

    if not conteudo or any(p in normalizar(conteudo) for p in ("unknown", "desconhecido")):
        return None

    match = re.search(r"https?://[^\s\"'<>]+", conteudo)

    if not match:
        return None

    url = match.group(0)

    return url if _dominio_existe(url) else None


GOOGLE_SEARCH_URL = "https://www.google.com/search?q="

# Serviços onde "abrir o [X] no <serviço>" (ex: "canal da anthropic no
# youtube", "perfil da nasa no instagram") deve virar uma BUSCA dentro
# do serviço, não uma tentativa de adivinhar a URL exata do perfil/
# canal/vídeo — é justamente esse tipo de pedido que um modelo pequeno
# não tem como saber de cor, e nem uma busca genérica acerta de
# primeira sem contexto. Pesquisar dentro do próprio site é o
# comportamento que um usuário esperaria de qualquer forma (parecido
# com digitar na barra de busca do site). "google" também entra aqui
# pra "pesquisar X no google" nunca precisar da IA leve — é sempre uma
# busca direta, rápida e sem chance de alucinar uma URL.
_BUSCAS_POR_SERVICO = {
    "youtube": "https://www.youtube.com/results?search_query=",
    "google": GOOGLE_SEARCH_URL,
}

# Os verbos de busca ("pesquisar", "search", "buscar"...), os conectores
# do começo da consulta ("sobre", "about"...) e as preposições antes do
# serviço ("no youtube", "on youtube") vêm dos arquivos de idioma — ver
# _vocab().


def _resolver_busca(entrada):
    """Reconhece um pedido de busca — com um serviço citado ('...no
    youtube', '...no google') ou não (aí o padrão é Google) — e monta
    a URL de busca diretamente, sem passar pela IA leve. Isso é mais
    rápido (uma chamada a menos) E mais confiável (uma busca nunca
    'erra' feito uma URL adivinhada pode). Retorna None quando a
    entrada não parece um pedido de busca — nesse caso quem chamou
    segue pro caminho normal (domínio direto ou pergunta pra IA)."""

    entrada_n = normalizar(entrada)

    # Tokeniza só por ESPAÇO aqui (não por qualquer caractere não-
    # alfanumérico como _contem_palavra_inteira faz) — isso importa
    # porque "entrada" pode ser um nome de app/executável compacto tipo
    # "google-chrome", não só uma frase natural. Com o tokenizador
    # genérico, "google-chrome" vira dois tokens ("google" e "chrome"),
    # e "google" bateria como se fosse o serviço Google sozinho —
    # gerando uma busca sem sentido tipo "https://.../search?q=-chrome"
    # (bug real já visto em produção). Palavras separadas por espaço de
    # verdade continuam batendo normalmente.
    tokens_espaco = set(entrada_n.split())
    vocab = _vocab()

    tem_verbo_busca = bool(tokens_espaco & vocab["busca_verbos"])

    servico_citado = next(
        (s for s in _BUSCAS_POR_SERVICO if s in tokens_espaco),
        None,
    )

    if not tem_verbo_busca and not servico_citado:
        return None

    url_busca = _BUSCAS_POR_SERVICO.get(servico_citado, GOOGLE_SEARCH_URL)

    resto = entrada_n

    for verbo in vocab["busca_verbos"]:
        resto = re.sub(rf"\b{re.escape(verbo)}\b", " ", resto)

    if servico_citado:
        # Remove o nome do serviço e a preposição que normalmente vem
        # junto ("no youtube", "on youtube") — sem isso a busca ficava
        # com uma preposição solta no final ("canal da anthropic no").
        preposicoes = "|".join(re.escape(x) for x in vocab["busca_preposicoes"])
        resto = re.sub(rf"\b(?:(?:{preposicoes})\s+)?{re.escape(servico_citado)}\b", " ", resto)

    resto = re.sub(r"\s+", " ", resto).strip()

    # Conectores ("sobre", "por", "de"...) só são removidos do INÍCIO
    # da consulta (ex: "sobre buracos negros" → "buracos negros") —
    # nunca no meio ou fim, senão uma consulta legítima como "receita
    # de bolo de cenoura" perderia os "de" que fazem parte dela.
    mudou = True
    while mudou:
        mudou = False
        for conector in vocab["busca_conectores"]:
            nova = re.sub(rf"^{re.escape(conector)}\b\s*", "", resto)
            if nova != resto:
                resto = nova
                mudou = True

    if not resto:
        return None

    return url_busca + quote_plus(resto)


def _pastas_de_aplicativos():
    """Todas as pastas onde o menu do desktop procura atalhos (.desktop),
    seguindo a especificação XDG, mais as de Snap e Flatpak (no Ubuntu,
    o Firefox é Snap e o atalho dele só existe em /var/lib/snapd)."""

    dados_usuario = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local/share")
    dados_sistema = os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share"

    bases = [dados_usuario] + [d for d in dados_sistema.split(":") if d]
    bases += [
        str(Path.home() / ".local/share/flatpak/exports/share"),
        "/var/lib/flatpak/exports/share",
        "/var/lib/snapd/desktop",
        "/usr/local/share",
        "/usr/share",
    ]

    pastas = []
    for base in bases:
        pasta = Path(base) / "applications"
        if pasta not in pastas:
            pastas.append(pasta)
    return pastas


# caminho do .desktop -> (mtime, entrada já lida). Sobrevive ao TTL do
# _cache_desktop: numa nova varredura, só arquivos alterados são relidos.
_cache_arquivos_desktop = {}


# O nome traduzido do app também vale: "abra a calculadora" precisa bater
# com Name[pt_BR]=Calculadora, já que o Name= padrão é em inglês
# (Calculator). Os idiomas considerados são os de entrada (o escolhido,
# os do sistema e o inglês) — ver _vocab()["locales"].

_PASTAS_LOCALE = ("/usr/share/locale-langpack", "/usr/share/locale")


@functools.lru_cache(maxsize=None)
def _catalogos_gettext(dominio, grupos):
    """Catálogos de tradução do app, um por grupo de locales
    (ex: ("pt_BR", "pt")). 'grupos' é uma tupla (entra na chave do cache)."""
    catalogos = []
    for grupo in grupos:
        for pasta in _PASTAS_LOCALE:
            try:
                catalogos.append(gettext.translation(dominio, pasta, languages=list(grupo)))
                break
            except (OSError, ValueError):
                continue
    return catalogos


def _traducoes_desktop(dominio, texto):
    vistos = []
    for catalogo in _catalogos_gettext(dominio, _vocab()["grupos_locale"]):
        try:
            t = catalogo.gettext(texto)
        except Exception:
            continue
        if t and t != texto and t not in vistos:
            vistos.append(t)
    return vistos


def _ler_desktop_entry(arquivo):
    """Lê só a seção [Desktop Entry] (as seções [Desktop Action ...]
    têm outros Exec=, como "nova janela anônima", que antes
    sobrescreviam o comando principal)."""

    try:
        texto = arquivo.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None

    campos = {}
    na_secao = False

    for linha in texto.splitlines():
        if linha.startswith("["):
            if na_secao:
                break  # acabou a [Desktop Entry]; o resto são ações
            na_secao = linha.strip() == "[Desktop Entry]"
            continue
        if not na_secao or linha.startswith("#"):
            continue
        chave, sep, valor = linha.partition("=")
        if sep:
            campos.setdefault(chave.strip(), valor.strip())

    nome = campos.get("Name")
    if not nome:
        return None
    if campos.get("Type", "Application") != "Application":
        return None
    if campos.get("Hidden", "").lower() == "true":
        return None

    outros_nomes = []
    for base in ("Name", "GenericName"):
        for sufixo in _vocab()["sufixos_desktop"]:
            valor = campos.get(base + sufixo)
            if valor and valor != nome and valor not in outros_nomes:
                outros_nomes.append(valor)

    # Ubuntu, Zorin e apps GNOME não guardam Name[pt_BR] no arquivo: a
    # tradução fica num catálogo gettext à parte (é assim que o menu
    # mostra "Calculadora"). Sem isso, "calculadora" não achava nada.
    dominio = campos.get("X-GNOME-Gettext-Domain") or campos.get("X-Ubuntu-Gettext-Domain")
    if dominio:
        for base in ("Name", "GenericName"):
            original = campos.get(base)
            if not original:
                continue
            for traducao in _traducoes_desktop(dominio, original):
                if traducao != nome and traducao not in outros_nomes:
                    outros_nomes.append(traducao)

    exec_cmd = campos.get("Exec")

    return {
        "nome": nome,
        "outros_nomes": outros_nomes,
        "arquivo": arquivo,
        "exec": exec_cmd,
        "terminal": campos.get("Terminal", "").lower() == "true",
        # Já normalizados aqui, uma vez por varredura (que fica em
        # cache), em vez de a cada busca: shlex e normalizar() eram o
        # grosso do tempo de procurar um app.
        "_nomes_n": [normalizar_nome_app(n) for n in [nome] + outros_nomes],
        "_exec_n": _exec_para_busca(exec_cmd),
    }


_RE_CODIGO_EXEC = re.compile(r"%[a-zA-Z]|[\"']")
_RE_ESPACOS = re.compile(r"\s+")


def _exec_para_busca(exec_cmd):
    """Mesmo texto que normalizar(limpar_exec(...)) produz pra comparar
    com o pedido, mas sem o shlex (que era a parte cara da varredura).
    Pra EXECUTAR o comando continua valendo limpar_exec/shlex."""
    if not exec_cmd:
        return ""
    return normalizar(_RE_ESPACOS.sub(" ", _RE_CODIGO_EXEC.sub("", exec_cmd)))


def comando_para_desktop_entry(arquivo, exec_cmd):
    """Como abrir um atalho .desktop neste desktop. gtk-launch é o ideal
    (respeita tudo que o atalho define), mas vem do GTK e pode não
    existir num KDE; então tenta o equivalente do GLib, o do KDE e,
    por fim, roda o Exec= do próprio atalho."""

    arquivo = Path(arquivo)

    # gtk-launch só acha atalhos pelo ID, nas pastas do XDG_DATA_DIRS;
    # um atalho do Snap/Flatpak fora dessa lista precisa ir pelo caminho.
    dados = (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":")
    dados.append(os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local/share"))
    alcancavel_por_id = any(
        arquivo.parent == Path(d) / "applications" for d in dados if d
    )

    if shutil.which("gtk-launch") and alcancavel_por_id:
        return ["gtk-launch", arquivo.stem]
    if shutil.which("gio"):
        return ["gio", "launch", str(arquivo)]
    if shutil.which("kioclient"):
        return ["kioclient", "exec", str(arquivo)]
    if shutil.which("kioclient5"):
        return ["kioclient5", "exec", str(arquivo)]

    exec_limpo = limpar_exec(exec_cmd)
    try:
        partes = shlex.split(exec_limpo)
    except ValueError:
        partes = exec_limpo.split()
    return partes or ["xdg-open", str(arquivo)]


def desktop_entries(forcar=False):
    agora = time.time()

    if (
        not forcar
        and _cache_desktop["dados"] is not None
        and (agora - _cache_desktop["ts"]) < CACHE_APPS_TTL
    ):
        return _cache_desktop["dados"]

    encontrados = []
    ids_vistos = set()

    for pasta in _pastas_de_aplicativos():

        if not pasta.is_dir():
            continue

        try:
            for arquivo in sorted(pasta.glob("*.desktop")):

                # Mesmo ID em duas pastas: vale a primeira (a do
                # usuário sobrepõe a do sistema, como no menu).
                if arquivo.name in ids_vistos:
                    continue
                ids_vistos.add(arquivo.name)

                # Só relê o arquivo se ele mudou desde a última
                # varredura; senão, reaproveita o que já foi lido.
                try:
                    mtime = arquivo.stat().st_mtime_ns
                except OSError:
                    continue
                chave = str(arquivo)
                guardado = _cache_arquivos_desktop.get(chave)
                if guardado and guardado[0] == mtime:
                    entrada = guardado[1]
                else:
                    entrada = _ler_desktop_entry(arquivo)
                    _cache_arquivos_desktop[chave] = (mtime, entrada)

                if entrada:
                    encontrados.append(entrada)

        except Exception:
            pass

    _cache_desktop["dados"] = encontrados
    _cache_desktop["ts"] = agora

    return encontrados


def flatpak_apps(forcar=False):
    agora = time.time()

    if (
        not forcar
        and _cache_flatpak["dados"] is not None
        and (agora - _cache_flatpak["ts"]) < CACHE_APPS_TTL
    ):
        return _cache_flatpak["dados"]

    resultado = []

    if not shutil.which("flatpak"):
        _cache_flatpak["dados"] = resultado
        _cache_flatpak["ts"] = agora
        return resultado

    r = executar_subprocesso(
        ["flatpak", "list", "--app", "--columns=application,name"],
        timeout=TIMEOUT_FLATPAK_LISTAGEM,
    )

    if r["codigo"] == 0:

        for linha in r["stdout"].splitlines():

            partes = linha.split("\t")

            if len(partes) >= 2:

                app_id = partes[0].strip()
                nome = partes[1].strip()

                if app_id:
                    resultado.append({
                        "nome": nome,
                        "id": app_id,
                    })

    _cache_flatpak["dados"] = resultado
    _cache_flatpak["ts"] = agora

    return resultado


def limpar_exec(exec_cmd):
    if not exec_cmd:
        return ""

    try:
        partes = shlex.split(exec_cmd)
        partes = [p for p in partes if not p.startswith("%")]
        return " ".join(partes)

    except Exception:
        return exec_cmd


def _pontuar_normalizado(alvo_n, nome_n, exec_n):
    if alvo_n == nome_n:
        return 1000

    if alvo_n == exec_n:
        return 950

    if nome_n.startswith(alvo_n):
        return 800

    if nome_n.endswith(alvo_n):
        return 750

    if f" {alvo_n} " in f" {nome_n} ":
        return 700

    if alvo_n in nome_n:
        return 500

    if alvo_n in exec_n:
        return 400

    return 0


def encontrar_app(alvo):
    alvo_original = alvo.strip()

    resultado = _buscar_app_no_sistema(alvo_original)

    if resultado:
        return resultado

    # Nada encontrado com o nome literal — em vez de desistir ou
    # depender de uma lista fixa de aliases, pergunta pro modelo leve
    # quais nomes de executável/pacote provavelmente correspondem ao
    # pedido, e tenta de novo a busca determinística com cada um.
    for candidato in perguntar_candidatos_app(alvo_original):

        resultado = _buscar_app_no_sistema(candidato)

        if resultado:
            resultado = dict(resultado)
            resultado["nome"] = alvo_original
            return resultado

    return None


def _buscar_app_no_sistema(alvo_original):
    """Busca determinística no sistema (sem IA), por ordem de
    confiança: executável exato no PATH, desktop entry por
    similaridade, flatpak instalado, e por fim um executável a partir
    de cada palavra do pedido."""

    alvo_original = alvo_original.strip()

    if not alvo_original:
        return None

    # 1. EXECUTÁVEL EXATO
    caminho = shutil.which(alvo_original)

    if caminho:
        return {
            "tipo": "executavel",
            "nome": alvo_original,
            "comando": [caminho],
            "origem": caminho,
        }

    # 2. DESKTOP ENTRY por similaridade
    entradas = desktop_entries()

    melhor = None
    melhor_pontuacao = 0

    alvo_n = normalizar_nome_app(alvo_original)

    for entrada in entradas:

        # Nome principal e os traduzidos (pt_BR) / genéricos contam
        # igual — "calculadora" acha o "Calculator".
        nomes_n = entrada.get("_nomes_n")
        if nomes_n is None:  # entrada montada fora de _ler_desktop_entry
            nomes_n = [normalizar_nome_app(n) for n in [entrada["nome"]] + entrada.get("outros_nomes", [])]
        exec_n = entrada.get("_exec_n")
        if exec_n is None:
            exec_n = normalizar(limpar_exec(entrada.get("exec", "")))

        pontos = max(_pontuar_normalizado(alvo_n, nome_n, exec_n) for nome_n in nomes_n)

        if pontos > melhor_pontuacao:
            melhor_pontuacao = pontos
            melhor = entrada

    if melhor and melhor_pontuacao >= 500:

        return {
            "tipo": "desktop",
            "nome": melhor["nome"],
            "arquivo": str(melhor["arquivo"]),
            "exec": melhor.get("exec"),
            "comando": comando_para_desktop_entry(melhor["arquivo"], melhor.get("exec")),
            "origem": str(melhor["arquivo"]),
        }

    # 3. FLATPAK
    alvo_n = normalizar(alvo_original)

    for app in flatpak_apps():

        app_nome_n = normalizar(app["nome"])

        if alvo_n == app_nome_n or alvo_n in app_nome_n:

            return {
                "tipo": "flatpak",
                "nome": app["nome"],
                "id": app["id"],
                "comando": ["flatpak", "run", app["id"]],
                "origem": "flatpak",
            }

    # 4. ÚLTIMA TENTATIVA: EXECUTÁVEL POR PALAVRA
    for parte in alvo_original.split():

        caminho = shutil.which(parte)

        if caminho:

            return {
                "tipo": "executavel",
                "nome": parte,
                "comando": [caminho],
                "origem": caminho,
            }

    return None


def _termos_do_app(app, encontrado):
    """Nomes pelos quais a janela/processo do app pode aparecer."""
    termos = [app, encontrado.get("nome", "")]
    partes_exec = limpar_exec(encontrado.get("exec") or "").split()
    if partes_exec and os.path.basename(partes_exec[0]) != "env":
        termos.append(os.path.basename(partes_exec[0]))
    if encontrado.get("arquivo"):
        stem = Path(encontrado["arquivo"]).stem  # org.gnome.Calculator
        termos += [stem, stem.split(".")[-1]]
    if encontrado.get("id"):
        termos.append(encontrado["id"].split(".")[-1])
    base = os.path.basename(encontrado["comando"][0])
    if base not in ("gtk-launch", "gio", "kioclient", "kioclient5", "flatpak", "xdg-open"):
        termos.append(base)
    return [t for t in dict.fromkeys(termos) if t]


def _processo_ativo(termos):
    alvos = {normalizar(t) for t in termos}
    for proc in psutil.process_iter(["name", "cmdline"]):
        try:
            nome = normalizar(proc.info["name"] or "")
            cmd = normalizar(" ".join(proc.info["cmdline"] or []))
            if nome in alvos or any(a in cmd for a in alvos if len(a) > 2):
                return True
        except Exception:
            continue
    return False


def _esperar_janela_do_app(termos, ids_antes, proc=None):
    """Espera a janela do app aparecer. Devolve (janela, ja_estava_aberta).

    Se já havia uma janela do app, ela só é considerada "a" janela quando
    o app claramente reaproveitou ela (ficou em foco) ou quando nenhuma
    nova apareceu no tempo todo: um app lento (LibreOffice, Firefox frio)
    ainda vai abrir a janela nova, e o próximo clique iria pra antiga."""

    pid = getattr(proc, "pid", None)
    inicio = time.time()
    existente = None

    while time.time() - inicio < TIMEOUT_JANELA_APP_SEG:
        janelas = listar_janelas_x() or []
        novas = [j for j in janelas if j["id"] not in ids_antes]

        janela = next((j for j in novas if pid and j["pid"] == pid), None) \
            or encontrar_janela(termos, novas)
        if janela:
            return janela, False

        if existente is None:
            existente = encontrar_janela(termos, [j for j in janelas if j["id"] in ids_antes]) or False
        if existente and time.time() - inicio > 0.8 and janela_ativa_x() == existente["id"]:
            return existente, True

        time.sleep(INTERVALO_POLL_JANELA_SEG)

    return (existente or None), bool(existente)


# Arquivos que só existem ao lado de um app Electron/Chromium.
_MARCAS_ELECTRON = ("resources.pak", "chrome_100_percent.pak", "v8_context_snapshot.bin",
                    "snapshot_blob.bin", os.path.join("resources", "app.asar"))
OPCAO_ACESSIBILIDADE_CHROMIUM = "--force-renderer-accessibility"


def _eh_electron(comando):
    """O comando abre um app Electron/Chromium (Claude, Discord, VS Code,
    Slack, Chrome...)? Pelo que existe ao lado do executável, ou pelo
    script lançador que chama o electron."""
    try:
        real = os.path.realpath(shutil.which(comando[0]) or comando[0])
    except Exception:
        return False
    pasta = os.path.dirname(real)
    if any(os.path.exists(os.path.join(pasta, marca)) for marca in _MARCAS_ELECTRON):
        return True
    try:
        if os.path.getsize(real) < 20000:
            with open(real, "rb") as arquivo:
                inicio = arquivo.read(20000)
            return inicio.startswith(b"#!") and re.search(rb"electron|app\.asar|chromium|google-chrome", inicio,
                                                          re.I) is not None
    except Exception:
        pass
    return False


def abrir_aplicativo(app):
    app = app.strip()

    encontrado = encontrar_app(app)

    if not encontrado:

        return {
            "sucesso": False,
            "acao": "open_application",
            "aplicativo": app,
            "mensagem": f"APP NOT FOUND: '{app}'. No installed application matches this name.",
        }

    comando = list(encontrado["comando"])
    # Electron/Chromium só mostra os botões pra acessibilidade se pedirem:
    # com isso, o clique pelo nome funciona no Claude, Discord, VS Code...
    if _eh_electron(comando) and OPCAO_ACESSIBILIDADE_CHROMIUM not in comando:
        comando.append(OPCAO_ACESSIBILIDADE_CHROMIUM)
    termos = _termos_do_app(app, encontrado)
    origem = encontrado["nome"] if encontrado["tipo"] == "desktop" else encontrado.get("origem", "")
    base_resultado = {"acao": "open_application", "aplicativo": app, "encontrado_como": origem}

    janelas_x = listar_janelas_x()
    ids_antes = {j["id"] for j in janelas_x or []}

    try:
        proc = subprocess.Popen(
            comando,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            # Chromium/Electron (Claude, Discord, VS Code, Chrome) só
            # expõem os botões pra acessibilidade com isso: aí o clique
            # pelo nome funciona neles também. Os outros apps ignoram.
            env={**os.environ, "ACCESSIBILITY_ENABLED": "1"},
        )
    except Exception as e:
        return {**base_resultado, "sucesso": False, "mensagem": f"ERROR opening '{app}': {e}"}

    # Com X: espera a JANELA (não só o processo) e traz ela pra frente —
    # assim o próximo passo (print, clique, digitar) já acontece nela.
    # No Wayland o X só enxerga janelas XWayland: esperar a janela de um
    # app nativo seria esperar à toa o tempo todo.
    if janelas_x is not None and SESSAO_GRAFICA == "x11":
        janela, ja_aberta = _esperar_janela_do_app(termos, ids_antes, proc)
        if janela:
            try:
                if janela["id"] != janela_ativa_x():
                    focar_janela_x(janela["id"])
            except Exception:
                pass
            _usar_quadro_tela_inteira()
            return {
                **base_resultado,
                "sucesso": True,
                "janela": _janela_para_ia(janela),
                "mensagem": (
                    f"SUCCESS: '{app}' "
                    + ("was already open; its window was brought to the front" if ja_aberta else "opened")
                    + f" (window '{janela['titulo']}', in the foreground)."
                    + _dica_clique_por_nome()
                ),
            }

        if proc is not None and proc.poll() not in (None, 0):
            return {
                **base_resultado,
                "sucesso": False,
                "mensagem": f"ERROR: the command to open '{app}' failed (exit code {proc.returncode}).",
            }

        return {
            **base_resultado,
            "sucesso": True,
            "mensagem": (
                f"The command to open '{app}' ran, but no window appeared within "
                f"{TIMEOUT_JANELA_APP_SEG:.0f}s. It may be an app without a window or "
                "one that is still loading: check with take_screenshot."
            ),
        }

    # Sem acesso às janelas: confirma pelo processo.
    inicio_poll = time.time()
    ativo = False
    while time.time() - inicio_poll < TIMEOUT_POLL_PROCESSO_SEG:
        if _processo_ativo(termos):
            ativo = True
            break
        time.sleep(INTERVALO_POLL_PROCESSO_SEG)

    return {
        **base_resultado,
        "sucesso": True,
        "mensagem": (
            f"SUCCESS: the application '{app}' is running."
            if ativo
            else f"SUCCESS: the command to open '{app}' was executed."
        ),
    }


def _pids_protegidos():
    """O próprio openTARS e o terminal/sessão que o abriu: "feche o
    python" ou "feche o terminal" não podem derrubar o openTARS."""
    protegidos = {os.getpid()}
    try:
        protegidos |= {p.pid for p in psutil.Process().parents()}
    except Exception:
        pass
    return protegidos


def _terminar_processos(alvo_n):
    """Termina todo processo cujo nome bata exatamente ou cuja linha de
    comando contenha alvo_n como um argumento/palavra inteira (já
    normalizado). Retorna a lista de pids encerrados.

    Antes isso usava `alvo_n in cmdline` (substring solta) — "code"
    batia em QUALQUER processo com "code" em qualquer parte da linha
    de comando, inclusive coisas sem relação nenhuma com o app pedido.
    Comparar por token evita matar um processo errado por causa de uma
    coincidência de texto."""

    encerrados = []

    protegidos = _pids_protegidos()

    for proc in psutil.process_iter(["pid", "name", "cmdline"]):

        try:

            pid = proc.info["pid"]
            if pid in protegidos:
                continue
            nome = normalizar(proc.info["name"] or "")
            cmdline = normalizar(" ".join(proc.info["cmdline"] or []))

            if alvo_n == nome:
                bateu = True
            elif " " in alvo_n:
                # alvo com espaço (ex: "gerenciador de arquivos") não é
                # um token só — comparar por substring direto continua
                # sendo a forma correta aqui, e o risco de bater à toa
                # é bem menor com uma frase inteira do que com uma
                # palavra solta.
                bateu = alvo_n in cmdline
            else:
                cmdline_tokens = set(re.split(r"[^a-z0-9]+", cmdline))
                bateu = alvo_n in cmdline_tokens

            if bateu:
                proc.terminate()
                encerrados.append(pid)

        except Exception:
            continue

    return encerrados


def _fechar_pelas_janelas(app):
    """Fecha as janelas cuja classe (o app dono) bate com o pedido.
    Título sozinho não conta: uma aba "Calculadora online" no navegador
    não é a calculadora."""

    protegidos = _pids_protegidos()
    janelas = [j for j in listar_janelas_x() or [] if j["pid"] not in protegidos]
    alvo = [j for j in janelas if _pontuar_janela(j, [app]) >= 2]
    if not alvo:
        encontrado = _buscar_app_no_sistema(app)
        if encontrado:
            termos = _termos_do_app(app, encontrado)
            alvo = [j for j in janelas if _pontuar_janela(j, termos) >= 2]
    if not alvo:
        return None

    for janela in alvo:
        try:
            fechar_janela_x(janela["id"])
        except Exception:
            pass

    ids = {j["id"] for j in alvo}
    limite = time.time() + 3
    while time.time() < limite:
        time.sleep(0.25)
        if not ids & {j["id"] for j in listar_janelas_x() or []}:
            break
    restantes = ids & {j["id"] for j in listar_janelas_x() or []}
    fechadas = [j["titulo"] for j in alvo if j["id"] not in restantes]
    abertas = [j["titulo"] for j in alvo if j["id"] in restantes]
    return fechadas, abertas


def fechar_aplicativo(app):
    alvo_n = normalizar(app)

    if normalizar_nome_app(app) in ("opentars", "tars", "open tars"):
        return {
            "sucesso": False,
            "acao": "close_application",
            "aplicativo": app,
            "mensagem": (
                "openTARS does not close itself in the middle of a request. Tell the "
                f"user that to quit they can type '{t('cmd.sair_principal')}' or close the window."
            ),
        }

    pelas_janelas = _fechar_pelas_janelas(app)
    if pelas_janelas is not None:
        fechadas, abertas = pelas_janelas
        if not abertas:
            return {
                "sucesso": True,
                "acao": "close_application",
                "aplicativo": app,
                "janelas_fechadas": fechadas,
                "mensagem": f"SUCCESS: closed {len(fechadas)} window(s) of '{app}'.",
            }
        # Janela que não fechou quase sempre está perguntando "salvar
        # alterações?". Matar o processo aqui faria o usuário perder o
        # que não salvou, então para e avisa.
        return {
            "sucesso": False,
            "acao": "close_application",
            "aplicativo": app,
            "janelas_abertas": abertas,
            "mensagem": (
                f"Asked '{app}' to close, but {len(abertas)} window(s) are still open "
                "(probably asking whether to save). Closing was not forced so nothing "
                "is lost: tell the user."
            ),
        }

    encerrados = _terminar_processos(alvo_n)

    if not encerrados:

        # Nenhum processo bateu com o nome literal — em vez de uma
        # lista fixa de aliases, pergunta pro modelo leve nomes
        # prováveis de executável e tenta de novo.
        for candidato in perguntar_candidatos_app(app):

            encerrados = _terminar_processos(normalizar(candidato))

            if encerrados:
                break

    if encerrados:

        return {
            "sucesso": True,
            "acao": "close_application",
            "aplicativo": app,
            "mensagem": f"SUCCESS: application '{app}' was closed.",
            "pids": encerrados,
        }

    return {
        "sucesso": False,
        "acao": "close_application",
        "aplicativo": app,
        "mensagem": f"No running process matches '{app}'.",
    }


# ============================================================
# SITES
# ============================================================

# Nomes que quase sempre significam "abra o NAVEGADOR", não "visite um
# site chamado assim" — um modelo (principalmente os menores) às vezes
# chama open_website pra isso, quando o certo seria open_application.
# Em vez de depender só do prompt pra evitar essa confusão, a própria
# ferramenta redireciona pra abrir o aplicativo de verdade.
# Marcas (iguais em qualquer idioma). A palavra "navegador" em cada
# idioma vem dos arquivos de idioma (palavras.navegador).
_MARCAS_NAVEGADORES = {
    "chrome", "google chrome", "chromium", "firefox", "brave", "edge",
    "microsoft edge", "opera", "vivaldi", "safari", "browser",
}


def abrir_site(site):
    entrada = site.strip()

    # Hífen vira espaço só pra essa checagem ("google-chrome" ==
    # "google chrome") — não afeta o resto da função.
    entrada_normalizada = re.sub(r"[\s-]+", " ", normalizar(entrada)).strip()

    if entrada_normalizada in _vocab()["navegadores"]:
        resultado = abrir_aplicativo(entrada)
        resultado["mensagem"] = (
            f"('{entrada}' was requested as a website, but it is a browser — "
            "opened it as an application instead) "
            + resultado.get("mensagem", "")
        )
        return resultado

    url = None

    if entrada.startswith(("http://", "https://")):
        url = entrada

    elif "." in entrada and " " not in entrada:
        # parece já ser um domínio (ex: "github.com")
        url = "https://" + entrada

    else:
        # Não é uma URL nem parece um domínio. Primeiro checa se é um
        # pedido de busca DENTRO de um serviço conhecido (ex: "canal
        # da anthropic no youtube") — pedir pra uma IA pequena adivinhar
        # a URL exata de algo assim é o tipo de pedido que ela não tem
        # como saber de cor, e ela tende a inventar um domínio que não
        # existe. Só depois disso tenta a IA leve pra qualquer outro
        # site desconhecido.
        url = _resolver_busca(entrada) or perguntar_url_site(entrada)

    if url is None:
        url = "https://www.google.com/search?q=" + quote_plus(entrada)

    try:

        webbrowser.open(url)

        return {
            "sucesso": True,
            "acao": "open_website",
            "entrada": entrada,
            "url": url,
            "mensagem": f"SUCCESS: opened '{entrada}' at {url}.",
        }

    except Exception as e:

        return {
            "sucesso": False,
            "acao": "open_website",
            "entrada": entrada,
            "mensagem": f"ERROR opening the website: {e}",
        }


def pesquisar_web(query, service=None):
    """Handler da ferramenta search_web — pensada pra ser a forma
    ÓBVIA e sem ambiguidade de fazer uma busca: a própria IA decide
    separar 'o que pesquisar' (query) de 'onde pesquisar' (service),
    em vez de o código ter que adivinhar isso tentando reconhecer
    verbos/serviços dentro de uma frase livre (o problema real de
    antes não era a IA ser burra, era a ferramenta open_website não
    ter um jeito claro de dizer 'isso aqui é uma busca, e isso aqui é
    só o termo' — ela só tinha um campo 'site' genérico, então um
    modelo pequeno podia repassar a frase cortada pela metade).

    Uma query vazia é um erro claro (a IA esqueceu de preencher o
    campo), não motivo pra adivinhar nada."""

    query = (query or "").strip()

    if not query:
        return {
            "sucesso": False,
            "acao": "search_web",
            "mensagem": "ERROR: no search terms given (empty 'query').",
        }

    servico_normalizado = normalizar(service or "").strip()
    url_base = _BUSCAS_POR_SERVICO.get(servico_normalizado, GOOGLE_SEARCH_URL)
    url = url_base + quote_plus(query)

    try:

        webbrowser.open(url)

        return {
            "sucesso": True,
            "acao": "search_web",
            "query": query,
            "servico": servico_normalizado or "google",
            "url": url,
            "mensagem": f"SUCCESS: searched for '{query}' and opened the results at {url}.",
        }

    except Exception as e:

        return {
            "sucesso": False,
            "acao": "search_web",
            "mensagem": f"ERROR while searching: {e}",
        }
