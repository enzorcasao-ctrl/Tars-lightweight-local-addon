"""openTARS 3.0: voz.

- ouvir: o microfone (arecord / parecord / pw-record, o que houver) vira
  trechos de fala (Segmentador: energia com piso de ruído que se adapta);
- palavra de ativação: cada trecho curto passa por um Whisper pequeno
  (tiny); se começa com "TARS" ("ei TARS", "ok TARS"...), o trecho é
  transcrito de novo com o modelo melhor e o que vem depois do nome é o
  pedido. "TARS" sozinho: o próximo trecho é o pedido;
- transcrever: faster-whisper (roda na CPU, int8);
- falar: Piper (voz neural local) + o tocador que houver (pw-play,
  paplay, aplay).

Tudo 100% local. As dependências (faster-whisper, piper-tts) e os modelos
(~470 MB de bibliotecas, ~220 MB dos modelos do Whisper e ~60 MB por voz) só são baixados quando a pessoa
liga a voz (instalar()).

A lógica pura (Segmentador, achar_ativacao, limpar_para_fala, escolhas de
voz e de programa) não depende de nada instalado e é testada sozinha."""

import array
import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
from pathlib import Path

TAXA = 16000               # Hz, mono, 16 bits: o que o Whisper quer
BYTES_AMOSTRA = 2
QUADRO_MS = 30

# ------------------------------------------------------------
# Onde ficam os modelos
# ------------------------------------------------------------


def pasta_dados():
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "opentars" / "voz"


def pasta_pacotes():
    """Onde o openTARS instala as bibliotecas da voz: na pasta da PESSOA (o
    Python do openTARS fica em /usr/share, que é do root), uma por versão
    do Python (atualizar o sistema não quebra)."""
    return pasta_dados() / f"python{sys.version_info.major}.{sys.version_info.minor}"


def _ativar_pacotes():
    pasta = str(pasta_pacotes())
    if Path(pasta).is_dir() and pasta not in sys.path:
        sys.path.append(pasta)
    return pasta


_ativar_pacotes()

MODELO_WHISPER = os.environ.get("TARS_WHISPER", "base")          # o pedido
MODELO_WHISPER_ATIVACAO = os.environ.get("TARS_WHISPER_ATIVACAO", "tiny")  # só achar o "TARS"

# Uma voz por idioma da interface (rhasspy/piper-voices).
VOZES = {
    "pt_BR": ("pt", "pt_BR", "faber", "medium"),
    "en": ("en", "en_US", "lessac", "medium"),
    "es": ("es", "es_ES", "davefx", "medium"),
    "fr": ("fr", "fr_FR", "siwis", "medium"),
    "de": ("de", "de_DE", "thorsten", "medium"),
}
URL_VOZ = ("https://huggingface.co/rhasspy/piper-voices/resolve/main/"
           "{familia}/{codigo}/{nome}/{qualidade}/{codigo}-{nome}-{qualidade}{extensao}?download=true")

IDIOMA_WHISPER = {"pt_BR": "pt", "pt": "pt", "en": "en", "es": "es", "fr": "fr", "de": "de"}

# Só o nome, sem frase de exemplo: uma frase longa (a do 3.0 Miller, em
# português) fazia o Whisper "ouvir" coisas que ninguém falou.
DICA = "TARS, openTARS."

# O que o TARS responde quando ouve só o nome
CONFIRMACOES = {"pt_BR": "Sim?", "en": "Yes?", "es": "¿Sí?", "fr": "Oui ?", "de": "Ja?"}


def arquivo_voz(idioma):
    familia, codigo, nome, qualidade = VOZES.get(idioma) or VOZES["en"]
    return pasta_dados() / f"{codigo}-{nome}-{qualidade}.onnx"


def urls_voz(idioma):
    familia, codigo, nome, qualidade = VOZES.get(idioma) or VOZES["en"]
    campos = dict(familia=familia, codigo=codigo, nome=nome, qualidade=qualidade)
    return URL_VOZ.format(extensao=".onnx", **campos), URL_VOZ.format(extensao=".onnx.json", **campos)


# ------------------------------------------------------------
# Programas de áudio
# ------------------------------------------------------------
GRAVADORES = (
    ("arecord", ["arecord", "-q", "-f", "S16_LE", "-r", str(TAXA), "-c", "1", "-t", "raw"]),
    ("parecord", ["parecord", "--raw", f"--rate={TAXA}", "--channels=1", "--format=s16le"]),
    ("pw-record", ["pw-record", "--rate", str(TAXA), "--channels", "1", "--format", "s16", "-"]),
)
TOCADORES = (
    ("pw-play", ["pw-play"]),
    ("paplay", ["paplay"]),
    ("aplay", ["aplay", "-q"]),
)


def _primeiro(programas, existe=shutil.which):
    for programa, comando in programas:
        if existe(programa):
            return list(comando)
    return None


def comando_gravar(existe=shutil.which):
    return _primeiro(GRAVADORES, existe)


def comando_tocar(existe=shutil.which):
    return _primeiro(TOCADORES, existe)


def _tem_modulo(nome):
    try:
        return importlib.util.find_spec(nome) is not None
    except (ImportError, ValueError):
        return False


def o_que_falta(idioma="en", existe=shutil.which, tem_modulo=_tem_modulo):
    """Lista do que falta pra voz funcionar (vazia = pronta). Cada item é
    uma chave curta: 'faster-whisper', 'piper-tts', 'voz', 'gravador', 'tocador'."""
    falta = []
    if not tem_modulo("faster_whisper"):
        falta.append("faster-whisper")
    if not tem_modulo("piper"):
        falta.append("piper-tts")
    if not arquivo_voz(idioma).exists():
        falta.append("voz")
    if not comando_gravar(existe):
        falta.append("gravador")
    if not comando_tocar(existe):
        falta.append("tocador")
    return falta


# ------------------------------------------------------------
# Instalação (só quando a pessoa liga a voz)
# ------------------------------------------------------------
PACOTES = ("faster-whisper", "piper-tts")


def instalar(idioma, avisar=print):
    """Instala as bibliotecas no Python do openTARS, baixa a voz do idioma
    e os modelos do Whisper. Devolve (ok, mensagem)."""
    falta = o_que_falta(idioma)
    if "faster-whisper" in falta or "piper-tts" in falta:
        avisar("pip install " + " ".join(PACOTES))
        pasta = pasta_pacotes()
        pasta.mkdir(parents=True, exist_ok=True)
        comando = [sys.executable, "-m", "pip", "install", "--quiet", "--upgrade", "--target", str(pasta), *PACOTES]
        r = subprocess.run(comando, capture_output=True, text=True)
        if r.returncode != 0:
            return False, (r.stderr or r.stdout or "pip failed").strip()[-600:]
        _ativar_pacotes()
        importlib.invalidate_caches()
    if not arquivo_voz(idioma).exists():
        ok, erro = baixar_voz(idioma, avisar)
        if not ok:
            return False, erro
    avisar(f"Whisper {MODELO_WHISPER_ATIVACAO} + {MODELO_WHISPER}")
    try:
        Transcritor(MODELO_WHISPER_ATIVACAO).carregar()
        Transcritor(MODELO_WHISPER).carregar()
    except Exception as e:
        return False, f"Whisper: {e}"
    falta = o_que_falta(idioma)
    if falta:
        return False, "missing: " + ", ".join(falta)
    return True, ""


def baixar_voz(idioma, avisar=print):
    import requests  # só aqui: o resto do módulo não precisa

    destino = arquivo_voz(idioma)
    destino.parent.mkdir(parents=True, exist_ok=True)
    for url, caminho in zip(urls_voz(idioma), (destino, Path(str(destino) + ".json"))):
        avisar(f"{caminho.name}...")
        temporario = caminho.with_suffix(caminho.suffix + ".parte")
        try:
            with requests.get(url, stream=True, timeout=60) as r:
                r.raise_for_status()
                with open(temporario, "wb") as f:
                    for bloco in r.iter_content(1 << 16):
                        f.write(bloco)
            os.replace(temporario, caminho)
        except Exception as e:
            try:
                temporario.unlink()
            except OSError:
                pass
            return False, f"{caminho.name}: {e}"
    return True, ""


# ------------------------------------------------------------
# Segmentador: microfone -> trechos de fala
# ------------------------------------------------------------
LIMIAR_MINIMO = 350        # RMS (0–32768): abaixo disso nunca é fala
FATOR_RUIDO = 3.0          # fala = mais que 3x o ruído de fundo
SILENCIO_FIM_MS = 600      # tanto silêncio encerra o trecho
FALA_MINIMA_MS = 250       # menos que isso é estalo, tosse, clique
FALA_MAXIMA_S = 12
PRE_ROLL_MS = 300          # o começo da palavra fica abaixo do limiar
AQUECIMENTO_MS = 250       # o começo só aprende o ruído de fundo (ventoinha, rua)


def rms(quadro):
    amostras = array.array("h")
    amostras.frombytes(quadro[: len(quadro) - len(quadro) % 2])
    if sys.byteorder == "big":
        amostras.byteswap()
    if not amostras:
        return 0.0
    return math.sqrt(sum(a * a for a in amostras) / len(amostras))


class Segmentador:
    """Recebe áudio cru (16 kHz, 16 bits, mono) em pedaços de qualquer
    tamanho e devolve os trechos de fala completos (bytes)."""

    def __init__(self, taxa=TAXA, quadro_ms=QUADRO_MS):
        self.bytes_quadro = int(taxa * quadro_ms / 1000) * BYTES_AMOSTRA
        self.quadro_ms = quadro_ms
        self.piso = None
        self._resto = b""
        self._pre = []
        self._fala = []
        self._silencio_ms = 0
        self._fala_ms = 0
        self._aquecido_ms = 0
        self.id_trecho = 0        # sobe a cada fala que começa

    @property
    def limiar(self):
        return max(LIMIAR_MINIMO, (self.piso or 0) * FATOR_RUIDO)

    def alimentar(self, dados):
        return [trecho for _id, trecho in self.alimentar_com_id(dados)]

    def alimentar_com_id(self, dados):
        """Como alimentar(), mas cada trecho vem com o id da fala: [(id, bytes)]."""
        prontos = []
        dados = self._resto + dados
        n = len(dados) - len(dados) % self.bytes_quadro
        self._resto = dados[n:]
        for i in range(0, n, self.bytes_quadro):
            ident = self.id_trecho
            trecho = self._quadro(dados[i:i + self.bytes_quadro])
            if trecho:
                prontos.append((ident, trecho))
        return prontos

    @property
    def falando_ms(self):
        """Quanto da fala EM ANDAMENTO já chegou (0 se ninguém está falando)."""
        return len(self._fala) * self.quadro_ms if self._fala else 0

    def audio_parcial(self, max_s):
        """O começo da fala em andamento (até max_s segundos)."""
        return b"".join(self._fala[:int(max_s * 1000 / self.quadro_ms)])

    def _quadro(self, quadro):
        energia = rms(quadro)
        if self._aquecido_ms < AQUECIMENTO_MS:
            # o quadro mais quieto do começo é o ruído de fundo; os quadros
            # ficam no pre-roll (quem já começou a falar não perde o início)
            self._aquecido_ms += self.quadro_ms
            self.piso = energia if self.piso is None else min(self.piso, energia)
            self._pre.append(quadro)
            if len(self._pre) * self.quadro_ms > PRE_ROLL_MS:
                self._pre.pop(0)
            return None
        falando = energia > self.limiar
        if not self._fala:
            if falando:
                self.id_trecho += 1
                self._fala = list(self._pre) + [quadro]
                self._fala_ms = self.quadro_ms
                self._silencio_ms = 0
                self._pre = []
                return None
            # silêncio: aprende o ruído de fundo e guarda o pre-roll
            self.piso = energia if self.piso is None else 0.95 * self.piso + 0.05 * energia
            self._pre.append(quadro)
            if len(self._pre) * self.quadro_ms > PRE_ROLL_MS:
                self._pre.pop(0)
            return None
        self._fala.append(quadro)
        if falando:
            self._fala_ms += self.quadro_ms
            self._silencio_ms = 0
        else:
            self._silencio_ms += self.quadro_ms
        total_ms = len(self._fala) * self.quadro_ms
        if self._silencio_ms >= SILENCIO_FIM_MS or total_ms >= FALA_MAXIMA_S * 1000:
            fala, fala_ms = b"".join(self._fala), self._fala_ms
            self._fala, self._fala_ms, self._silencio_ms = [], 0, 0
            if fala_ms >= FALA_MINIMA_MS:
                return fala
        return None


# ------------------------------------------------------------
# Palavra de ativação
# ------------------------------------------------------------
# O Whisper escreve "TARS" de vários jeitos: Tars, Tarz, Thars, Taars...
_RE_ATIVACAO = re.compile(r"\b(?:open[\s-]?)?th?a{1,2}r[sz]{1,2}h?\b[\s,.!?:;…-]*", re.IGNORECASE)
PALAVRAS_ANTES_MAX = 2     # "ei TARS", "ok TARS", "hey there TARS": o nome vem logo no começo


def _sem_acento(texto):
    """Tira acentos SEM mudar o tamanho do texto (um caractere por
    caractere): as posições achadas valem pro texto original."""
    return "".join(unicodedata.normalize("NFD", ch)[0] for ch in texto)


def achar_ativacao(texto):
    """(chamou, resto): 'Ei TARS, abre o Firefox.' -> (True, 'abre o Firefox.').
    Só vale com o nome no começo (até 2 palavras antes), pra não ligar
    quando alguém só fala SOBRE o TARS."""
    original = (texto or "").strip()
    achado = _RE_ATIVACAO.search(_sem_acento(original))
    if not achado:
        return False, ""
    antes = re.findall(r"\w+", original[:achado.start()])
    if len(antes) > PALAVRAS_ANTES_MAX:
        return False, ""
    resto = original[achado.end():].strip(" \t,.;:!?-…")
    if resto and not re.search(r"\w", resto):
        resto = ""
    return True, resto


# ------------------------------------------------------------
# Texto -> fala
# ------------------------------------------------------------
LIMITE_FALA = 700  # caracteres: resposta longa é lida até aí (o resto está na tela)


def limpar_para_fala(texto, limite=LIMITE_FALA):
    """Tira o que não se fala: blocos de código, markdown, links, emoji."""
    t = texto or ""
    t = re.sub(r"```.*?(```|$)", " ", t, flags=re.S)
    t = re.sub(r"`([^`]*)`", r"\1", t)
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", t)
    t = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", t)
    t = re.sub(r"https?://\S+", " ", t)
    t = re.sub(r"^\s{0,3}#{1,6}\s*", "", t, flags=re.M)
    t = re.sub(r"^\s*[-*•]\s+", "", t, flags=re.M)
    t = re.sub(r"^\s*\|.*\|\s*$", " ", t, flags=re.M)      # tabelas
    t = re.sub(r"[*_~]{1,3}([^*_~\n]+)[*_~]{1,3}", r"\1", t)
    t = "".join(ch for ch in t if unicodedata.category(ch) not in ("So", "Cs", "Co"))
    t = re.sub(r"\s*\n\s*", ". ", t.strip())
    t = re.sub(r"\.(\s*\.)+", ".", t)
    t = re.sub(r"([!?:;])\.", r"\1", t)
    t = re.sub(r"\s{2,}", " ", t).strip(" .")
    if len(t) > limite:
        corte = t[:limite]
        fim = max(corte.rfind(". "), corte.rfind("! "), corte.rfind("? "))
        t = corte[:fim + 1] if fim > limite // 3 else corte.rsplit(" ", 1)[0] + "..."
    return t


# ------------------------------------------------------------
# Whisper
# ------------------------------------------------------------
class Transcritor:
    _cache = {}
    _trava = threading.Lock()

    def __init__(self, tamanho=MODELO_WHISPER):
        self.tamanho = tamanho

    def carregar(self):
        with self._trava:
            modelo = self._cache.get(self.tamanho)
            if modelo is None:
                from faster_whisper import WhisperModel
                modelo = WhisperModel(self.tamanho, device="cpu", compute_type="int8")
                self._cache[self.tamanho] = modelo
            return modelo

    def transcrever(self, audio, idioma=None, dica=None, rapido=False):
        """Texto do áudio (bytes 16 kHz 16 bits mono). rapido=True: só
        pra achar o "TARS" (poucos tokens)."""
        import numpy as np

        dados = np.frombuffer(audio, dtype=np.int16).astype(np.float32) / 32768.0
        opcoes = dict(
            language=IDIOMA_WHISPER.get(idioma), beam_size=1, vad_filter=False,
            initial_prompt=dica or DICA, condition_on_previous_text=False,
            temperature=0.0,             # sem refazer a decodificação com outras temperaturas: mais rápido
            without_timestamps=True,
        )
        if rapido:
            opcoes["max_new_tokens"] = 12
        modelo = self.carregar()
        while True:
            try:
                segmentos, _info = modelo.transcribe(dados, **opcoes)
                return " ".join(s.text.strip() for s in segmentos).strip()
            except TypeError as e:  # faster-whisper antigo: tira a opção que ele não conhece
                opcao = next((k for k in ("max_new_tokens", "without_timestamps") if k in opcoes
                              and k in str(e)), None)
                if not opcao:
                    raise
                opcoes.pop(opcao)

    def aquecer(self):
        """Carrega e roda uma vez (a primeira transcrição é a mais lenta)."""
        self.transcrever(b"\x00\x00" * (TAXA // 2), "en", rapido=True)


# ------------------------------------------------------------
# Falar (Piper)
# ------------------------------------------------------------
class Falador:
    def __init__(self, tocar=None):
        self._processos = []
        self._trava = threading.Lock()
        self.falando = threading.Event()   # ligado enquanto QUALQUER fala estiver em andamento
        self._falas = 0
        self._tocar = tocar

    def _comecou(self):
        with self._trava:
            self._falas += 1
            self.falando.set()

    def _acabou(self):
        with self._trava:
            self._falas = max(0, self._falas - 1)
            if not self._falas:
                self.falando.clear()

    def falar(self, texto, idioma, esperar=False, ao_terminar=None):
        texto = limpar_para_fala(texto)
        if not texto:
            return False
        thread = threading.Thread(target=self._falar, args=(texto, idioma, ao_terminar), daemon=True)
        thread.start()
        if esperar:
            thread.join()
        return True

    # --- "Sim?" quando ouve só o nome ---
    @staticmethod
    def _arquivo_confirmacao(idioma):
        return pasta_dados() / "cache" / f"sim-{idioma}.wav"

    def preparar_confirmacao(self, idioma):
        """Gera (uma vez) o "Sim?" na voz do idioma, pra tocar na hora."""
        destino = self._arquivo_confirmacao(idioma)
        if destino.exists() or not arquivo_voz(idioma).exists():
            return destino.exists()
        destino.parent.mkdir(parents=True, exist_ok=True)
        return self._sintetizar(CONFIRMACOES.get(idioma, "Yes?"), idioma, destino) and destino.exists()

    def confirmar(self, idioma):
        """Toca o "Sim?" (ou um sininho, se a voz ainda não estiver pronta)
        sem travar: é o sinal de que ouviu o nome."""
        tocador = self._tocar or comando_tocar()
        if not tocador:
            return False
        arquivo = self._arquivo_confirmacao(idioma)
        if not arquivo.exists():
            arquivo = pasta_dados() / "cache" / "sininho.wav"
            if not arquivo.exists():
                arquivo.parent.mkdir(parents=True, exist_ok=True)
                arquivo.write_bytes(sininho_wav())
        self._comecou()  # já conta como falando: o microfone não ouve o próprio "Sim?"

        def tocar():
            try:
                subprocess.run(tocador + [str(arquivo)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=10)
            except Exception:
                pass
            finally:
                self._acabou()
        threading.Thread(target=tocar, daemon=True).start()
        return True

    def _sintetizar(self, texto, idioma, destino):
        ambiente = dict(os.environ)
        ambiente["PYTHONPATH"] = os.pathsep.join(
            x for x in (str(pasta_pacotes()), os.environ.get("PYTHONPATH", "")) if x)
        try:
            r = subprocess.run([sys.executable, "-m", "piper", "-m", str(arquivo_voz(idioma)), "-f", str(destino)],
                               input=texto.encode("utf-8"), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               env=ambiente, timeout=60)
            return r.returncode == 0
        except Exception:
            return False

    def _falar(self, texto, idioma, ao_terminar=None):
        try:
            self._falar_de_fato(texto, idioma)
        finally:
            if ao_terminar is not None:
                try:
                    ao_terminar()
                except Exception:
                    pass

    def _falar_de_fato(self, texto, idioma):
        self.parar()
        modelo = arquivo_voz(idioma)
        tocador = self._tocar or comando_tocar()
        if not modelo.exists() or not tocador:
            return
        fd, wav = tempfile.mkstemp(suffix=".wav", prefix="opentars-fala-")
        os.close(fd)
        self._comecou()
        meus = []
        try:
            ambiente = dict(os.environ)
            ambiente["PYTHONPATH"] = os.pathsep.join(
                x for x in (str(pasta_pacotes()), os.environ.get("PYTHONPATH", "")) if x)
            gerar = subprocess.Popen([sys.executable, "-m", "piper", "-m", str(modelo), "-f", wav],
                                     stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                     env=ambiente)
            meus.append(gerar)
            with self._trava:
                self._processos.append(gerar)
            gerar.communicate(texto.encode("utf-8"), timeout=120)
            if gerar.returncode != 0:
                return
            tocar = subprocess.Popen(tocador + [wav], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            meus.append(tocar)
            with self._trava:
                self._processos.append(tocar)
            tocar.wait(timeout=300)
        except Exception:
            pass
        finally:
            for p in meus:  # timeout ou erro: nada fica tocando/gerando sozinho
                if p.poll() is None:
                    try:
                        p.kill()
                        p.wait(timeout=5)
                    except Exception:
                        pass
            with self._trava:
                self._processos = [p for p in self._processos if p.poll() is None]
            self._acabou()
            try:
                os.unlink(wav)
            except OSError:
                pass

    def parar(self):
        with self._trava:
            for p in self._processos:
                if p.poll() is None:
                    try:
                        p.terminate()
                    except Exception:
                        pass
            self._processos = []


# ------------------------------------------------------------
# Ouvir
# ------------------------------------------------------------
ESPERA_PEDIDO_S = 8      # depois de "TARS" sozinho, quanto tempo espera o pedido
ESPERA_CONVERSA_S = 7    # depois de responder falando: dá pra continuar sem dizer "TARS"
CEDO_MS = 650            # com tanto de fala, já confere se começou com "TARS" (sem esperar a pausa)
CEDO_MAX_S = 1.6         # o nome vem no começo: basta olhar esse pedaço


class Ouvinte:
    """Escuta o microfone numa thread.

    modo "ativacao": fica ouvindo; cada trecho que começa com "TARS" vira
    pedido (ao_pedido(texto)). modo "uma_vez": o primeiro trecho de fala é
    o pedido e para (o botão "Falar agora").

    Pra responder rápido (3.0 Miller):
    - os dois Whisper são carregados e "aquecidos" assim que começa a ouvir
      (antes, o primeiro "TARS" esperava o modelo carregar);
    - com ~0,65 s de fala, já confere (em paralelo, sem parar de gravar) se
      começou com "TARS": a tela mostra na hora que ouviu, e no fim da fala
      só falta transcrever o pedido;
    - "TARS" sozinho: responde "Sim?" na voz do idioma (ou um sininho) e o
      próximo trecho é o pedido;
    - depois de responder falando, dá pra continuar sem dizer "TARS"
      (abrir_conversa).

    ao_estado(estado): "carregando", "ouvindo", "chamado" (ouviu o nome),
    "conversa" (pode continuar sem o nome), "transcrevendo", "parado",
    ou "erro:<motivo>"."""

    def __init__(self, ao_pedido, idioma, modo="ativacao", ao_estado=None, falador=None,
                 gravar=None, transcritor=None, transcritor_ativacao=None, aquecer=True):
        self.ao_pedido = ao_pedido
        self.idioma = idioma if callable(idioma) else (lambda: idioma)
        self.modo = modo
        self.ao_estado = ao_estado or (lambda estado: None)
        self.falador = falador
        self._gravar = gravar
        self._transcritor = transcritor or Transcritor(MODELO_WHISPER)
        self._ativacao = transcritor_ativacao or Transcritor(MODELO_WHISPER_ATIVACAO)
        self._aquecer = aquecer
        self._parar = threading.Event()
        self._thread = None
        self._processo = None
        self.chamado_ate = 0.0
        # conferência "cedo" do nome: id do trecho -> (chamou, resto); e a thread em andamento
        self._cedo = {}
        self._cedo_id = None
        self._cedo_thread = None

    @property
    def ativo(self):
        return self._thread is not None and self._thread.is_alive()

    def iniciar(self):
        if self.ativo:
            return
        self._parar.clear()
        self._thread = threading.Thread(target=self._rodar, daemon=True)
        self._thread.start()

    def parar(self):
        self._parar.set()
        if self._processo is not None:
            try:
                self._processo.terminate()
            except Exception:
                pass

    def abrir_conversa(self, segundos=ESPERA_CONVERSA_S):
        """Por alguns segundos, a próxima fala é pedido mesmo sem "TARS"."""
        if self.ativo and self.modo == "ativacao":
            self.chamado_ate = time.monotonic() + segundos
            self.ao_estado("conversa")

    def _preparar(self):
        """Carrega os modelos (e o "Sim?" falado) antes da primeira fala."""
        if not self._aquecer:
            return
        self.ao_estado("carregando")
        for transcritor in ((self._ativacao, self._transcritor) if self.modo == "ativacao" else (self._transcritor,)):
            try:
                transcritor.aquecer()
            except Exception:
                pass
        if self.falador is not None and hasattr(self.falador, "preparar_confirmacao"):
            threading.Thread(target=self.falador.preparar_confirmacao, args=(self.idioma(),), daemon=True).start()

    def _fonte(self):
        """Iterador de pedaços de áudio cru."""
        if self._gravar is not None:
            yield from self._gravar()
            return
        comando = comando_gravar()
        if not comando:
            raise RuntimeError("no recorder (install alsa-utils or pulseaudio-utils)")
        self._processo = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try:
            while not self._parar.is_set():
                bloco = self._processo.stdout.read(1600)  # 50 ms: reage mais rápido ao fim da fala
                if not bloco:
                    break
                yield bloco
        finally:
            try:
                self._processo.terminate()
            except Exception:
                pass

    def _rodar(self):
        segmentador = Segmentador()
        try:
            self._preparar()
            self.ao_estado("ouvindo")
            for bloco in self._fonte():
                if self._parar.is_set():
                    break
                if self.falador is not None and self.falador.falando.is_set():
                    continue  # não ouve a própria voz
                prontos = segmentador.alimentar_com_id(bloco)
                self._conferir_cedo(segmentador)
                for ident, trecho in prontos:
                    if self._tratar(trecho, ident) and self.modo == "uma_vez":
                        self._parar.set()
                        break
                if self._parar.is_set():
                    break
        except Exception as e:
            self.ao_estado(f"erro:{e}")
            return
        self.ao_estado("parado")

    # --- nome conferido enquanto a pessoa ainda fala ---
    def _esperando_pedido(self):
        return self.modo == "uma_vez" or time.monotonic() < self.chamado_ate

    def _conferir_cedo(self, segmentador):
        if (self.modo != "ativacao" or self._esperando_pedido() or segmentador.falando_ms < CEDO_MS
                or segmentador.id_trecho == self._cedo_id
                or (self._cedo_thread is not None and self._cedo_thread.is_alive())):
            return
        ident = self._cedo_id = segmentador.id_trecho
        audio = segmentador.audio_parcial(CEDO_MAX_S)
        idioma = self.idioma()

        def conferir():
            try:
                chamou, resto = achar_ativacao(self._ativacao.transcrever(audio, idioma, rapido=True))
            except Exception:
                chamou, resto = False, ""
            self._cedo[ident] = (chamou, resto)
            if chamou:
                self.ao_estado("chamado")  # a pessoa vê na hora que foi ouvida

        self._cedo_thread = threading.Thread(target=conferir, daemon=True)
        self._cedo_thread.start()

    def _nome_no_trecho(self, trecho, ident, idioma):
        """(chamou, resto) do começo do trecho: da conferência cedo, se houve."""
        if ident is not None and ident == self._cedo_id and self._cedo_thread is not None:
            self._cedo_thread.join(timeout=10)
        if ident in self._cedo:
            return self._cedo.pop(ident)
        inicio = trecho[:int(CEDO_MAX_S * TAXA) * BYTES_AMOSTRA]
        return achar_ativacao(self._ativacao.transcrever(inicio, idioma, rapido=True))

    def _confirmar_chamado(self, idioma):
        if self.falador is not None and hasattr(self.falador, "confirmar"):
            try:
                self.falador.confirmar(idioma)
            except Exception:
                pass

    def _tratar(self, trecho, ident=None):
        """True se o trecho virou pedido."""
        idioma = self.idioma()
        if self._esperando_pedido():
            self.ao_estado("transcrevendo")
            texto = self._transcritor.transcrever(trecho, idioma)
            chamou, resto = achar_ativacao(texto)
            texto = resto if chamou and resto else texto
            self.chamado_ate = 0.0
            if texto and re.search(r"\w", texto) and not (chamou and not resto):
                self.ao_pedido(texto)
                self.ao_estado("ouvindo")
                return True
            if chamou:  # disse só "TARS" de novo: continua esperando
                self.chamado_ate = time.monotonic() + ESPERA_PEDIDO_S
                self._confirmar_chamado(idioma)
                self.ao_estado("chamado")
                return False
            self.ao_estado("ouvindo")
            return False
        chamou, resto = self._nome_no_trecho(trecho, ident, idioma)
        if not chamou:
            return False
        duracao = len(trecho) / BYTES_AMOSTRA / TAXA
        if resto or duracao > CEDO_MAX_S:
            # o pedido veio junto ("TARS, abre o Firefox"): o bom transcreve tudo
            self.ao_estado("transcrevendo")
            completo = self._transcritor.transcrever(trecho, idioma)
            chamou2, resto2 = achar_ativacao(completo)
            pedido = resto2 or (resto if chamou2 else completo)
            if pedido and re.search(r"\w", pedido):
                self.ao_pedido(pedido)
                self.ao_estado("ouvindo")
                return True
        # só o nome: "Sim?" e o próximo trecho é o pedido
        self.chamado_ate = time.monotonic() + ESPERA_PEDIDO_S
        self._confirmar_chamado(idioma)
        self.ao_estado("chamado")
        return False


def sininho_wav(taxa=22050):
    """Dois toques curtos (mi-si), baixinho: "ouvi você"."""
    import io
    import wave

    amostras = array.array("h")
    for freq, dur in ((659.25, 0.09), (987.77, 0.13)):
        n = int(taxa * dur)
        for i in range(n):
            envelope = min(1.0, i / (taxa * 0.01), (n - i) / (taxa * 0.04))
            amostras.append(int(7000 * envelope * math.sin(2 * math.pi * freq * i / taxa)))
    if sys.byteorder == "big":
        amostras.byteswap()
    saida = io.BytesIO()
    with wave.open(saida, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(taxa)
        w.writeframes(amostras.tobytes())
    return saida.getvalue()
